"""Self-contained symbolic catalogue: no input data, DSL execution, fitting or alpha claims."""

import ast as _formula_ast
import itertools as _formula_itertools
import statistics as _formula_statistics
from functools import lru_cache as _formula_lru_cache

import pandas as pd


GLOBAL_FIELDS = (
    "PR",
    "Gap",
    "N_real",
    "AR",
    "HHI",
    "Entropy",
    "Top1",
    "Cond",
    "Bulk_var",
    "Slope",
    "crowd_mean",
    "crowd_std",
    "crowd_skew",
    "ret_mean",
)
FORMULA_WINDOWS = (5, 10, 20, 60, 120, 252)
FORMULA_ARCHETYPES = (
    "Level",
    "Change",
    "CSrank",
    "Correlation",
    "Divergence",
    "Interaction",
    "Accel",
    "Conditional",
    "Decay",
    "Neutral",
)
FORMULA_PARTNER = "crowd_i"

NOTE_RESEARCH_SCOPE = """
This is a symbolic audit, not numeric execution or empirical alpha selection.
Kakushadze, 101 Formulaic Alphas: https://arxiv.org/abs/1601.00991
provides operator vocabulary, not evidence for these new crowding hypotheses.
Cawley and Talbot (2010): https://jmlr.org/papers/v11/cawley10a.html
explain selection bias from optimising a noisy performance criterion. No models
are fitted and no empirical scores are invented here.

GLOBAL inputs have shape (time,), with one scalar per day. crowd_i and ret_i
have shape (time,index). Indices are aggregates of stocks, not new asset classes.
The sole deterministic binary partner is crowd_i for every binary archetype;
ret_i is permitted vocabulary but unused. No Cartesian partner search occurs.
Scalar time-series correlation with each crowd_i series is explicitly a
global-to-index operation. A scalar condition/sign can likewise modulate an
index panel. This is not a cross-sectional rank of that scalar.

""".strip()

NOTE_CAUSAL_OPERATORS = """
Operator contract for a FUTURE numerical implementation, not a runnable DSL:
Every time-series operator applies shift(1) to its immediate input internally.
delta(x,d)[t]=x[t-1]-x[t-d-1]. ts_std uses a full d-session sample standard
deviation (ddof=1) of x.shift(1). zscore(x,252) uses x[t-1] relative to its
full trailing252 shifted-input mean and sample standard deviation. correlation
uses d aligned pairs of both shifted inputs and is missing for constant inputs.
ts_rank uses the current last shifted observation's average-tie percentile in
its full60 shifted observations. decay_linear uses full d shifted observations
with weights1..d from oldest to newest, normalised to sum1. Nested operators
add lags: nested delta and decay(delta(...)) have minimum source lag2, not a
single universal shift. rank is an available-date cross-sectional average-tie
percentile over the explicitly eligible index panel; scalar rank is undefined.
indneutralize subtracts an available-date within-sector mean, requiring actual
labels; no index sector label is supplied. Interaction's rank(crowd_i) uses
the available-date panel (lag0), while its delta(F,d) has global-source lag1;
the source_lag_by_input column distinguishes these paths from TS nesting depth.
where(c,a,b) is display shorthand for the supplied Kakushadze ternary
(c)?a:b, not an extra signal operator. where requires its condition and
selected branch to be observable; unavailable condition means missing, not zero.
Zero denominators, insufficient full windows and missing inputs give missing;
there is no filling, clipping, epsilon or fallback model implicit in a formula.
Nested lookbacks add history requirements, too. Inputs must themselves be
point-in-time; internal shifts do not repair historical revisions.

""".strip()

NOTE_FAILURE_MODES = """
Known failures by archetype:
Level: constant/near-constant history makes zscore undefined; the six d rows
repeat the same252-session expression. Slow adaptation is a tradeoff, not a
universal claim that long windows are biased.
Change: level standard deviation is not the standard deviation of d-day changes;
zero dispersion is undefined, and a ratio is not a calibrated significance test.
CSrank: rank of a daily GLOBAL scalar has no cross-sectional dimension.
Correlation: common trends/cohorts may induce association; d=5 is noisy, rolling
windows overlap, and sign does not identify an economic return direction.
Divergence: rank(F1) of a GLOBAL scalar is undefined; do not broadcast before rank.
Interaction: a common sign times a panel rank changes exposure; sign is unstable
near zero and rank ignores the common absolute level. No centred-product alpha.
Accel: nested differences amplify measurement/cohort noise and add causal lags.
Conditional: a fixed .9 tail gate can be rare/discrete and produces discontinuity;
0 denotes the inactive branch, not evidence of no crowding. No threshold search.
Decay: literal delta(F,1) violates the requested minimum5-session lookback; retain
the raw formula as REJECTED rather than silently replacing1 by5.
Neutral: scalar rank is invalid and no economically justified index-sector labels
are provided. A sector for one stock is not a sector for a mixed-stock index.

""".strip()

NOTE_INPUT_BINDINGS = """
Input bindings: all14 GLOBAL names are assumed symbolic bindings, unverified
against user data or vendor-supported fields. In this catalogue PR and HHI mean
spectral participation ratio and spectral eigenvalue-share HHI under the latest
user definition; earlier optional fund-position PR/HHI belong to a different
namespace and are not substituted. Gap, N_real, Bulk_var and the other assumed
spectral definitions also require an explicit supplied dictionary before use.

Default field rejection: crowd_mean of complete fixed-N average-tie percentile
ranks has constant mean (N+1)/(2N), even with ties. crowd_std and crowd_skew are
fixed for distinct ranks but can change with average ties at fixedN, so they are
CONDITIONALLY ADMISSIBLE scalar hypotheses, not analytically constant. Their
changes may reflect tie structure, overlapping aggregates, cohort/coverage or
ranking artifacts rather than changed positioning; no independent return
mechanism is validated. They retain the percentile-moment binding: a moment of
RAW aggregates would be a different source field and is not silently substituted.
Slope has no supplied definition and remains rejected.
Cond depends on near-zero eigenvalues and numerical ridge; N_real and Bulk_var
depend on a declared random-matrix/MP null, effective sample size, serial
dependence, cohort and estimator assumptions. None is fake-calibrated here.

""".strip()

NOTE_INTERPRETATION_LIMITS = """
Irrelevant-artifact invariance is robustness, not proof that a feature is or is
not crowding. That user filter cannot be assessed without data except for the
analytic degeneracies just identified. All survivors are symbolic hypotheses
conditional on supplied field definitions and availability, not validated signals.
No separate numeric implementation, new filtering model, returns or backtest is
created. No 100-200-survivor target is imposed. Return inputs are symbolic only.
HigherPR/Entropy means variation spreads across more spectral modes; higher
AR/HHI/Top1 means more concentration in leading/fewer modes. Spectral breadth
does not establish investor independence, how many stocks participate, common
buy/sell direction or expected returns. Common repositioning pressure remains
an economic hypothesis, not a consequence of eigendecomposition.
Analytically survived-mode counts cover four explicitly named coordinate
perturbations: add a constant to the entire F1 history, multiply F1 by a
positive constant, add a constant to the entire F2 panel, multiply F2 by a
positive constant. These are exact algebraic invariances under fixed cohorts
and valid denominators. They are NOT counts of survived regime breaks, gaps,
universe changes or vintage errors; none of those is certified. Absent F2
does not earn an invariance point. Unit/offset invariance is robustness, not
evidence of an economic edge. The qualitative fragility judgement remains a
separate tie-breaker; no perturbation return experiment is invented.
""".strip()

RESEARCH_NOTES = "\n\n".join(
    (
        NOTE_RESEARCH_SCOPE,
        NOTE_CAUSAL_OPERATORS,
        NOTE_FAILURE_MODES,
        NOTE_INPUT_BINDINGS,
        NOTE_INTERPRETATION_LIMITS,
    )
)

_FIELD_MECHANISMS = {
    "PR": (
        "participation ratio of the stock-crowding spectrum distinguishes "
        "broad from concentrated common positioning"
    ),
    "Gap": (
        "a spectral gap distinguishes a dominant shared stock-positioning "
        "mode from nearby modes"
    ),
    "N_real": (
        "the count of modes exceeding a declared noise benchmark "
        "describes structured stock-positioning breadth"
    ),
    "AR": (
        "absorption ratio describes how much stock-positioning variation "
        "lies in the declared leading modes"
    ),
    "HHI": (
        "spectral concentration describes how stock-positioning variation "
        "concentrates in a few modes"
    ),
    "Entropy": "spectral entropy describes the breadth of stock-positioning modes",
    "Top1": "the leading-mode share describes dominance of one common stock-positioning mode",
    "Cond": (
        "the spectrum condition number describes numerical anisotropy "
        "that may accompany common positioning"
    ),
    "Bulk_var": (
        "noise-bulk variation describes residual stock-positioning "
        "structure under a declared spectral null"
    ),
    "Slope": "an undefined slope cannot support a specified stock-crowding mechanism",
    "crowd_mean": "the mean of complete fixed-N percentile ranks is mechanically constrained",
    "crowd_std": (
        "dispersion of percentile ranks can reflect average ties and "
        "cohort structure rather than positioning changes"
    ),
    "crowd_skew": (
        "skewness of percentile ranks can reflect asymmetric average ties "
        "and cohort structure rather than positioning changes"
    ),
    "ret_mean": (
        "mean stock-index return supplies a symbolic price-context "
        "variable, rather than a pure crowding measure"
    ),
}
_FIELD_FRAGILITY = {
    "PR": 4,
    "Gap": 6,
    "N_real": 9,
    "AR": 4,
    "HHI": 4,
    "Entropy": 4,
    "Top1": 4,
    "Cond": 9,
    "Bulk_var": 9,
    "Slope": 10,
    "crowd_mean": 10,
    "crowd_std": 10,
    "crowd_skew": 10,
    "ret_mean": 6,
}
_FIELD_ORIENTATION = {
    "PR": "higher means more effectively participating modes, not greater concentration",
    "Gap": "higher separates the leading mode from the next without proving crowded direction",
    "N_real": "higher means more modes exceed the specified noise benchmark",
    "AR": "higher means the declared leading modes absorb more positioning variation",
    "HHI": "higher means eigenvalue shares are more concentrated",
    "Entropy": "higher means a more even eigenvalue-share distribution, not greater concentration",
    "Top1": "higher means one mode absorbs more positioning variation",
    "Cond": "higher means stronger numerical anisotropy, possibly an estimation artifact",
    "Bulk_var": "orientation depends on the supplied noise-bulk definition",
    "Slope": "no economic orientation is defined",
    "crowd_mean": "fixed-universe mean is mechanically constrained",
    "crowd_std": "higher dispersion can reflect changing ties, not new crowded capital",
    "crowd_skew": "higher asymmetry can reflect changing ties, not new crowded capital",
    "ret_mean": "higher means stronger supplied index returns, not proof of crowding",
}
_OP_FRAGILITY = {
    "Level": 4,
    "Change": 4,
    "CSrank": 10,
    "Correlation": 6,
    "Divergence": 10,
    "Interaction": 6,
    "Accel": 8,
    "Conditional": 8,
    "Decay": 7,
    "Neutral": 10,
}
_OP_FAILURE_MODES = {
    "Level": (
        "Constant-history denominator and slow adaptation across regime "
        "or definition changes."
    ),
    "Change": (
        "Zero/near-zero trailing denominator; level dispersion is not "
        "change uncertainty; overlapping horizons."
    ),
    "CSrank": (
        "A global scalar has no index cross-section; broadcasting cannot "
        "repair the rank and cohort changes can create artifacts."
    ),
    "Correlation": (
        "Common cohort/trend exposure and noisy short-window correlation "
        "can mimic shared positioning dynamics."
    ),
    "Divergence": (
        "The global scalar rank is undefined; valid panel rank "
        "differences would depend on universe membership and ties."
    ),
    "Interaction": (
        "Near-zero sign instability and a common exposure switch can "
        "reverse all selected index weights together."
    ),
    "Accel": (
        "Nested differencing amplifies measurement noise and adds causal "
        "lags and history requirements."
    ),
    "Conditional": (
        "Discrete tail gating creates rare or unstable activation near "
        "the threshold and with changing ties/cohorts."
    ),
    "Decay": (
        "The one-day inner difference violates the minimum5-session "
        "lookback; finite-window decay retains old state and cannot "
        "repair revisions."
    ),
    "Neutral": (
        "Scalar rank and absent index-sector labels make this invalid; "
        "classification or universe changes alter a within-group "
        "estimand."
    ),
}
_EXACT_INVARIANCE_MODES = {
    "Level": ("F1_offset", "F1_positive_scale"),
    "Change": ("F1_offset", "F1_positive_scale"),
    "Correlation": ("F1_offset", "F1_positive_scale", "F2_offset", "F2_positive_scale"),
    "Interaction": ("F1_offset", "F1_positive_scale", "F2_offset", "F2_positive_scale"),
    "Accel": ("F1_offset",),
    "Conditional": ("F1_offset", "F1_positive_scale", "F2_offset"),
}
_OP_MECHANISMS = {
    "Level": "This fires positively when lagged {field_id} exceeds its own 252-session reference",
    "Change": (
        "This fires positively when lagged {field_id} increases over {d} "
        "sessions relative to its trailing dispersion"
    ),
    "CSrank": (
        "Cross-sectional comparison would test whether {field}, but a "
        "global scalar cannot be ranked across indices."
    ),
    "Correlation": (
        "This is positive when lagged {field_id} and an index's crowding "
        "levels co-vary over {d} sessions"
    ),
    "Divergence": (
        "Relative ranks would contrast the global state with local "
        "crowding, but the global rank is undefined."
    ),
    "Interaction": (
        "This weights crowded stock indices by the sign of the lagged "
        "{d}-session change in {field_id}"
    ),
    "Accel": (
        "This fires positively when the lagged {d}-session change in "
        "{field_id} exceeds its preceding change"
    ),
    "Conditional": (
        "This passes the index's lagged {d}-session crowding change only "
        "when lagged {field_id} is above its 60-session 90th percentile"
    ),
    "Decay": (
        "A linearly weighted average would smooth daily changes, but its "
        "literal one-day inner difference violates the minimum lookback."
    ),
    "Neutral": (
        "Sector demeaning would remove labelled peer exposure, but a "
        "scalar rank and absent index-sector labels make this "
        "construction unavailable."
    ),
}


def _formula_expression(archetype, field, d):
    partner = FORMULA_PARTNER
    return {
        "Level": f"zscore({field},252)",
        "Change": f"delta({field},{d})/ts_std({field},{d})",
        "CSrank": f"rank({field})",
        "Correlation": f"correlation({field},{partner},{d})",
        "Divergence": f"rank({field})-rank({partner})",
        "Interaction": f"sign(delta({field},{d}))*rank({partner})",
        "Accel": f"delta(delta({field},{d}),{d})",
        "Conditional": f"where(ts_rank({field},60)>.9,delta({partner},{d}),0)",
        "Decay": f"decay_linear(delta({field},1),{d})",
        "Neutral": f"indneutralize(rank({field}),sector)",
    }[archetype]


@_formula_lru_cache(maxsize=2048)
def _ast_subtrees(expression):
    """Parse only our generated expressions; never evaluate arbitrary formulas."""
    root = _formula_ast.parse(expression, mode="eval")

    class _Normalise(_formula_ast.NodeTransformer):
        def visit_Constant(self, node):
            # Ignore window literal values, retain the fixed .9 gate and zero.
            if type(node.value) is int and node.value > 0:
                return _formula_ast.copy_location(_formula_ast.Constant("WINDOW"), node)
            return node

        def visit_Name(self, node):
            # Field substitutions alone do not earn structural diversity.
            if node.id in GLOBAL_FIELDS:
                return _formula_ast.copy_location(
                    _formula_ast.Name("GLOBAL", _formula_ast.Load()), node
                )
            if node.id in ("crowd_i", "ret_i"):
                return _formula_ast.copy_location(
                    _formula_ast.Name("PANEL", _formula_ast.Load()), node
                )
            return node

    root = _Normalise().visit(root)
    return frozenset(
        _formula_ast.dump(node, include_attributes=False)
        for node in _formula_ast.walk(root)
        if isinstance(
            node, (_formula_ast.Call, _formula_ast.BinOp, _formula_ast.Compare)
        )
    )


def ast_overlap(first, second):
    """Jaccard overlap of normalised operator subtrees; no empirical meaning."""
    a, b = _ast_subtrees(first), _ast_subtrees(second)
    return len(a & b) / len(a | b) if a | b else 1.0


_BINARY_ARCHETYPES = {"Correlation", "Divergence", "Interaction", "Conditional"}
_PANEL_ARCHETYPES = _BINARY_ARCHETYPES | {"Neutral"}

_FORMULA_FIELD_WARNINGS = {
    "Cond": (
        "Near-zero eigenvalues/ridge and estimator changes can dominate; "
        "no calibrated numerical threshold."
    ),
    "N_real": (
        "MP/null assumptions, effective sample size, serial dependence "
        "and cohort require verification."
    ),
    "Bulk_var": (
        "MP/noise-bulk definition and estimator assumptions require "
        "verification; not a calibrated risk estimate."
    ),
    "ret_mean": (
        "Symbolic return context only; no real returns supplied and no "
        "pure-crowding interpretation assumed."
    ),
    "crowd_std": (
        "Conditionally admissible percentile moment: ties, overlapping "
        "aggregates and cohort/coverage can drive changes; no independent "
        "return mechanism validated."
    ),
    "crowd_skew": (
        "Conditionally admissible percentile moment: ties, overlapping "
        "aggregates and cohort/coverage can drive changes; no independent "
        "return mechanism validated."
    ),
}


def _formula_rejection_reasons(archetype, field):
    reasons = []
    if archetype in {"CSrank", "Divergence", "Neutral"}:
        reasons.append(
            (
                "rank of scalar GLOBAL field has no cross-sectional dimension; "
                "broadcasting does not repair it"
            )
        )
    if archetype == "Neutral":
        reasons.append("no justified index-sector labels supplied")
    if archetype == "Decay":
        reasons.append("literal inner delta(F,1) violates minimum5-session lookback")
    if field == "crowd_mean":
        reasons.append(
            (
                "fixed-N average-tie percentile-rank mean is constant even with "
                "ties; cohort changes are mechanical artifacts"
            )
        )
    if field == "Slope":
        reasons.append(
            "Slope is undefined; no definition or source transformation invented"
        )
    return reasons


def _formula_mechanism(archetype, field, d):
    mechanism = _OP_MECHANISMS[archetype].format(
        field=_FIELD_MECHANISMS[field], field_id=field, d=d
    )
    if archetype in {
        "Level",
        "Change",
        "Correlation",
        "Interaction",
        "Accel",
        "Conditional",
    }:
        mechanism += (
            f"; {_FIELD_MECHANISMS[field]} ({_FIELD_ORIENTATION[field]}), "
            "testing a hypothesis about exposure to common stock-positioning shocks."
        )
    return mechanism


def _formula_risk(archetype, field, d):
    fragility = max(_FIELD_FRAGILITY[field], _OP_FRAGILITY[archetype])
    if archetype == "Correlation" and d == 5:
        fragility = max(fragility, 8)
    mechanism_quality = (
        2
        if field in {"PR", "Gap", "AR", "HHI", "Entropy", "Top1"}
        else 1
        if field != "ret_mean"
        else 0
    )
    robustness = 10 - fragility
    return fragility, mechanism_quality, robustness


def _formula_source_lags(archetype, field):
    max_ts_depth = (
        2
        if archetype in {"Accel", "Decay"}
        else 0
        if archetype in {"CSrank", "Divergence", "Neutral"}
        else 1
    )
    input_lags = {field: max_ts_depth}
    if archetype in _BINARY_ARCHETYPES:
        input_lags[FORMULA_PARTNER] = (
            0 if archetype in {"Interaction", "Divergence"} else 1
        )
    return input_lags, max_ts_depth


def _formula_failure_description(archetype, field, reasons):
    field_warning = (
        "Assumed symbolic binding, unverified against user data/vendor fields. "
        + _FORMULA_FIELD_WARNINGS.get(
            field,
            (
                "Fixed cohort, point-in-time field definition and spectral "
                "estimator must be verified."
            ),
        )
    )
    expected_fragility_mode = " ".join(
        [_OP_FAILURE_MODES[archetype], field_warning] + reasons
    )
    return field_warning, expected_fragility_mode


def _formula_row(archetype, field, d, seen):
    formula = _formula_expression(archetype, field, d)
    reasons = _formula_rejection_reasons(archetype, field)
    duplicate = seen.get(formula)
    status = "REJECTED" if reasons else "DUPLICATE" if duplicate else "SURVIVOR"
    candidate_id = f"{archetype}:{field}:d{d}"
    if not reasons and not duplicate:
        seen[formula] = candidate_id
    mechanism = _formula_mechanism(archetype, field, d)
    fragility, mechanism_quality, robustness = _formula_risk(archetype, field, d)
    input_lags, max_ts_depth = _formula_source_lags(archetype, field)
    field_warning, expected_fragility_mode = _formula_failure_description(
        archetype, field, reasons
    )
    row = {
        "candidate_id": candidate_id,
        "archetype": archetype,
        "field": field,
        "d": d,
        "F2": FORMULA_PARTNER if archetype in _BINARY_ARCHETYPES else None,
        "formula": formula,
        "mechanism": mechanism,
        "hypothesis": True,
        "fragility_0_robust_10_fragile": fragility,
        "expected_fragility_mode": expected_fragility_mode,
        "input_type_shape": "F: scalar daily GLOBAL (T,); F2: index panel (T,N)"
        if archetype in _BINARY_ARCHETYPES
        else "F: scalar daily GLOBAL (T,)",
        "output_type_shape": "invalid (cross-sectional scalar rank)"
        if archetype in {"CSrank", "Divergence", "Neutral"}
        else "index panel (T,N)"
        if archetype in _PANEL_ARCHETYPES
        else "global scalar series (T,)",
        "primitive_fields": (field, FORMULA_PARTNER)
        if archetype in _BINARY_ARCHETYPES
        else (field,),
        "status": status,
        "rejection_reasons": "; ".join(reasons),
        "duplicate_of": duplicate if status == "DUPLICATE" else None,
        "field_admission": "CONDITIONAL_TIE_COHORT"
        if field in {"crowd_std", "crowd_skew"}
        else "ASSUMED_BINDING_UNVERIFIED",
        "field_warning": field_warning,
        "minimum_source_lag": min(input_lags.values()),
        "source_lag_by_input": input_lags,
        "max_time_series_nesting": max_ts_depth,
        "robustness_judgement": (
            "Analytical structural review only; artifact-invariance filter "
            "otherwise unassessed without data."
        ),
        "syntactic_diversity_judgement": (
            "Normalised AST overlap only; windows and field substitutions "
            "earn no extra structural diversity."
        ),
        "mechanism_priority": mechanism_quality,
        "structural_robustness": robustness,
        "analytically_survived_mode_count": len(
            _EXACT_INVARIANCE_MODES.get(archetype, ())
        ),
        "analytical_invariance_modes": _EXACT_INVARIANCE_MODES.get(archetype, ()),
        "regime_gap_cohort_revision_survival": "NOT certified; see failure-mode audit",
        "numeric_execution": False,
    }
    return row


def _formula_priority(row, novelty):
    return (
        -int(row.mechanism_priority),
        -int(row.analytically_survived_mode_count),
        -int(row.structural_robustness),
        -novelty,
        row.formula,
        row.candidate_id,
    )


def _formula_slate(survivors):
    """Balance admissible archetypes, then order by the declared criteria."""
    selected = []
    admissible = [
        name for name in FORMULA_ARCHETYPES if name in set(survivors.archetype)
    ]
    target_count = min(30, len(survivors))
    base_slots, extra_slots = (
        divmod(target_count, len(admissible)) if admissible else (0, 0)
    )
    slots = {
        name: base_slots + int(j < extra_slots) for j, name in enumerate(admissible)
    }
    subtrees = {i: _ast_subtrees(survivors.at[i, "formula"]) for i in survivors.index}

    def overlap(i, j):
        a, b = subtrees[i], subtrees[j]
        return len(a & b) / len(a | b) if a | b else 1.0

    for archetype in admissible:
        remaining = list(survivors.index[survivors.archetype.eq(archetype)])
        while (
            remaining
            and sum(survivors.at[i, "archetype"] == archetype for i in selected)
            < slots[archetype]
        ):

            def selection_key(i):
                novelty = (
                    1 - _formula_statistics.mean(overlap(i, j) for j in selected)
                    if selected
                    else 1.0
                )
                return _formula_priority(survivors.loc[i], novelty)

            chosen = min(remaining, key=selection_key)
            selected.append(chosen)
            remaining.remove(chosen)
    novelty_map = {
        i: 1 - _formula_statistics.mean(overlap(i, j) for j in selected if j != i)
        if len(selected) > 1
        else 1.0
        for i in selected
    }
    selected.sort(key=lambda i: _formula_priority(survivors.loc[i], novelty_map[i]))
    overlaps = [overlap(i, j) for i, j in _formula_itertools.combinations(selected, 2)]
    return {
        "selected": selected,
        "novelty_values": [novelty_map[i] for i in selected],
        "admissible": admissible,
        "slots": slots,
        "mean_overlap": _formula_statistics.mean(overlaps) if overlaps else 0.0,
    }


def _formula_top30(survivors, selection):
    selected = selection["selected"]
    novelty_values = selection["novelty_values"]
    top_rows = []
    for number, (i, novelty) in enumerate(zip(selected, novelty_values), 1):
        row = survivors.loc[i]
        top_rows.append(
            {
                "#": number,
                "Formula": row.formula,
                "Interpretation": row.mechanism,
                "Fragility mode": (
                    f"Hypothesis fragility {row.fragility_0_robust_10_fragile}/10; "
                    f"{row.expected_fragility_mode}"
                ),
                "Orthogonality score": (
                    f"{novelty:.3f} syntactic novelty; NOT empirical orthogonality"
                ),
                "syntactic_novelty": novelty,
                "candidate_id": row.candidate_id,
            }
        )
    top30 = pd.DataFrame(top_rows)
    return top30


def _formula_metadata(all_candidates, survivors, top30, selection):
    admissible = selection["admissible"]
    slots = selection["slots"]
    mean_overlap = selection["mean_overlap"]
    metadata = {
        "catalogue_rows": len(all_candidates),
        "global_field_count": len(GLOBAL_FIELDS),
        "archetype_count": len(FORMULA_ARCHETYPES),
        "windows": FORMULA_WINDOWS,
        "partner_policy": (
            "F2=crowd_i for every binary archetype; no partner search; ret_i "
            "is permitted but unused."
        ),
        "survivor_count": len(survivors),
        "top_count": len(top30),
        "status_counts": all_candidates.status.value_counts().sort_index().to_dict(),
        "ranking_policy": (
            "Equal slots across admissible archetypes derived "
            "from30/archetype_count; use mechanism clarity, exact "
            "coordinate-invariance mode count, qualitative structural "
            "robustness, AST syntax novelty and stable lexical ties. Present "
            "the balanced slate by those same criteria. Counts do not certify "
            "regime/gap/cohort/revision survival. No empirical performance."
        ),
        "admissible_archetypes": admissible,
        "excluded_archetypes": [
            name for name in FORMULA_ARCHETYPES if name not in admissible
        ],
        "archetype_slots": slots,
        "diversity_definition": (
            "Syntactic Jaccard operator-AST subtree overlap; positive integer "
            "windows ignored, GLOBAL/PANEL field identities normalised; fixed "
            ".9 and zero retained."
        ),
        "mean_pairwise_ast_overlap": mean_overlap,
        "overlap_threshold": 0.4,
        "overlap_threshold_flag": mean_overlap >= 0.4,
        "overlap_judgement": (
            "High overlap: syntactic diversity target not met; reported "
            "honestly, formulas not altered."
        )
        if mean_overlap >= 0.4
        else "Below syntax-overlap flag; not evidence of empirical independence.",
        "empirical_orthogonality": "NOT measured; no data or returns supplied.",
        "artifact_invariance": (
            "Unassessed without data except analytic degeneracy; robustness "
            "is not proof of non-crowding."
        ),
        "field_binding_status": (
            "All14 GLOBAL fields are assumed symbolic bindings, unverified "
            "against user data or vendor-supported fields; PR/HHI are "
            "spectral, not fund-position fields."
        ),
        "numeric_execution": False,
        "disabled_by_default": True,
        "research_notes": RESEARCH_NOTES,
        "sources": {
            "operator_vocabulary": "https://arxiv.org/abs/1601.00991",
            "selection_bias": "https://jmlr.org/papers/v11/cawley10a.html",
        },
    }
    return metadata


def build_formula_catalogue():
    """Construct the full ledger, unique survivors, balanced slate and audit."""
    seen = {}
    rows = [
        _formula_row(archetype, field, d, seen)
        for archetype, field, d in _formula_itertools.product(
            FORMULA_ARCHETYPES, GLOBAL_FIELDS, FORMULA_WINDOWS
        )
    ]
    all_candidates = pd.DataFrame(rows)
    survivors = (
        all_candidates[all_candidates.status.eq("SURVIVOR")]
        .copy()
        .reset_index(drop=True)
    )
    selection = _formula_slate(survivors)
    top30 = _formula_top30(survivors, selection)
    metadata = _formula_metadata(all_candidates, survivors, top30, selection)
    return {
        "all_candidates": all_candidates,
        "survivors": survivors,
        "top30": top30,
        "metadata": metadata,
    }
