"""Execute the deliverable in a fresh kernel and inspect every cell result."""

from pathlib import Path
import json
import os
import time
import importlib.metadata
import sys
import asyncio
import warnings
import hashlib
import ast
from datetime import datetime, timezone

# Opt in to Jupyter's documented platformdirs migration before importing it.
os.environ["JUPYTER_PLATFORM_DIRS"] = "1"
root = Path(__file__).resolve().parents[1]
verification_path = root / "work" / "verification.json"
execution_started_utc = datetime.now(timezone.utc).isoformat()
last_cell = {"index": None, "purpose": None}
verification_path.write_text(
    json.dumps(
        {
            "status": "running",
            "warnings_are_errors": True,
            "execution_started_utc": execution_started_utc,
        }
    ),
    encoding="utf-8",
)


def failure_hook(kind, value, trace):
    verification_path.write_text(
        json.dumps(
            {
                "status": "failed",
                "error_type": kind.__name__,
                "error": str(value),
                "execution_started_utc": execution_started_utc,
                "last_cell": last_cell,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    sys.__excepthook__(kind, value, trace)


sys.excepthook = failure_hook

# pyzmq requires selector add_reader support on Windows. Select the compatible
# loop instead of suppressing its Proactor compatibility warning.
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
warnings.simplefilter("error")
import nbformat
from nbclient import NotebookClient

for variable, folder in [
    ("JUPYTER_RUNTIME_DIR", "jupyter_runtime"),
    ("IPYTHONDIR", "ipython"),
    ("JUPYTER_CONFIG_DIR", "jupyter_config"),
]:
    path = root / "work" / folder
    path.mkdir(exist_ok=True)
    os.environ[variable] = str(path)
os.environ["LOKY_MAX_CPU_COUNT"] = "1"
os.environ["MPLBACKEND"] = "Agg"
notebook_path = root / "ASX_Crowding_Framework.ipynb"
initial_file_sha256 = hashlib.sha256(notebook_path.read_bytes()).hexdigest()
notebook = nbformat.read(notebook_path, as_version=4)
embedded_sources = {}
manifest = notebook.metadata.stock_crowding.get("embedded_source_manifest", {})
embedded_ast_digests = {}


def semantic_digest(source):
    return hashlib.sha256(
        ast.dump(ast.parse(source), include_attributes=False).encode("utf-8")
    ).hexdigest()


for source_name in ["notebook_source.py", "formula_catalogue.py", "profile_stages.py"]:
    source_path = root / "work" / source_name
    embedded_sources[source_name] = hashlib.sha256(source_path.read_bytes()).hexdigest()
    entry = manifest.get(source_name)
    if entry is None:
        raise RuntimeError(
            f"Missing split-source manifest for {source_name}; rebuild the notebook."
        )
    parts = [
        cell
        for cell in notebook.cells
        if cell.cell_type == "code"
        and cell.metadata.get("embedded_module") == source_name
    ]
    sequence = [cell.metadata.get("embedded_part") for cell in parts]
    if (
        not all(type(part) is int for part in sequence)
        or len(sequence) != entry["parts"]
        or sorted(sequence) != list(range(entry["parts"]))
    ):
        raise RuntimeError(
            f"Missing or duplicated definition cells for {source_name}: {sequence}"
        )
    # Execution intentionally stages the matrix-only dependency closure first.
    # Reassemble original source order only for semantic fidelity verification.
    ordered_parts = sorted(parts, key=lambda cell: cell.metadata["embedded_part"])
    joined = "\n\n".join(cell.source for cell in ordered_parts)
    actual_ast = semantic_digest(joined)
    source_ast = semantic_digest(source_path.read_text(encoding="utf-8"))
    if (
        actual_ast != source_ast
        or actual_ast != entry["semantic_ast_sha256"]
        or embedded_sources[source_name] != entry["source_sha256"]
    ):
        raise RuntimeError(
            f"Embedded split definitions do not match packaging source: {source_name}"
        )
    embedded_ast_digests[source_name] = actual_ast
if (
    embedded_sources["notebook_source.py"]
    != notebook.metadata.stock_crowding.runtime_source_sha256
):
    raise RuntimeError(
        "Runtime source digest does not match benchmark-bound notebook metadata."
    )


def bound_names(node):
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return {node.name}
    if isinstance(node, (ast.Import, ast.ImportFrom)):
        return {alias.asname or alias.name.split(".")[0] for alias in node.names}
    if isinstance(node, (ast.Assign, ast.AnnAssign)):
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        return {
            item.id
            for target in targets
            for item in ast.walk(target)
            if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store)
        }
    return set()


defined = set()
matrix_prerequisites_verified = False
for cell_index, cell in enumerate(notebook.cells):
    if cell.cell_type != "code":
        continue
    if cell.metadata.get("purpose", "").startswith("Main synthetic index-score"):
        missing = (
            set(notebook.metadata.stock_crowding.get("matrix_prerequisites", []))
            - defined
        )
        if missing:
            raise RuntimeError(
                f"Matrix demo cell {cell_index} precedes required setup: {sorted(missing)}"
            )
        matrix_prerequisites_verified = True
    for node in ast.parse(cell.source).body:
        if cell.metadata.get("embedded_module") == "notebook_source.py" and isinstance(
            node, (ast.FunctionDef, ast.AsyncFunctionDef)
        ):
            defaults = list(node.args.defaults) + [
                item for item in node.args.kw_defaults if item is not None
            ]
            uses_config = any(
                isinstance(item, ast.Name) and item.id == "Config"
                for default in defaults
                for item in ast.walk(default)
            )
            if uses_config and "Config" not in defined:
                raise RuntimeError(
                    f"{node.name} in cell {cell_index} evaluates a Config default before Config exists."
                )
        defined.update(bound_names(node))
if not matrix_prerequisites_verified:
    raise RuntimeError(
        "No identified matrix demonstration cell; cannot verify staged prerequisites."
    )


def source_digest(document):
    payload = json.dumps(
        [(cell.cell_type, cell.source) for cell in document.cells], ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


source_sha256_before = source_digest(notebook)
started = time.perf_counter()
progress = root / "work" / "execution_progress.log"
progress.write_text("Starting fresh-kernel execution\n", encoding="utf-8")


def cell_start(cell, cell_index, **kwargs):
    purpose = cell.metadata.get("purpose") or (
        cell.source.splitlines()[0][:100] if cell.source else "empty"
    )
    last_cell.update(index=cell_index, purpose=purpose)
    message = f"Cell {cell_index}: {purpose}"
    with progress.open("a", encoding="utf-8") as stream:
        stream.write(message + "\n")
    print(message, flush=True)


client = NotebookClient(
    notebook,
    timeout=90,
    startup_timeout=30,
    kernel_name="python3",
    on_cell_start=cell_start,
    resources={"metadata": {"path": str(root)}},
)
executed = client.execute()
errors = [
    {"cell": j, "error": output.get("evalue")}
    for j, cell in enumerate(executed.cells)
    for output in cell.get("outputs", [])
    if output.output_type == "error"
]
if errors:
    raise RuntimeError(errors)
warning_outputs = [
    {"cell": j, "text": output.get("text", "")}
    for j, cell in enumerate(executed.cells)
    for output in cell.get("outputs", [])
    if output.output_type == "stream"
    and any(marker in output.get("text", "") for marker in ["Warning:", "WARNING:"])
]
if warning_outputs:
    raise RuntimeError(warning_outputs)
nbformat.validate(executed)
source_sha256_after = source_digest(executed)
if source_sha256_before != source_sha256_after:
    raise RuntimeError("Cell sources changed during execution.")
if hashlib.sha256(notebook_path.read_bytes()).hexdigest() != initial_file_sha256:
    raise RuntimeError(
        "Notebook was edited on disk during execution; refusing to overwrite or certify it."
    )
if any(
    cell.execution_count is None for cell in executed.cells if cell.cell_type == "code"
):
    raise RuntimeError("A code cell was not executed.")
nbformat.write(executed, notebook_path)
packages = [
    "numpy",
    "pandas",
    "scipy",
    "scikit-learn",
    "matplotlib",
    "threadpoolctl",
    "pyarrow",
    "nbformat",
    "nbclient",
    "ipykernel",
    "pytest",
]
summary = {
    "status": "executed",
    "cells": len(executed.cells),
    "code_cells": sum(c.cell_type == "code" for c in executed.cells),
    "error_outputs": len(errors),
    "warning_outputs": len(warning_outputs),
    "warnings_are_errors": True,
    "seconds": time.perf_counter() - started,
    "embedded_checks": executed.metadata.stock_crowding.test_cases,
    "python": sys.version,
    "execution_started_utc": execution_started_utc,
    "execution_completed_utc": datetime.now(timezone.utc).isoformat(),
    "notebook_sha256": hashlib.sha256(notebook_path.read_bytes()).hexdigest(),
    "source_sha256_before": source_sha256_before,
    "source_sha256_after": source_sha256_after,
    "embedded_sources_match": True,
    "embedded_source_sha256": embedded_sources,
    "embedded_semantic_ast_sha256": embedded_ast_digests,
    "split_source_manifest_verified": True,
    "matrix_prerequisites_verified": matrix_prerequisites_verified,
    "largest_code_cell_lines": max(
        len(cell.source.splitlines())
        for cell in executed.cells
        if cell.cell_type == "code"
    ),
    "layout_line_target": executed.metadata.stock_crowding.get("layout_line_target"),
    "layout_exceptions": executed.metadata.stock_crowding.get("layout_exceptions", []),
    "versions": {name: importlib.metadata.version(name) for name in packages},
    "alpha_validated": False,
    "notebook": str(notebook_path),
}
(root / "work" / "verification.json").write_text(
    json.dumps(summary, indent=2), encoding="utf-8"
)
print(json.dumps(summary, indent=2))
