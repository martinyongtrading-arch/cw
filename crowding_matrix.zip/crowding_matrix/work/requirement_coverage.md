# Requirement-to-artifact coverage

This ledger corrects broad completion wording. Tests establish selected machinery contracts; they do not establish global computational optimality, universal statistical validity or investment-production readiness. An original design promise is not completed merely because its limitation is documented here.

Provenance matters: the original +/-20% and feature +/-10% requests asked for analytical reasoning, which is fulfilled. A comprehensive executed sensitivity grid is a proposed validation stage, not a requirement to fabricate empirical evidence in the web-only review. A numeric fourteen-field extractor was not explicitly requested by the symbolic-generation prompt.

| Requirement | Actual artifact or behavior | Status |
|---|---|---|
| Formula, mechanism and expected fragility for every grid row | All840rows include expected_fragility_mode; top30 uses the same descriptions, with operator and field caveats | Implemented; regression-tested |
| Numeric index score / score-AR / delta-AR | Initial-release scores, bounded lagged Spearman matrix, constant-correlation shrinkage, SVD and full252normalization | Implemented; controlled-fixture tests and declared local benchmarks |
| Analytical +/-10% and +/-20% fragility review | Analytical window/threshold/configuration reasoning and a manual perturbation protocol; selected PIT/edge-case fixtures exist | Requested analytical review fulfilled; full proposed sensitivity validation has not been run |
| Forced-cover stress in portfolio outcomes | cover_ledger is standalone and tested; evaluate_legs uses fixed-holding signed-return/cost scenarios | NOT integrated into portfolio evaluation |
| Untouched purged holdout | Chronological label-maturity eligibility is implemented; exploratory full-history reports exist | Original purged-holdout design promise remains NOT implemented/executed; no unused evidence was supplied |
| Optional signal/model comparisons | Optional candidate score columns and fixed-model predictions are generated | Automatic portfolio comparison for these outputs is NOT wired; default report is baseline versus overlay only |
| Fourteen spectral input fields | Fourteen assumed names are accepted as symbolic formula vocabulary; AR has its separate numeric matrix path | Symbolic-generation scope fulfilled; no fourteen-field extractor or numeric DSL implemented, neither explicitly requested by that prompt |
| OptionAreturn-AR / OptionBposition-HHI | Literature and input/timing/interpretation audit only | Conditional constructions are reviewed, NOT runnable paths; no inputs are fetched or invented |
| GICS2/4/6/8research consult | Cited hierarchy, taxonomy, PIT and aggregation methodology; supplied sector labels have pooled stock-date summaries | Research request fulfilled;4/6/8hierarchy views are not implemented and are not claimed |
| MP filtering / EWM / two-window claims | Unsupported universal claims were challenged; fixed requested estimator retained | Review fulfilled; alternative estimators are not mandatory or silently implemented |
| Lender/broker count validation | Each known active/total count leg requires a feasible integer, and matched legs require active <= total; broker_count requires finite nonnegative integers at public validation/standalone entry points | Implemented without rounding; missing remains unknown and standalone checks use visible vintages only. Average/weighted fields cannot silently map to entity counts |
| Zero-variance unusualness | Zero historical standard deviation, detected exactly from identical values, yields neutral0 | Implemented without a dedicated zero-variance flag; earlier 'flagged' wording corrected |
| Actual source/cost/capacity and statistical edge | Explicit mappings, source contracts and declared cost scenarios; no proprietary/market evidence supplied | Real vintages, paid borrow/fills/locates, feasible capacity, unused-evidence inference and alpha remain unverified |
| Local compute scale |500×200matrix; ASX200/300ten-decision parity on columns not deliberately changed by the 2026-10-30 fixes; full330×200stock feature backfill | Measured at stated synthetic sizes; global near-optimality, fullASX300/7000vintage backfills and database/HPC scaling remain unmeasured |

The purged-holdout design promise and end-to-end portfolio stress/comparison integrations remain genuine implementation gaps. The comprehensive proposed sensitivity validation is unperformed, while the requested analytical review is fulfilled. This update closes a catalogue-output omission and documents the actual boundary; it does not silently count missing stages as completed or turn research-only requests into new implementation demands.
