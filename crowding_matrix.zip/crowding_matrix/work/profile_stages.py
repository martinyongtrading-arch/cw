"""Small reproducible synthetic stage profiler; no numerical PIT caching."""

from pathlib import Path
import time
import json
import platform
import tracemalloc
import importlib.metadata
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits, threadpool_info


def _profile_measurement(measurements):
    def measure(
        stage, dimensions, operation, repetitions=3, cache="OS cache uncontrolled"
    ):
        durations = []
        value = None
        for repeat in range(repetitions):
            start = time.perf_counter()
            value = operation()
            durations.append(time.perf_counter() - start)
        tracemalloc.start()
        memory_start = time.perf_counter()
        try:
            memory_value = operation()
            _, peak = tracemalloc.get_traced_memory()
            memory_seconds = time.perf_counter() - memory_start
        finally:
            tracemalloc.stop()
        del memory_value
        measurements.append(
            dict(
                stage=stage,
                dimensions=dimensions,
                median_seconds=float(np.median(durations)),
                samples_seconds=durations,
                timing_repetitions=repetitions,
                timing_label="single run" if repetitions == 1 else "median of3 runs",
                python_traced_peak_MiB=peak / 2**20,
                memory_sample_seconds=memory_seconds,
                cache_state=cache,
            )
        )
        return value

    return measure


def _profile_stock_inputs(api, folder, measure):
    fixture = api["synthetic_inputs"](sessions_count=330, securities_count=8, seed=33)
    lending = fixture["lending"]
    calendar = fixture["sessions"]
    universe = fixture["universe"]
    cfg = api["Config"]()
    csv_path = folder / "synthetic_lending.csv"
    parquet_path = folder / "synthetic_lending.parquet"
    lending.to_csv(csv_path, index=False)
    lending.to_parquet(parquet_path, index=False)
    mapping = {c: c for c in lending}
    shape = f"{len(lending)} lending rows,{len(lending.columns)} mapped columns"
    measure("CSV loading", shape, lambda: api["load_table"](csv_path, mapping))
    measure("Parquet loading", shape, lambda: api["load_table"](parquet_path, mapping))
    stock_shape = f"{len(calendar)} sessions×{lending.security_id.nunique()} stocks"
    measure(
        "As-of canonical history",
        f"{len(lending)} rows;{stock_shape};one vintage/row",
        lambda: api["history_asof"](lending, calendar.decision_at.iloc[-1]),
    )
    members = api["universe_at"](
        universe, calendar.session.iloc[-1], calendar.decision_at.iloc[-1]
    )
    measure(
        "One decision feature snapshot",
        stock_shape + ";16 diagnostic columns",
        lambda: api["features_at"](
            lending, calendar, members, calendar.decision_at.iloc[-1], cfg
        ),
    )
    return fixture, cfg, stock_shape


def _profile_stock_features(api, fixture, cfg, stock_shape, measure):
    lending = fixture["lending"]
    calendar = fixture["sessions"]
    universe = fixture["universe"]
    features = measure(
        "Full stock feature reference",
        stock_shape + ";full as-of rebuild",
        lambda: api["build_feature_panel"](lending, calendar, universe, cfg),
        repetitions=1,
        cache="single timed backfill plus separate memory sample;not7000stocks",
    )
    labels = measure(
        "Forward labels",
        stock_shape + f";H{cfg.horizon}",
        lambda: api["make_labels"](fixture["prices"], calendar, cfg.horizon),
    )
    joined = features.merge(
        labels, on=["session", "security_id"], how="left", validate="one_to_one"
    )
    models = measure(
        "Five optional fixed research models",
        stock_shape
        + f";minimum training sessions={cfg.minimum_train_sessions};no selection",
        lambda: api["chronological_predictions"](joined, cfg),
        repetitions=1,
    )
    model_counts = {
        "fit_timestamps": int(models.fit_at.nunique()),
        "prediction_rows": int(models.ridge.notna().sum()),
        "design_columns": int(models.model_input_count.max()),
        "input_rows": len(joined),
    }
    return joined, model_counts


def _profile_stock_accounting(api, calendar, cfg, joined, measure):
    complete = joined.loc[joined.session.isin(calendar.session.iloc[: -cfg.horizon])]
    legs = measure(
        "Stock-leg accounting scenarios",
        (
            f"{complete.session.nunique()} completed dates;"
            f"{len(complete)} stock-date rows;baseline/overlay;two legs"
        ),
        lambda: api["evaluate_legs"](complete, cfg),
    )
    measure(
        "Paired block bootstrap",
        f"{legs.session.nunique()} dates;H{cfg.horizon};999resamples per leg",
        lambda: api["comparison_report"](legs, cfg),
    )


def _profile_sparse_aggregation(api, measure, rng):
    dates = pd.bdate_range("2024-01-02", periods=20)
    ids = np.arange(7000)
    stocks = pd.DataFrame(
        {
            "session": np.repeat(dates, 7000),
            "security_id": np.tile(ids, 20),
            "on_loan": rng.uniform(1e4, 1e6, 140000),
            "shares_outstanding": 1e8,
            "adv_eligible": np.tile(ids < 4900, 20),
        }
    )
    chosen = np.concatenate(
        [rng.choice(ids, size=200, replace=False) for _ in range(200)]
    )
    memberships = pd.DataFrame(
        {
            "session": np.repeat(dates, 40000),
            "index_id": np.tile(np.repeat(np.arange(200), 200), 20),
            "security_id": np.tile(chosen, 20),
        }
    )
    measure(
        "Sparse stock/index aggregation",
        (
            f"{len(dates)} dates;{len(ids)} stocks;"
            f"{stocks.loc[stocks.adv_eligible, 'security_id'].nunique()} eligible;"
            f"{memberships.index_id.nunique()} indices;"
            f"{len(memberships)} membership rows;static memberships"
        ),
        lambda: api["aggregate_stock_positioning"](stocks, memberships),
    )


def _profile_index_stages(api, measure, rng):
    raw = pd.DataFrame(
        rng.lognormal(size=(500, 200)), index=pd.bdate_range("2020-01-02", periods=500)
    )
    matrix_shape = f"{raw.shape[0]} sessions×{raw.shape[1]} indices"
    scores = measure(
        "Index percentile scoring",
        matrix_shape,
        lambda: api["index_crowding_scores"](raw),
    )
    ar = measure(
        "Full Spearman/shrinkage/SVD AR",
        matrix_shape + ";60changes;one BLAS thread",
        lambda: api["absorption_ratio"](scores),
    )
    measure(
        "Delta-AR normalization",
        (
            f"{len(ar['series'])} session rows;"
            f"{ar['series'].AR.notna().sum()} valid AR values;"
            "15/252full windows"
        ),
        lambda: api["delta_ar"](ar["series"].AR),
    )
    return ar, matrix_shape


def _profile_catalogue_stages(api, measure):
    def first_catalogue():
        api["_ast_subtrees"].cache_clear()
        return api["build_formula_catalogue"]()

    catalogue = measure(
        "Formula catalogue and AST: first call",
        "requested840slots",
        first_catalogue,
        repetitions=1,
        cache="ASTcache cleared before each call;no market cache",
    )
    measure(
        "Formula catalogue and AST: warm",
        "same840slots;immutableASTreuse",
        lambda: api["build_formula_catalogue"](),
        cache="warm bounded pure-syntaxcache;dataframes rebuilt",
    )
    return catalogue


def _profile_plot_stage(ar, matrix_shape, measure):
    def draw_plot():
        import matplotlib.pyplot as plt

        figure, axes = plt.subplots(1, 3, figsize=(16, 4))
        axes[0].plot(ar["series"].AR)
        axes[1].plot(ar["series"].delta_AR)
        axes[2].imshow(ar["latest_correlation"].to_numpy(), vmin=-1, vmax=1)
        figure.canvas.draw()
        plt.close(figure)

    measure("Three-panel plot render", matrix_shape + ";16×4inch", draw_plot)


def _profile_libraries():
    return [
        {
            k: v
            for k, v in library.items()
            if k
            in [
                "user_api",
                "internal_api",
                "version",
                "num_threads",
                "threading_layer",
                "architecture",
            ]
        }
        for library in threadpool_info()
    ]


def _profile_metadata(api, measurements, model_counts, ar, catalogue, libraries):
    result = {
        "scope": "synthetic local stage profile;no investment evidence",
        "measurements": measurements,
        "stock_panel_implementation": "invocation-prepared"
        if "_prepare_stock_context" in api
        else "reference before preparation",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "libraries": libraries,
        "versions": {
            p: importlib.metadata.version(p)
            for p in [
                "numpy",
                "pandas",
                "scipy",
                "scikit-learn",
                "threadpoolctl",
                "pyarrow",
            ]
        },
        "model_counts": model_counts,
        "matrix_counts": {
            "valid_AR": int(ar["series"].AR.notna().sum()),
            "valid_delta_AR": int(ar["series"].delta_AR.notna().sum()),
        },
        "formula_counts": catalogue["metadata"]["status_counts"],
        "memory_note": (
            "Separate call:peak additional traced allocation above prebuilt "
            "inputs and retained outputs;excludes total process/native RSS"
        ),
        "timing_note": (
            "Ordinary wall times without tracemalloc;one separate "
            "memory-instrumented call per stage. Fixture creation/export "
            "writes excluded. Files written immediately before reads;no "
            "cold-storage claim. Distinct fixtures are not one end-to-end "
            "workload."
        ),
        "unmeasured": [
            "HPC node/runtime and parallel scaling",
            "real database query/transfer plans:no DB connector delivered",
            "full7000stock vintage-feature backfill",
            "real vendor data size/revisions and paid execution/borrow",
        ],
    }
    return result


def run_stage_profile(api, folder):
    # Load optional model libraries before applying thread limits, so later imports
    # cannot introduce an unconstrained OpenMP runtime into the measured section.
    import sklearn.ensemble

    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    measurements = []
    measure = _profile_measurement(measurements)
    with threadpool_limits(limits=1):
        fixture, cfg, stock_shape = _profile_stock_inputs(api, folder, measure)
        joined, model_counts = _profile_stock_features(
            api, fixture, cfg, stock_shape, measure
        )
        _profile_stock_accounting(api, fixture["sessions"], cfg, joined, measure)
        rng = np.random.default_rng(77)
        _profile_sparse_aggregation(api, measure, rng)
        ar, matrix_shape = _profile_index_stages(api, measure, rng)
        catalogue = _profile_catalogue_stages(api, measure)
        _profile_plot_stage(ar, matrix_shape, measure)
        libraries = _profile_libraries()
    result = _profile_metadata(
        api, measurements, model_counts, ar, catalogue, libraries
    )
    (folder / "stage_profile.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    return result
