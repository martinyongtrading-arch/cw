"""Build-time packager only. Delivered notebook imports no files from work/."""

from pathlib import Path
import ast
import json
import re
import hashlib
import pprint
import html
import subprocess
import sys
import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
cells = []
MAX_CODE_LINES = 99
embedded_manifest = {}
layout_exceptions = []
matrix_prerequisites = set()


def matrix_dependency_names(source):
    """Static module-name closure; no source execution or inferred market inputs."""
    tree = ast.parse(source)
    bindings = {}
    imported = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            bindings[node.name] = node
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                imported.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in targets:
                if isinstance(target, ast.Name):
                    bindings[target.id] = node
    required = {
        "Config",
        "InputError",
        "index_crowding_scores",
        "absorption_ratio",
        "absorption_from_correlation",
        "delta_ar",
    }
    missing = required - set(bindings)
    if missing:
        raise ValueError(
            f"Matrix bootstrap definitions absent from runtime: {sorted(missing)}"
        )
    pending = list(required)
    while pending:
        name = pending.pop()
        referenced = {
            item.id
            for item in ast.walk(bindings[name])
            if isinstance(item, ast.Name) and isinstance(item.ctx, ast.Load)
        }
        additions = (referenced & set(bindings)) - required
        required.update(additions)
        pending.extend(additions)
    return required | imported


def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))


def append_code_cell(text, tags=None, purpose=None, metadata=None):
    cell = nbf.v4.new_code_cell(text)
    if tags:
        cell.metadata["tags"] = tags
        if set(tags) & {"definitions", "embedded-tests", "collapsed-code"}:
            cell.metadata["jupyter"] = {"source_hidden": True}
            cell.metadata["collapsed"] = True
    if purpose:
        cell.metadata["purpose"] = purpose
    if metadata:
        cell.metadata.update(metadata)
    cells.append(cell)


def format_source(source):
    """Build-only formatter; no Ruff dependency is embedded in the notebook."""
    completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "ruff",
            "format",
            "--stdin-filename",
            "notebook_cell.py",
            "--line-length",
            "88",
            "-",
        ],
        input=source,
        text=True,
        encoding="utf-8",
        capture_output=True,
        check=True,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return completed.stdout.rstrip("\n")


def code(text, tags=None, purpose=None, metadata=None):
    purpose = purpose or next(
        (line.lstrip("# ").strip() for line in text.splitlines() if line.strip()),
        "Notebook step",
    )
    if not text.lstrip().startswith("#"):
        text = "# " + purpose + "\n" + text
    formatted = format_source(text)
    if len(formatted.splitlines()) > MAX_CODE_LINES:
        title = purpose or next(
            (line.lstrip("# ").strip() for line in text.splitlines() if line.strip()),
            "Notebook step",
        )
        definition_cells(
            formatted, title=title, tags=tags or [], extra_metadata=metadata
        )
    else:
        append_code_cell(formatted, tags=tags, purpose=purpose, metadata=metadata)


def semantic_digest(source):
    """Whitespace/comments may change; executable top-level AST must not."""
    return hashlib.sha256(
        ast.dump(ast.parse(source), include_attributes=False).encode("utf-8")
    ).hexdigest()


def definition_cells(source, *, title, tags, source_name=None, extra_metadata=None):
    """Split only between top-level statements; retain comments and licenses."""
    source = format_source(source)
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    if not tree.body:
        return
    starts = []
    for position, node in enumerate(tree.body):
        decorators = getattr(node, "decorator_list", [])
        start = min([node.lineno] + [item.lineno for item in decorators]) - 1
        floor = tree.body[position - 1].end_lineno if position else 0
        while start > floor and (
            not lines[start - 1].strip() or lines[start - 1].lstrip().startswith("#")
        ):
            start -= 1
        starts.append(start if position else 0)
    starts.append(len(lines))
    groups = []
    buffer = []
    labels = []
    phase = None
    for position, node in enumerate(tree.body):
        segment = "".join(lines[starts[position] : starts[position + 1]])
        name = getattr(node, "name", None)
        if name is None and isinstance(node, (ast.Import, ast.ImportFrom)):
            name = "imports"
        if name is None and isinstance(node, (ast.Assign, ast.AnnAssign)):
            target = node.targets[0] if isinstance(node, ast.Assign) else node.target
            name = target.id if isinstance(target, ast.Name) else "module constants"
        name = name or type(node).__name__
        next_phase = "definitions"
        if source_name == "notebook_source.py":
            next_phase = (
                "matrix-bootstrap"
                if isinstance(node, (ast.Import, ast.ImportFrom))
                or name in matrix_prerequisites
                else "core-after-matrix"
            )
        proposed = "".join(buffer + [segment]).strip("\n")
        if buffer and (
            len(proposed.splitlines()) + 2 > MAX_CODE_LINES or phase != next_phase
        ):
            groups.append(("".join(buffer).strip("\n"), labels, phase))
            buffer, labels = [], []
        phase = next_phase
        buffer.append(segment)
        labels.append(name)
    if buffer:
        groups.append(("".join(buffer).strip("\n"), labels, phase))
    for part, (body, names, phase) in enumerate(groups):
        purpose = f"{title}: " + ", ".join(dict.fromkeys(names))
        metadata = {
            "definition_group": title,
            "definition_part": part,
            "definition_phase": phase,
            "prerequisite_note": "Run the preceding setup cells in actual notebook order.",
        }
        if extra_metadata:
            metadata.update(extra_metadata)
        if source_name:
            metadata["embedded_module"] = source_name
            metadata["embedded_part"] = part
        text = "# " + purpose + " | Prerequisite: earlier setup cells.\n" + body
        if len(text.splitlines()) > MAX_CODE_LINES:
            layout_exceptions.append(
                {
                    "purpose": purpose,
                    "lines": len(text.splitlines()),
                    "reason": "One top-level definition/literal cannot be split without a source refactor.",
                }
            )
        append_code_cell(text, tags=tags, purpose=purpose, metadata=metadata)
    if source_name:
        embedded_manifest[source_name] = {
            "source_sha256": hashlib.sha256(
                (WORK / source_name).read_bytes()
            ).hexdigest(),
            "semantic_ast_sha256": semantic_digest(source),
            "parts": len(groups),
        }


def embed_module(source_name, title):
    definition_cells(
        (WORK / source_name).read_text(encoding="utf-8"),
        title=title,
        tags=["definitions"],
        source_name=source_name,
    )


def saved_data(name, value, title):
    """Emit readable literal data in bounded cells, never encoded exec strings."""
    statements = []

    def assign(target, item):
        literal = pprint.pformat(item, width=88, sort_dicts=False)
        statement = target + " = " + literal
        # Ruff, not pprint, lays out the final cell; nested literals can grow.
        if (
            len(statement.splitlines()) + 2 <= MAX_CODE_LINES
            and len(format_source(statement).splitlines()) + 2 <= MAX_CODE_LINES
        ):
            statements.append(statement)
        elif isinstance(item, dict):
            statements.append(target + " = {}")
            for key, child in item.items():
                assign(target + "[" + repr(key) + "]", child)
        elif isinstance(item, list):
            statements.append(target + " = []")
            for child in item:
                child_literal = pprint.pformat(child, width=88, sort_dicts=False)
                if len(child_literal.splitlines()) + 3 <= MAX_CODE_LINES:
                    statements.append(target + ".append(" + child_literal + ")")
                else:
                    temporary = "_saved_profile_item_" + str(len(statements))
                    assign(temporary, child)
                    statements.append(
                        target + ".append(" + temporary + ")\ndel " + temporary
                    )
        else:
            raise ValueError(f"Cannot make readable bounded data cell for {target}")

    assign(name, value)
    definition_cells("\n\n".join(statements), title=title, tags=["collapsed-code"])


md("""# Stock crowding: ASX features and index absorption ratio

**A self-contained research notebook. All runnable definitions and tests are embedded here.**

The main path is **stock-index positioning → percentile scores → lagged Spearman change correlation → AR and delta-AR**. Its matrix has at most200 index columns. Stock-level feature/accounting research is optional.

Run all cells for the synthetic machinery checks and a 500-day × 200-index benchmark. Configure the local CSV/Parquet cells for your exports. No network access, data download, credentials, neighboring project or `work/` module is required at runtime.

<details><summary><b>Run order and notebook navigation</b></summary>

Run **Restart Kernel → Run All** from the top. The short, folded setup cells below keep one logical purpose per cell; expand a labeled cell to inspect or edit it. Each definition depends on earlier setup cells. An error identifies that purpose and cell, rather than a single combined source dump.

The first visible result is the matrix plot, followed by the symbolic shortlist and saved timing evidence. **Input contract: local exports** contains the discoverable index configuration and the separate optional stock configuration. The stock-strategy note explains the current long/short selection and execution limits. Adversarial checks and the full literature/review follow their relevant examples.

</details>

**No real market data was supplied. Synthetic examples are tests, not evidence of alpha, timing, capacity or production readiness.** The review scores the submitted bundle; proposed corrections do not retrospectively raise those scores.

| Capability | Implemented | Real-input status |
|---|---|---|
| Index score / AR matrix | 20–200 surviving stock indices | Local CSV/Parquet mapping required |
| GICS2 sector-label summaries | Pooled stock-date coverage/composition from supplied dated labels | No real labels supplied; no validated code parser |
| GICS4 / GICS6 / GICS8 hierarchy | Research methodology only; hierarchy views are not implemented | Detailed codes alone do not enable a view |

<details><summary>Numerical corrections and causal conventions</summary>

- Preserve the actual N×N index correlation matrix, labels and diagonal; retain only the latest matrix to avoid a daily matrix archive.
- Uniform-spectrum AR is k/N, about 20%. Correlation-matrix singular values are used directly, without squaring.
- Exactly 60 lagged changes require 61 score observations ending t−1. Rank changes through time within that window.
- Constant-correlation Ledoit–Wolf shrinkage at N>60 follows the author's estimator; sklearn's different identity target is not substituted.
- Recompute N and k after missing/constant index exclusions. Reject more than 200 columns before quadratic allocation.
- delta-AR uses full 15/252 rolling averages and the full 252-period sample standard deviation of AR levels. Zero dispersion gives missing.
- Distinguish latest-vintage-known-at-decision stock research from the **initial-release-only** index construction.
- Missing future prices cannot change earlier portfolio selection. Missing source sessions remain sessions, not economic zeros.

The defaults retain the requested 60/252 windows. Cohort changes are flagged. MP filtering, a second AR window, return-AR and position-HHI are discussed in the audit; none is silently imposed on the runnable core.

</details>
""")
code(
    """# Warnings are failures in this verification notebook; none are hidden.
import warnings
warnings.simplefilter("error")
import os
os.environ.setdefault("LOKY_MAX_CPU_COUNT", "1")
from IPython import get_ipython
get_ipython().run_line_magic("matplotlib", "inline")
""",
    tags=["warning-gate"],
)

# Embed the already-tested ASX-sized benchmark helpers without CLI/file loading.
benchmark_tree = ast.parse(
    (WORK / "benchmark_asx_scale.py").read_text(encoding="utf-8")
)
helper_names = ["fixture_for", "canonical", "parity", "timed", "memory_sample"]
asx_helpers = "\n\n".join(
    ast.unparse(node)
    for node in benchmark_tree.body
    if isinstance(node, ast.FunctionDef) and node.name in helper_names
)
for name in helper_names:
    asx_helpers = re.sub(r"\b" + name + r"\b", "_asx_" + name, asx_helpers)
asx_helpers = (
    "import gc\n"
    + asx_helpers
    + '''

def run_asx_scale_profile(securities=200):
    """Optional330-history/ten-decision fixture; not a full backfill or alpha test."""
    import sklearn.ensemble
    with threadpool_limits(limits=1):
        lending,calendar,universe,final_universe,fixture=_asx_fixture_for(globals(),securities)
        cfg=Config()
        reference,reference_time=_asx_timed(lambda:_build_feature_panel_reference(lending,calendar,universe,cfg),1,lambda message:None)
        optimized,optimized_time=_asx_timed(lambda:build_feature_panel(lending,calendar,universe,cfg),1,lambda message:None)
        proof=_asx_parity(reference,optimized)
        ref_final,reference_memory=_asx_memory_sample(lambda:_build_feature_panel_reference(lending,calendar,final_universe,cfg))
        opt_final,optimized_memory=_asx_memory_sample(lambda:build_feature_panel(lending,calendar,final_universe,cfg))
        final_proof=_asx_parity(ref_final,opt_final)
    return dict(fixture=fixture,reference_time=reference_time,optimized_time=optimized_time,
                parity=proof,final_decision_parity=final_proof,
                reference_memory=reference_memory,optimized_memory=optimized_memory,
                open_unmeasured=["full330-decision ASX300 backfill","7000-stock vintage backfill","HPC","database"])
'''
)
# Preserve original comments/license text and source order. A later source
# formatter automatically flows through these slices without semantic changes.
matrix_prerequisites = matrix_dependency_names(
    (WORK / "notebook_source.py").read_text(encoding="utf-8")
)
embed_module("notebook_source.py", "Core stock/index definitions")
bootstrap_cells = list(cells)

md("""## Input contract: local exports

Right-hand mapping values below are placeholders for **your actual export column names**, not claimed S&P field identifiers. Preserve immutable initial/as-received vintages and explicit timezones. A row's availability must bound every used field, including denominators and classifications. Do not check a declaration to disguise a final-revised archive.

For ASX stock exports, provide actual exchange sessions with `open_at`, `close_at`, `decision_at`, and **expected_event_date** from the verified delivery-lag contract. Unknown lag is not replaced by the latest delivered date. Point-in-time universe rows must include explicit eligibility and dated GICS. Quantity, shares and price adjustments must agree. Canonical broker_count means a finite nonnegative integer entity count; no rounding is applied and unknown values remain missing. Do not map a vendor average or weighted quantity as this count. Optional borrower fee inputs require declared annual units and fee definitions; ordinal DCBS cannot support fee standard deviation.

The matrix path needs initial-release **aggregate positioning metrics plus scoring sessions only**. Its metric is the equal-stock mean Q/S from the bundle's Positioning theme; a supplied aggregate with that definition enters directly. If you already have the initial-release score matrix in [0,1], pass it directly to `absorption_ratio` and skip re-ranking. Supply rows for all scoring sessions, including missing observations. `expected_event_date` can align a verified release lag. No ADV or market-cap data is invented: the stock aggregation helper accepts the already-computed PIT ADV mask and equal-stock weights.
""")
code(
    """# Fast, price-free index path: fill these paths and actual right-hand names.
INDEX_EXPORTS = {
    "index_metrics_path": None,  # local .csv or .parquet
    "index_metrics_columns": {
        "index_id": "index_id", "event_date": "event_date",
        "available_at": "available_at", "positioning_metric": "positioning_metric",
    },
    "sessions_path": None,
    "sessions_columns": {
        "session": "session", "decision_at": "decision_at", "close_at": "close_at",
        "expected_event_date": "expected_event_date",
    },
    "normalize_252": False,  # if True: own-history252-day z, min_periods252
}
index_input_status = run_index_exports(INDEX_EXPORTS)
print({k:v for k,v in index_input_status.items() if k in ["status","message","missing"]})
# On real success:
# real_scores = index_input_status["scores"]
# real_AR = index_input_status["series"]
# real_matrix = index_input_status["latest_correlation"]
""",
    tags=["configuration"],
    purpose="Configure local initial-release index exports",
)
code(
    """# Optional stock-level reference. This is NOT needed for the index AR path.
STOCK_EXPORTS = {
    "lending_path": None, "sessions_path": None,
    "universe_path": None, "prices_path": None,
    "lending_columns": {
        "security_id":"security_id", "event_date":"event_date", "available_at":"available_at",
        "utilisation":"utilisation", "on_loan":"on_loan", "lendable":"lendable",
        "shares_outstanding":"shares_outstanding", "broker_count":"broker_count",
        # Optional confirmed mappings:
        # "annual_fee":"actual_fee_column", "fee_definition":"fee_definition",
        # "active_lenders":"matched_active_lenders", "total_lenders":"matched_total_lenders",
    },
    "sessions_columns": {k:k for k in ["session","expected_event_date","decision_at","open_at","close_at"]},
    "universe_columns": {k:k for k in ["session","security_id","eligible","gics_sector","available_at",
                                       "borrowable","borrow_available","round_trip_cost_bps"]},
    "prices_columns": {k:k for k in ["session","security_id","open","close"]},
    "vintages_are_as_received": False,
    "row_availability_is_max_input": False,
    "point_in_time_universe": False,
    "consistent_corporate_actions": False,
    "prices_include_distributions": False,
    "fee_unit": None,  # decimal, percent, or bps
    "fee_kind": None,  # actual_borrower, indicative, benchmark
    "borrow_fee_multiplier": None,
}
stock_input_status = run_local_exports(STOCK_EXPORTS, Config())
print({k:v for k,v in stock_input_status.items() if k in ["status","message","missing"]})
""",
    tags=["configuration"],
    purpose="Configure optional local stock research exports",
)

md("""## Embedded adversarial machinery checks

These tests exercise the functions above, not mock behavior. They cover future revisions and reordering, publication cutoffs, full-date and stock gaps, zero history, fee units/regime resets, valid lender ratios, masked minimum observations, ramp/curvature semantics, actual label maturity, no future-outcome selection, signed borrow/cover cash flows, both local file formats, exact spectral benchmarks and all requested matrix edge cases. All tests run without market data.
""")
test_functions = []
test_cases = []
for path in [
    ROOT / "tests" / "test_notebook.py",
    ROOT / "tests" / "test_matrix.py",
    ROOT / "tests" / "test_formula_catalogue.py",
    ROOT / "tests" / "test_stock_optimization_candidate.py",
    ROOT / "tests" / "test_quality_regressions.py",
    ROOT / "tests" / "test_quality_performance_candidate.py",
]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef) or node.name in (
            "api",
            "catalogue_module",
        ):
            continue
        if any(
            (isinstance(decorator, ast.Attribute) and decorator.attr == "fixture")
            or (
                isinstance(decorator, ast.Call)
                and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == "fixture"
            )
            for decorator in node.decorator_list
        ):
            continue
        if node.name.startswith("test_"):
            parameters = [{}]
            for decorator in node.decorator_list:
                if (
                    isinstance(decorator, ast.Call)
                    and isinstance(decorator.func, ast.Attribute)
                    and decorator.func.attr == "parametrize"
                ):
                    names = [
                        s.strip()
                        for s in ast.literal_eval(decorator.args[0]).split(",")
                    ]
                    values = ast.literal_eval(decorator.args[1])
                    parameters = [
                        dict(
                            zip(names, row if isinstance(row, (list, tuple)) else [row])
                        )
                        for row in values
                    ]
            test_cases.extend((node.name, p) for p in parameters)
        node.decorator_list = []
        test_functions.append(ast.unparse(node))
definition_cells(
    "import pytest\nimport tempfile\nimport ast\nfrom types import SimpleNamespace\n\n"
    + "\n\n".join(test_functions),
    title="Adversarial check definitions",
    tags=["embedded-tests"],
)
saved_data("EMBEDDED_TEST_CASES", test_cases, "Adversarial check case list")
code(
    """
def run_embedded_checks():
    import inspect
    results=[]
    namespace=globals()
    with tempfile.TemporaryDirectory(prefix="stock_crowding_checks_") as folder:
        for name,parameters in EMBEDDED_TEST_CASES:
            arguments=dict(parameters)
            if "tmp_path" in inspect.signature(namespace[name]).parameters:
                arguments["tmp_path"]=Path(folder)
            first=SimpleNamespace(**namespace) if "catalogue_module" in inspect.signature(namespace[name]).parameters else namespace
            namespace[name](first,**arguments)
            results.append({"check":name,"status":"passed"})
    return pd.DataFrame(results)

machinery_checks=run_embedded_checks()
print(f"{len(machinery_checks)} adversarial machinery checks passed. No alpha test was performed.")
""",
    tags=["embedded-tests"],
)

md("""## Small stock-pipeline smoke example — SYNTHETIC ONLY

This short fixture deliberately uses smaller history settings to exercise the code quickly; actual research defaults remain in `Config()` (250/200 observations and the original horizon grid). Synthetic weekdays are not asserted to be a true ASX holiday calendar. This cell demonstrates input/output plumbing, not signal performance. It does not enable the optional model tournament or new candidates.

**What the current stock strategy does.** The selection is mirrored: the long leg takes the lowest scores and the short leg takes the highest scores. Short feasibility and entry borrow-cost treatment differ by leg. Holdings follow the fixed holding/execution schedule; this is not a learned buy/sell-model pair, dynamic stop/exit policy or integrated recall engine.

`borrow_available > 0` is a feasibility flag, not a firm locate for the intended order size. High short-lending crowding does not automatically define an implementable short: fees and recall tail risk remain relevant. The standalone cover helper is not connected to a dynamic portfolio recall process. Low short-lending crowding likewise does not establish crowded long ownership. No fees, locates or tuned asymmetric machine-learning policies are invented in this demonstration.
""")
code(
    """smoke_inputs=synthetic_inputs(sessions_count=35,securities_count=8,seed=11)
smoke_config=Config(window=10,min_observations=8,ema_min_observations=10,
                    half_lives=(1,2,4),horizon=3,minimum_train_sessions=10)
smoke_result=run_analysis(**smoke_inputs,config=smoke_config,mode="SYNTHETIC MACHINERY ONLY")
print({"feature_rows":len(smoke_result["features"]),"label_rows":len(smoke_result["labels"]),
       "leg_rows":len(smoke_result["legs"]),"synthetic_only":True})
display(HTML("<details><summary>Stock-pipeline numerical preview and pooled-slice convention</summary>"+
             smoke_result["features"][["session","security_id","baseline","overlay","flow_fallback"]].tail(8).to_html(index=False)+
             "<p>stock_slices pools stock-date rows across the sample; no daily hierarchy, equal-date averaging or sector performance.</p></details>"))
""",
    tags=["collapsed-code"],
)

md("""## Matrix demonstration and runtime benchmark — SYNTHETIC ONLY

The following is the main executable matrix workflow. It uses 500 sessions and 200 stock-index columns, retains the latest actual 200×200 correlation matrix and reports wall-clock time. It stores no full history of matrices and performs no feature/model search. Its values are random test inputs; spikes are not evidence of fragility in real stocks.

**Prerequisite:** run the short folded setup/contracts and matrix-kernel cells immediately above. Stock feature, accounting, catalogue and profiler definitions are placed after this plot and are not required for this demonstration. The remaining sections still run top-to-bottom before their examples or configuration cells.

The uniform-spectrum k/N line is an **ideal algebraic reference**, not the expected AR of independent finite samples. Estimation with200indices and60changes can produce substantial spectral concentration even with independent inputs. The delta-AR ±1lines are uncalibrated reference levels, not validated trading alarms.
""")
code(
    """import time
if "absorption_ratio" not in globals():
    raise RuntimeError("Run the preceding folded core definition cells before the matrix demonstration.")
rng=np.random.default_rng(2026)
matrix_dates=pd.bdate_range("2020-01-02",periods=500)
synthetic_metrics=pd.DataFrame(rng.lognormal(size=(500,200)),index=matrix_dates,
                               columns=[f"SYNTH_STOCK_INDEX_{i:03d}" for i in range(200)])
started=time.perf_counter()
synthetic_scores=index_crowding_scores(synthetic_metrics)
matrix_demo=absorption_ratio(synthetic_scores)
matrix_runtime_seconds=time.perf_counter()-started
matrix_benchmark={"mode":"SYNTHETIC MACHINERY ONLY","days":500,"indices":200,
                  "seconds":matrix_runtime_seconds,"valid_AR":int(matrix_demo["series"].AR.notna().sum()),
                  "valid_delta_AR":int(matrix_demo["series"].delta_AR.notna().sum()),
                  "latest_matrix_shape":list(matrix_demo["latest_correlation"].shape),
                  "alpha_validated":False}
figure,axes=plt.subplots(1,3,figsize=(16,4))
figure.suptitle("SYNTHETIC machinery demonstration — no real stock-market inference",fontsize=12)
matrix_demo["series"].AR.plot(ax=axes[0],label="Score-change absorption ratio",color="#166b87")
matrix_demo["series"].uniform_baseline.plot(ax=axes[0],label="Uniform spectrum k/N (ideal reference)",color="#a45b12",linestyle="--")
axes[0].set_title("Stock-index crowding concentration"); axes[0].set_ylabel("Variance share"); axes[0].legend(fontsize=8)
matrix_demo["series"].delta_AR.plot(ax=axes[1],title="Delta-AR: full 252-session baseline",color="#3659a3")
axes[1].set_ylabel("Standardised AR shift")
axes[1].axhline(1,color="grey",linestyle="--",label="Uncalibrated ±1 reference"); axes[1].axhline(-1,color="grey",linestyle="--")
axes[1].legend(fontsize=8)
for axis in axes[:2]:
    axis.set_xlim(matrix_dates[0],matrix_dates[-1]); axis.grid(alpha=.2)
heat=axes[2].imshow(matrix_demo["latest_correlation"].to_numpy(),vmin=-1,vmax=1,cmap="coolwarm")
axes[2].set_title("Latest 200 × 200 index correlation"); axes[2].set_xlabel("Stock index"); axes[2].set_ylabel("Stock index")
figure.colorbar(heat,ax=axes[2],label="Spearman correlation"); figure.tight_layout(); plt.show()
from IPython.display import HTML
print(f"SYNTHETIC: {matrix_runtime_seconds:.3f}s for500days×200indices; "
      f"{matrix_benchmark['valid_AR']} valid AR / {matrix_benchmark['valid_delta_AR']} valid delta-AR observations.")
display(HTML("<details><summary>Matrix diagnostics: latest eight sessions</summary>"+
             matrix_demo["series"].tail(8).to_html()+"</details>"))
""",
    tags=["demo", "collapsed-code"],
    purpose="Main synthetic index-score, absorption-ratio and correlation plots",
)
code(
    """# Optional exports go to a new, explicit output folder in this notebook's working directory.
OUTPUT_DIR=Path.cwd()/"crowding_outputs"
OUTPUT_DIR.mkdir(exist_ok=True)
synthetic_scores.to_parquet(OUTPUT_DIR/"synthetic_index_scores.parquet")
matrix_demo["series"].to_parquet(OUTPUT_DIR/"synthetic_AR.parquet")
matrix_demo["latest_correlation"].to_parquet(OUTPUT_DIR/"synthetic_latest_correlation.parquet")
(OUTPUT_DIR/"synthetic_run_summary.json").write_text(json.dumps(matrix_benchmark,indent=2),encoding="utf-8")
print("Synthetic outputs:",OUTPUT_DIR.resolve())
""",
    tags=["collapsed-code"],
)

md("""## Formulaic-alpha shortlist — symbolic only

The full 10 × 14 × 6 grid is retained with rejection reasons. Six archetypes are dimensionally valid under the supplied global-series/per-index distinction. Four literal archetypes are rejected: scalar cross-sectional ranks/divergence/neutralisation, and decay's conflicting one-day inner delta. Fixed-252 level duplicates are deduplicated. Binary constructions use the disclosed fixed `crowd_i` partner; no partner search occurs.

Rank mean is mechanically fixed for fixed N. Rank standard deviation and skewness can change with ties and therefore remain conditional, with cohort/tie warnings. Neither data-artifact invariance nor syntactic novelty proves an economic edge. Positive statements below are hypotheses to investigate, not expected-return estimates. The requested survivor count is reported as found, not forced into 100–200.
""")
embed_module("formula_catalogue.py", "Symbolic formula definitions")
code(
    """from IPython.display import HTML
formula_research=build_formula_catalogue()
formula_metadata=formula_research["metadata"]
print({key:formula_metadata[key] for key in ["catalogue_rows","survivor_count","top_count","status_counts",
       "mean_pairwise_ast_overlap","overlap_threshold_flag","numeric_execution"]})
print("All candidates are disabled symbolic research. AST overlap is not empirical correlation.")
print(formula_metadata["partner_policy"])
preview=formula_research["top30"][["#","Formula","Orthogonality score"]].head(5)
display(preview)
full_top=formula_research["top30"][["#","Formula","Interpretation","Fragility mode","Orthogonality score"]]
display(HTML("<details><summary><b>Open the complete requested top30 table</b></summary>"+
             full_top.to_html(index=False,escape=True)+"</details>"))
display(HTML("<details><summary>Open operator semantics, causal lags and research references</summary><pre>"+
             __import__("html").escape(RESEARCH_NOTES)+"</pre></details>"))
formula_research["all_candidates"].to_csv(OUTPUT_DIR/"formula_catalogue_840.csv",index=False)
formula_research["survivors"].to_csv(OUTPUT_DIR/"formula_symbolic_survivors.csv",index=False)
full_top.to_csv(OUTPUT_DIR/"formula_top30.csv",index=False)
(OUTPUT_DIR/"formula_catalogue_summary.json").write_text(json.dumps(formula_metadata,indent=2),encoding="utf-8")
""",
    tags=["collapsed-code"],
    purpose="Generate symbolic catalogue and preview shortlist",
)

md("""## Measured stage costs — synthetic local fixtures

The primary tables compare the actual archived **pre-repair/pre-batch public function** with the current **repaired and batched public function**, using identical valid synthetic inputs and default configuration. This combines correctness repairs and optimization; it does not isolate their individual effects. Each implementation runs once in a fresh process, with ordinary wall/CPU time and pre/post process RSS. Process-lifetime peak RSS includes imports, fixture preparation and output; it is not additional traced allocation.

Paired full330-decision backfills use the original8-stock stage fixture and the200-stock revision/omission fixture. FullASX300backfills, full7,000-stock feature backfills, real vintage-heavy exports, database transfer/query plans and HPC parallel scaling remain **OPEN / unmeasured**. The direct200-index matrix is the bounded default path. The stock path prepares parsed input/index tables once per invocation and reuses immutable EMA geometry; decision-time values, masks and vintage selections remain fresh.

Earlier stage and reference/prepared measurements remain explicitly historical below. They retain their original source digest, fixture scope and memory method; they are not relabeled as current-source results. No table is an end-to-end production certificate.
""")
embed_module("profile_stages.py", "Optional stage profiler definitions")
definition_cells(
    asx_helpers, title="Optional ASX benchmark helper definitions", tags=["definitions"]
)
runtime_source_sha256 = hashlib.sha256(
    (WORK / "notebook_source.py").read_bytes()
).hexdigest()
archived_source_sha256 = hashlib.sha256(
    (WORK / "code_quality_baseline.py").read_bytes()
).hexdigest()


def verified_quality_report(relative_path):
    report = json.loads((WORK / relative_path).read_text(encoding="utf-8"))
    if (
        report.get("status") != "measured"
        or report.get("current_source_sha256") != runtime_source_sha256
        or report.get("baseline_source_sha256") != archived_source_sha256
        or not report.get("source_hashes_unchanged_after_all_cases")
    ):
        raise RuntimeError(
            f"Archived/current public benchmark is incomplete or source-stale: {relative_path}"
        )
    for workload in report["workloads"]:
        for key, expected in [
            ("archived_public", archived_source_sha256),
            ("current_public", runtime_source_sha256),
        ]:
            measured = workload[key]
            if (
                measured["source_sha256"] != expected
                or measured["source_sha256_after"] != expected
            ):
                raise RuntimeError(
                    f"Worker source provenance mismatch: {relative_path}, {key}"
                )
        if (
            not workload.get("fixture_and_default_config_match")
            or not workload["output_parity"]["passed"]
        ):
            raise RuntimeError(
                f"Benchmark fixture/parity verification failed: {relative_path}"
            )
    return report


quality_profiles = {
    "Ten-decision ASX-sized comparison": verified_quality_report(
        "code_quality_benchmark/benchmark.json"
    ),
    "Full330-decision comparison": verified_quality_report(
        "code_quality_benchmark_full/benchmark.json"
    ),
}
quality_summary = {}
for label, report in quality_profiles.items():
    compact = {
        key: report[key]
        for key in ("scope", "baseline_source_sha256", "current_source_sha256")
    }
    compact["workloads"] = []
    for workload in report["workloads"]:
        before = workload["archived_public"]
        after = workload["current_public"]
        compact["workloads"].append(
            {
                "stocks": workload["stocks"],
                "archived_public": {
                    "ordinary_wall_seconds": before["ordinary_wall_seconds"],
                    "process_lifetime_peak_rss_bytes": before[
                        "process_lifetime_peak_rss_bytes"
                    ],
                },
                "current_public": {
                    key: after[key]
                    for key in (
                        "ordinary_wall_seconds",
                        "process_lifetime_peak_rss_bytes",
                        "decision_dates",
                        "feature_rows",
                    )
                }
                | {
                    "fixture": {
                        "history_sessions": after["fixture"]["history_sessions"]
                    }
                },
                "observed_combined_speedup_this_fixture_only": workload[
                    "observed_combined_speedup_this_fixture_only"
                ],
                "output_parity": {
                    "maximum_absolute_numeric_difference": workload["output_parity"][
                        "maximum_absolute_numeric_difference"
                    ],
                    "compared_columns": workload["output_parity"]["compared_columns"],
                },
            }
        )
    quality_summary[label] = compact
saved_data("QUALITY_PROFILES", quality_summary, "Compact paired public measurements")
code(
    """
quality_rows=[]
for workload_name,report in QUALITY_PROFILES.items():
    for workload in report['workloads']:
        before=workload['archived_public']
        after=workload['current_public']
        quality_rows.append({
            'workload':workload_name,'stocks':workload['stocks'],
            'history_sessions':after['fixture']['history_sessions'],
            'decisions':after['decision_dates'],'rows':after['feature_rows'],
            'archived_public_s':before['ordinary_wall_seconds'],
            'current_public_s':after['ordinary_wall_seconds'],
            'combined_speedup':workload['observed_combined_speedup_this_fixture_only'],
            'archived_peak_RSS_MiB':before['process_lifetime_peak_rss_bytes']/2**20,
            'current_peak_RSS_MiB':after['process_lifetime_peak_rss_bytes']/2**20,
            'max_abs_numeric_difference':workload['output_parity']['maximum_absolute_numeric_difference'],
        })
display(pd.DataFrame(quality_rows)[['stocks','history_sessions','decisions','archived_public_s',
                                   'current_public_s','combined_speedup']])
print('One ordinary call per fresh process. Valid-data parity does not exercise every new rejection path.')
print('Parity excludes columns the 2026-10-30 methodology fixes deliberately add or change; saved records list their differences.')
print('Combined correctness-repair plus optimization comparison; no isolated optimization attribution.')
display(HTML('<details><summary>Compact source-bound measurement records</summary><pre>'+
             __import__('html').escape(json.dumps(QUALITY_PROFILES,indent=2))+'</pre></details>'))
""",
    tags=["collapsed-code"],
    purpose="Compare current and actual archived public stock pipelines",
)
md(
    "<details>\n<summary>Full saved evidence: hashes, fixtures, Config, CPU, RSS and limits</summary>\n\n<pre>"
    + html.escape(json.dumps(quality_profiles, indent=2))
    + "</pre>\n</details>"
)
profile = json.loads(
    (WORK / "performance" / "stage_profile.json").read_text(encoding="utf-8")
)
saved_data("STAGE_PROFILE", profile, "Saved stage measurements")
code(
    """
stage_table=pd.DataFrame(STAGE_PROFILE["measurements"])
print('HISTORICAL stage profile: retain original fixture, timing and traced-memory scopes; not current-source certification.')
selected=["Full stock feature reference","Stock-leg accounting scenarios","Sparse stock/index aggregation",
          "Full Spearman/shrinkage/SVD AR","Formula catalogue and AST: first call","Formula catalogue and AST: warm"]
display(stage_table.loc[stage_table.stage.isin(selected),["stage","median_seconds","timing_label","python_traced_peak_MiB"]])
display(HTML("<details><summary>All stage dimensions, samples and execution context</summary>"+
             stage_table.to_html(index=False)+"<pre>"+__import__("html").escape(json.dumps(
                 {k:v for k,v in STAGE_PROFILE.items() if k!="measurements"},indent=2))+"</pre></details>"))
RUN_STAGE_PROFILE=False  # optional: slow full reference backfill, plus separate memory pass
if RUN_STAGE_PROFILE:
    fresh_stage_profile=run_stage_profile(globals(),OUTPUT_DIR/"performance")
""",
    tags=["definitions"],
)
asx_profile = json.loads(
    (WORK / "asx_scale_benchmark" / "benchmark.json").read_text(encoding="utf-8")
)
saved_data(
    "ASX_SCALE_PROFILE",
    asx_profile,
    "Historical reference/prepared ASX-sized comparison",
)
code(
    """
asx_rows=[]
print('HISTORICAL reference/prepared comparison at source '+ASX_SCALE_PROFILE['source_sha256']+
      '; this is not the current public-versus-archived-public comparison above.')
for workload in ASX_SCALE_PROFILE["workloads"]:
    asx_rows.append({"stocks":workload["fixture"]["securities"],
                     "history":workload["fixture"]["history_sessions"],
                     "decisions":workload["fixture"]["evaluation_decisions"],
                     "reference_s":workload["baseline"]["wall_median_seconds"],
                     "prepared_s":workload["candidate"]["wall_median_seconds"],
                     "max_abs_diff":workload["parity"]["maximum_absolute_numeric_difference"],
                     "reference_MiB*":workload["baseline_memory_one_decision"]["additional_traced_peak_MiB"],
                     "prepared_MiB*":workload["candidate_memory_one_decision"]["additional_traced_peak_MiB"]})
display(pd.DataFrame(asx_rows))
print("One ordinary timing call per workload; memory is a separate one-decision call, not ten-decision/RSS peak.")
display(HTML("<details><summary>ASX-sized fixture revisions, omissions, source digest and context</summary><pre>"+
             __import__("html").escape(json.dumps(ASX_SCALE_PROFILE,indent=2))+"</pre></details>"))
RUN_ASX_SCALE_PROFILE=False
if RUN_ASX_SCALE_PROFILE:
    print('Optional CURRENT preparation-reference comparator; distinct from the archived-public comparison.')
    fresh_asx_profile=run_asx_scale_profile(securities=200)
""",
    tags=["definitions"],
)
full_asx_profile = json.loads(
    (WORK / "performance" / "full_asx200_benchmark.json").read_text(encoding="utf-8")
)
if (
    full_asx_profile.get("status") != "measured"
    or full_asx_profile["source_sha256"] != runtime_source_sha256
    or full_asx_profile.get("source_sha256_after") != runtime_source_sha256
):
    raise RuntimeError("Full ASX200 benchmark does not describe the frozen runtime.")
saved_data("FULL_ASX200_PROFILE", full_asx_profile, "Saved full ASX 200 profile")
code(
    """
print(f"Independent FULL synthetic ASX200 backfill: {FULL_ASX200_PROFILE['decision_dates']} decisions × "
      f"{FULL_ASX200_PROFILE['stocks']} stocks = {FULL_ASX200_PROFILE['feature_rows']:,} feature rows; "
      f"{FULL_ASX200_PROFILE['ordinary_wall_seconds']:.2f}s ordinary wall time.")
print(f"Process peak working set: {FULL_ASX200_PROFILE['process_peak_rss_bytes']/2**20:.1f}MiB "
      "including imports, fixture, preparation and outputs; not the additional traced allocation above.")
display(HTML("<details><summary>Full-backfill timing, CPU, memory, source hash and limitations</summary><pre>"+
             __import__("html").escape(json.dumps(FULL_ASX200_PROFILE,indent=2))+"</pre></details>"))
# Optional slow reproduction using the same revision/omission lending construction.
RUN_FULL_ASX200_BACKFILL=False
if RUN_FULL_ASX200_BACKFILL:
    full_fixture=synthetic_inputs(sessions_count=330,securities_count=200,seed=741)
    revised_lending,full_calendar,_,_,_=_asx_fixture_for(globals(),200)
    started=time.perf_counter()
    with threadpool_limits(limits=1):
        full_features=build_feature_panel(revised_lending,full_calendar,full_fixture["universe"],Config())
    print({"ordinary_wall_seconds":time.perf_counter()-started,"feature_rows":len(full_features),"synthetic_only":True})
""",
    tags=["definitions"],
)

md("""## Acceptance summary

| Requirement | Artifact/check | Status |
|---|---|---|
| Stock-only S&P Global broker/lending scope | Explicit mappings, no fetched feeds | Configurable; actual vendor schema unverified |
| GICS capability | Supplied sector labels; pooled stock-date summaries |2/4/6/8research consult fulfilled;4/6/8views not implemented |
| Four-pass review and all requested audit supplements | Folded review below | Included; no empirical validation |
| Self-contained runtime and tests | Embedded definition/test cells | No work-folder imports |
| Matrix / timing / shrinkage |60lagged changes, full252 baseline, constant-correlation target, SVD | Adversarial checks and200-index benchmark |
| Missing data / revisions / close cutoff | Vintage, outage, future-label and after-close regressions | Tested on controlled fixtures |
| Stock preparation efficiency | Archived/current public parity at200/300ten decisions and8/200full330decisions, excluding columns deliberately changed by the 2026-10-30 fixes | Measured wall/CPU and process RSS; ASX300fullbackfill/7000/HPC/DB OPEN |
|840slots / top30 / diversity | Each row has formula, mechanism and expected_fragility_mode; typed ASTscreen | Symbolic only; no performance claim |
| Parameter fragility review | Analytical +/-10% and +/-20% reasoning; proposed validation protocol | Analytical request fulfilled; full proposed sensitivity validation not run |
| Holdout and portfolio integration | Mature-label checks; standalone cover ledger; optional predictions | Untouched purged holdout and cover/candidate/model leg integration absent |
| Spectral vocabulary / OptionsAandB |14symbolic names fulfill generation scope; reviewed conditional A/B | No numeric extractor requested/implemented; A/B remain review-only |
| Real paid costs, locates, source vintages and capacity | Local external acceptance gates | Not independently validated |

The broader original design is not fully implemented. The coverage ledger below distinguishes implemented machinery, standalone tests, protocols and reviewed-only constructions; documenting an outstanding stage does not complete it. Detailed methodology and literature remain folded below.
""")
for title, name in [
    ("Implementation decisions and limitations", "packaging_notes.md"),
    ("Code-quality repairs, public-path comparison and scope", "code_quality_notes.md"),
    (
        "Requirement coverage: implemented, protocol-only and outstanding stages",
        "requirement_coverage.md",
    ),
    (
        "Full four-pass framework review, feature audits and later supplements",
        "framework_review.md",
    ),
    (
        "Failure-mode literature for each of the ten formula archetypes",
        "archetype_literature.md",
    ),
    ("Stock indices, sectors, bounded signals and matrix research", "research.md"),
]:
    md(
        "<details>\n<summary><b>"
        + title
        + "</b></summary>\n\n"
        + (WORK / name).read_text(encoding="utf-8")
        + "\n\n</details>"
    )
md("""## Completion boundary

The executable checks and benchmark establish engineering behavior on controlled fixtures. They do not establish source vintage truth, actual paid borrow, executable capacity, predictive efficacy, or the claimed score-AR→return-AR lead. The stock accounting is a declared cost scenario, not an audited execution ledger. Real schema names, ASX source-cutoff schedule, actual baseline convention, and data quality remain local configuration requirements.

An untouched purged holdout and end-to-end forced-cover/optional-signal portfolio comparisons remain outstanding implementation stages. The requested analytical sensitivity review is fulfilled; the full proposed executed sensitivity validation has not been run. The14spectral names fulfill symbolic-generation scope, not an explicitly requested numeric extractor. Return-AR and position-HHI are reviewed conditional constructions without runnable paths. No flawless, globally near-optimal or universally statistically validated status is claimed.

The notebook contains the requested initial four-pass review, ratio/feature/covariance/universe/spectral/non-stationarity supplements, simple stock-crowding candidates, index/sector research, all runtime definitions and all adversarial tests. Additional data or spectral filters are not mandatory for the price-free index-matrix path.
""")


# Present the executable matrix and symbolic shortlist before local setup and
# optional stock research; definitions/tests remain embedded and discoverable.
def section(prefix):
    start = next(
        i
        for i, c in enumerate(cells)
        if c.cell_type == "markdown" and c.source.startswith(prefix)
    )
    end = next(
        (
            i
            for i in range(start + 1, len(cells))
            if cells[i].cell_type == "markdown" and cells[i].source.startswith("## ")
        ),
        len(cells),
    )
    return cells[start:end]


front = [
    cell
    for cell in bootstrap_cells
    if cell.metadata.get("definition_phase") != "core-after-matrix"
]
core_after_matrix = [
    cell
    for cell in bootstrap_cells
    if cell.metadata.get("definition_phase") == "core-after-matrix"
]
ordered = [
    section("## Matrix demonstration"),
    core_after_matrix,
    section("## Formulaic-alpha shortlist"),
    section("## Measured stage costs"),
    section("## Input contract"),
    section("## Small stock-pipeline"),
    section("## Embedded adversarial"),
]
used = {id(c) for block in [front] + ordered for c in block}
cells = (
    front
    + [c for block in ordered for c in block]
    + [c for c in cells if id(c) not in used]
)
oversized_cells = [
    {
        "cell": index,
        "purpose": cell.metadata.get("purpose"),
        "lines": len(cell.source.splitlines()),
    }
    for index, cell in enumerate(cells)
    if cell.cell_type == "code" and len(cell.source.splitlines()) > MAX_CODE_LINES
]
if oversized_cells:
    raise RuntimeError(
        f"Code cells exceed the99-line limit; split source definitions before packaging: {oversized_cells}"
    )
notebook = nbf.v4.new_notebook(cells=cells)
notebook.metadata.update(
    kernelspec={"display_name": "Python 3", "language": "python", "name": "python3"},
    language_info={"name": "python", "version": "3.13"},
    stock_crowding={
        "scope": "stocks only",
        "self_contained": True,
        "alpha_validated": False,
        "test_cases": len(test_cases),
        "runtime_source_sha256": runtime_source_sha256,
        "embedded_source_manifest": embedded_manifest,
        "matrix_prerequisites": sorted(matrix_prerequisites),
        "layout_line_target": MAX_CODE_LINES,
        "layout_exceptions": layout_exceptions,
        "historical_asx_benchmark_sha256": hashlib.sha256(
            (WORK / "asx_scale_benchmark" / "benchmark.json").read_bytes()
        ).hexdigest(),
        "quality_benchmark_sha256": hashlib.sha256(
            (WORK / "code_quality_benchmark" / "benchmark.json").read_bytes()
        ).hexdigest(),
        "quality_full_benchmark_sha256": hashlib.sha256(
            (WORK / "code_quality_benchmark_full" / "benchmark.json").read_bytes()
        ).hexdigest(),
    },
)
nbf.validate(notebook)
target = ROOT / "ASX_Crowding_Framework.ipynb"
nbf.write(notebook, target)
print(
    json.dumps(
        {
            "notebook": str(target),
            "cells": len(cells),
            "embedded_checks": len(test_cases),
            "bytes": target.stat().st_size,
            "layout_exceptions": layout_exceptions,
        }
    )
)
