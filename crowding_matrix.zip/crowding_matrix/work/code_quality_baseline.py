# %% Imports and contracts
from pathlib import Path
from dataclasses import dataclass, replace
import json
import math
import warnings
import numpy as np
import pandas as pd
from scipy.stats import norm
import matplotlib.pyplot as plt

class InputError(ValueError):
    """An actionable input-contract error, never silently replaced by demo data."""

@dataclass(frozen=True)
class Config:
    half_lives: tuple = (1,2,4,8,16,32,64,128)
    window: int = 250
    min_observations: int = 200
    ema_min_observations: int = 250
    kappa: float = .5
    clip_quantiles: tuple = (.01,.99)
    change_window: int = 20
    horizon: int = 20
    leg_fraction: float = .2
    minimum_train_sessions: int = 252
    refit_sessions: int = 126
    run_research_models: bool = False
    use_optional_signals: bool = False
    # All signs are declared research orientations, not recovered user settings.
    theme_signs: tuple = (1.,1.,1.)

def utc_timestamp(value, name='timestamp'):
    stamp=pd.Timestamp(value)
    if pd.isna(stamp) or stamp.tzinfo is None:
        raise InputError(f'{name} requires an explicit timezone/UTC offset.')
    return stamp.tz_convert('UTC')

def utc_series(values, name='available_at'):
    if isinstance(values.dtype,pd.DatetimeTZDtype):
        if values.isna().any(): raise InputError(f'{name} contains a missing timestamp.')
        return values.dt.tz_convert('UTC')
    return pd.Series([utc_timestamp(v,name) for v in values],index=values.index,dtype='datetime64[ns, UTC]')

def load_table(path, mapping):
    """mapping is canonical_name -> actual export column, never a guessed vendor schema."""
    if (not isinstance(mapping,dict) or not mapping or
        any(not isinstance(k,str) or not k or not isinstance(v,str) or not v for k,v in mapping.items()) or
        len(set(mapping.values()))!=len(mapping)):
        raise InputError('Supply a nonempty, one-to-one canonical-to-export column map.')
    path=Path(path)
    if not path.is_file():
        raise InputError(f'Input file not found: {path}')
    columns=list(mapping.values())
    try:
        if path.suffix.lower()=='.csv':
            import csv
            with path.open(encoding='utf-8-sig',newline='') as stream:
                header=next(csv.reader(stream),[])
            if any(header.count(column)>1 for column in columns):
                raise InputError('Mapped CSV header is ambiguous: duplicate source column names.')
            identifiers={v:'string' for k,v in mapping.items() if k.endswith('_id')}
            frame=pd.read_csv(path,usecols=columns,dtype=identifiers)
        elif path.suffix.lower() in ('.parquet','.pq'):
            frame=pd.read_parquet(path,columns=columns)
        else:
            raise InputError('Supported local input types: .csv, .parquet, .pq')
    except ValueError as error:
        raise InputError(f'Cannot read mapped export columns: {error}') from error
    if set(columns)-set(frame.columns):
        raise InputError('Export lacks mapped data columns; a Parquet index is not a data column.')
    return frame[list(mapping.values())].rename(columns={v:k for k,v in mapping.items()})

def canonical_fee(values, unit):
    factors={'decimal':1.,'percent':.01,'bps':.0001}
    if unit not in factors:
        raise InputError('Fee unit must be decimal, percent or bps; DCBS is ordinal, not a rate.')
    result=pd.to_numeric(values,errors='raise')*factors[unit]
    if (result.dropna()<0).any() or np.isinf(result.dropna()).any():
        raise InputError('Negative/invalid fee: reconcile fee versus rebate before use.')
    return result

def lender_fraction(active,total):
    a=pd.to_numeric(active,errors='raise'); n=pd.to_numeric(total,errors='raise')
    valid=a.notna() & n.notna()
    invalid=valid & ((a<0)|(n<0)|(a>n)|(a%1!=0)|(n%1!=0)|~np.isfinite(a)|~np.isfinite(n))
    if invalid.any():
        raise InputError('Invalid matched lender counts: require integer 0 <= active <= total.')
    return (a/n.where(n>0)).where(valid)

def _validate_broker_counts(values):
    """Validate entity counts without rounding or turning unknowns into zero."""
    counts=pd.to_numeric(values,errors='raise').dropna().to_numpy(dtype=float)
    if (not np.isfinite(counts).all() or (counts<0).any() or
        (counts!=np.floor(counts)).any()):
        raise InputError('broker_count requires finite nonnegative integers; fractional values are not rounded.')

def history_asof(frame,decision_at):
    required={'security_id','event_date','available_at'}
    if not required.issubset(frame):
        raise InputError(f'Lending history requires {sorted(required)}')
    decision=utc_timestamp(decision_at,'decision_at')
    data=frame.copy()
    data['security_id']=data.security_id.astype(str)
    data['event_date']=pd.to_datetime(data.event_date,errors='raise').dt.normalize()
    if data.event_date.dt.tz is not None:
        raise InputError('event_date must be a local ASX session date without a timezone.')
    data['available_at']=utc_series(data.available_at)
    local_day=decision.tz_convert('Australia/Sydney').tz_localize(None).normalize()
    data=data.loc[(data.available_at<=decision)&(data.event_date<=local_day)]
    keys=['security_id','event_date','available_at']
    # A timestamp tie has no principled file-order winner.
    duplicated=data.loc[data.duplicated(keys,keep=False)]
    for _,group in duplicated.groupby(keys,sort=False,observed=True):
        if len(group.drop_duplicates())>1:
            raise InputError('Conflicting values at the same security/event_date/available_at; resolve the source conflict.')
    return (data.drop_duplicates().sort_values(keys)
            .drop_duplicates(['security_id','event_date'],keep='last')
            .sort_values(['security_id','event_date']).reset_index(drop=True))

# %% Causal kernels and fixed transforms
def ema_contrasts(values,half_lives=(1,2,4,8,16,32,64,128),min_count=250):
    """Finite, weight-normalized causal kernels; NaNs preserve calendar distance."""
    x=np.asarray(values,dtype=float)
    valid=np.isfinite(x); count=int(valid.sum())
    if count<min_count:
        return np.nan,np.nan,count
    h=np.asarray(half_lives,dtype=float)
    if len(h)<3 or np.any(h<=0) or np.any(np.diff(h)<=0):
        raise InputError('Half-lives require at least3 increasing positive values.')
    ages=np.arange(len(x)-1,-1,-1,dtype=float)
    weights=np.exp2(-ages[None,:]/h[:,None])*valid[None,:]
    curve=(weights@np.where(valid,x,0.))/weights.sum(axis=1)
    u=np.log2(h); u=(u-u.mean())
    linear=u/np.linalg.norm(u)
    quadratic=u*u; quadratic-=quadratic.mean()
    quadratic-=linear*np.dot(linear,quadratic)
    quadratic/=np.linalg.norm(quadratic)
    return float(-linear@curve),float(quadratic@curve),count

def trailing_moments(values,window=250,min_observations=200,regimes=None):
    x=np.asarray(values,dtype=float)[-window:].copy()
    if regimes is not None:
        r=np.asarray(regimes,dtype=object)[-window:]
        if len(r)!=len(x) or len(r)==0 or pd.isna(r[-1]):
            x[:]=np.nan
        else:
            changes=np.flatnonzero((r[:-1]!=r[1:])|pd.isna(r[:-1]))
            if len(changes): x[:changes[-1]+1]=np.nan
    valid=x[np.isfinite(x)]; count=len(valid)
    okay=count>=min_observations and count>=2
    return {'mean':float(valid.mean()) if okay else np.nan,
            'std':float(valid.std(ddof=1)) if okay else np.nan,
            'count':count,'span':len(x)}

def cross_section(values,clip_quantiles=(.01,.99)):
    """Same-decision eligible cohort only; midranks keep ties and constants finite."""
    x=pd.to_numeric(values,errors='coerce').replace([np.inf,-np.inf],np.nan)
    valid=x.notna(); n=int(valid.sum()); result=pd.Series(np.nan,index=x.index,dtype=float)
    if n==0: return result
    if not 0<=clip_quantiles[0]<clip_quantiles[1]<=1:
        raise InputError('Invalid clipping quantiles.')
    q=x.loc[valid].quantile(list(clip_quantiles))
    clipped=x.loc[valid].clip(q.iloc[0],q.iloc[1])
    result.loc[valid]=norm.ppf((clipped.rank(method='average')-.5)/n)
    return result

def finite_z(values):
    x=pd.Series(values,dtype=float)
    sd=x.std(ddof=0)
    if not np.isfinite(sd) or sd==0:
        return x.where(x.isna(),0.)
    return (x-x.mean())/sd

def fixed_overlay(frame):
    columns=['scarcity_flow','positioning_flow','participation_flow']
    return frame.reindex(columns=columns).fillna(0.).sum(axis=1)/3.

# %% Chronological labels and stock cash flows
def mature_labels(labels,fit_at):
    cutoff=utc_timestamp(fit_at,'fit_at')
    present=labels.label_available_at.notna()
    result=pd.Series(False,index=labels.index)
    result.loc[present]=utc_series(labels.loc[present,'label_available_at'],'label_available_at')<=cutoff
    return result

def position_return(entry,exit,side,annual_fee,calendar_days,round_trip_cost_bps):
    if entry<=0 or exit<0 or not np.isfinite([entry,exit,calendar_days,round_trip_cost_bps]).all():
        raise InputError('Prices, duration and execution cost must be finite, with positive entry price.')
    if side not in (-1,1) or calendar_days<0 or round_trip_cost_bps<0:
        raise InputError('Invalid stock position/accounting convention.')
    if side==-1 and (not np.isfinite(annual_fee) or annual_fee<0):
        raise InputError('A short requires an annual borrower fee; missing is not free borrow.')
    borrow=annual_fee*calendar_days/365. if side==-1 else 0.
    return side*(exit/entry-1.)-borrow-round_trip_cost_bps/10000.

def cover_ledger(prices,cover_index=None,reenter_index=None):
    """One short share, cash proceeds/covers/re-entry; no arbitrary nine-day haircut."""
    p=np.asarray(prices,dtype=float)
    if len(p)<2 or np.any(~np.isfinite(p)) or np.any(p<=0):
        raise InputError('Cover ledger requires positive stock prices.')
    if cover_index is None:
        return {'pnl_per_initial_share':float(p[0]-p[-1]),'covers':0}
    if not 0<cover_index<len(p): raise InputError('Cover index outside position lifetime.')
    cash=p[0]-p[cover_index]
    if reenter_index is not None:
        if not cover_index<reenter_index<len(p): raise InputError('Reentry must follow cover.')
        cash+=p[reenter_index]-p[-1]
    return {'pnl_per_initial_share':float(cash),'covers':1}

def common_short_feasibility(members):
    if not {'borrowable','borrow_available'}.issubset(members):
        return pd.Series(False,index=members.index)
    flags=members.borrowable
    if not flags.dropna().isin([True,False,0,1]).all():
        raise InputError('borrowable must contain explicit boolean/0/1 values.')
    return flags.fillna(False).astype(bool)&(pd.to_numeric(members.borrow_available,errors='coerce')>0)

# %% Session/event contracts and per-decision feature history
def prepare_sessions(sessions):
    if not {'session','decision_at'}.issubset(sessions):
        raise InputError('ASX sessions require session and timezone-aware decision_at.')
    result=sessions.copy()
    result['session']=pd.to_datetime(result.session,errors='raise').dt.normalize()
    if result.session.duplicated().any() or not result.session.is_monotonic_increasing:
        raise InputError('ASX sessions must be unique and increasing; do not infer weekdays.')
    for column in ['decision_at','open_at','close_at']:
        if column in result: result[column]=utc_series(result[column],column)
    if 'expected_event_date' in result:
        result['expected_event_date']=pd.to_datetime(result.expected_event_date).dt.normalize()
    if not result.decision_at.is_monotonic_increasing:
        raise InputError('Decision times must increase with ASX sessions.')
    return result.reset_index(drop=True)

def validate_inputs(lending,sessions,universe):
    required={'security_id','event_date','available_at','utilisation','on_loan','lendable','shares_outstanding','broker_count'}
    if not required.issubset(lending):
        raise InputError(f'Lending export lacks canonical columns: {sorted(required-set(lending))}')
    calendar=prepare_sessions(sessions)
    dates=pd.to_datetime(lending.event_date).dt.normalize()
    if not dates.isin(calendar.session).all():
        raise InputError('Lending event dates outside supplied ASX session calendar.')
    utc_series(lending.available_at)
    for column in ['on_loan','lendable','shares_outstanding']:
        values=pd.to_numeric(lending[column],errors='raise')
        if (values.dropna()<0).any() or np.isinf(values.dropna()).any():
            raise InputError(f'{column}: negative/infinite stock-lending input.')
    _validate_broker_counts(lending.broker_count)
    if (pd.to_numeric(lending.shares_outstanding,errors='raise').dropna()<=0).any():
        raise InputError('shares_outstanding must be positive and use the quantity adjustment basis.')
    if 'active_lenders' in lending and 'total_lenders' in lending:
        lender_fraction(lending.active_lenders,lending.total_lenders)
    if not {'session','security_id','eligible','gics_sector','available_at'}.issubset(universe):
        raise InputError('Universe needs session,security_id,eligible,gics_sector,available_at; no current-membership backfill.')
    utc_series(universe.available_at,'universe available_at')
    return calendar

def event_mask(sessions,events,security_id,decision_at):
    calendar=pd.DatetimeIndex(pd.to_datetime(sessions.session).dt.normalize())
    mask=np.zeros(len(calendar),dtype=bool)
    if events is None or len(events)==0: return mask
    needed={'event_id','security_id','event_date','available_at','event_type','status'}
    if not needed.issubset(events): raise InputError(f'Events require {sorted(needed)}')
    data=events.copy(); data['available_at']=utc_series(data.available_at,'event available_at')
    data=data.loc[(data.available_at<=utc_timestamp(decision_at))&(data.security_id.astype(str)==str(security_id))]
    keys=['event_id','available_at']
    for _,group in data.loc[data.duplicated(keys,keep=False)].groupby(keys,observed=True):
        if len(group.drop_duplicates())>1: raise InputError('Conflicting event revision timestamp.')
    data=data.sort_values(keys).drop_duplicates('event_id',keep='last')
    offsets={'dividend':(-10,2),'meeting':(-20,2)}
    for row in data.itertuples():
        if row.status=='cancelled': continue
        if row.status!='active' or row.event_type not in offsets:
            raise InputError('Event status/type is not defined; use active/cancelled and dividend/meeting.')
        day=pd.Timestamp(row.event_date).normalize()
        if day not in calendar:
            raise InputError('Announced record date absent from ASX calendar; include the relevant future sessions.')
        j=calendar.get_loc(day); low,high=offsets[row.event_type]
        mask[max(0,j+low):min(len(calendar),j+high+1)]=True
    return mask

def _regime_reset(values,regimes):
    x=np.asarray(values,dtype=float).copy()
    if regimes is None: return x
    r=np.asarray(regimes,dtype=object)
    observed=np.flatnonzero(pd.notna(r))
    if len(observed)==0: return np.full(len(x),np.nan)
    last=observed[-1]; previous=observed[np.asarray(r[observed]!=r[last])]
    if len(previous): x[:previous[-1]+1]=np.nan
    return x

def features_at(lending,sessions,members,decision_at,config=Config(),events=None):
    """Validated standalone snapshot; the panel path prepares dependencies once."""
    return _features_at_impl(lending,sessions,members,decision_at,config,events)

def _features_at_impl(lending,sessions,members,decision_at,config=Config(),events=None,*,_prepared=None):
    """Rebuild ALL historical vintages available at D before any rolling transform."""
    calendar=prepare_sessions(sessions) if _prepared is None else _prepared['calendar']
    history_function=history_asof if _prepared is None else _prepared['history_asof']
    mask_function=event_mask if _prepared is None else _prepared['event_mask']
    lender_function=lender_fraction if _prepared is None else _prepared['lender_fraction']
    ema_function=ema_contrasts if _prepared is None else _prepared['ema_contrasts']
    snapshot=history_function(lending,decision_at)
    if _prepared is None and 'broker_count' in snapshot:
        # Standalone entry validates the visible vintage, not unavailable future
        # revisions. The prepared panel already validated its input once.
        _validate_broker_counts(snapshot.broker_count)
    current_members=members.copy()
    current_members['security_id']=current_members.security_id.astype(str)
    if current_members.security_id.duplicated().any(): raise InputError('Duplicate decision-time universe members.')
    if 'available_at' in current_members:
        current_members=current_members.loc[utc_series(current_members.available_at)<=utc_timestamp(decision_at)]
    if 'eligible' in current_members:
        if not current_members.eligible.dropna().isin([True,False,0,1]).all(): raise InputError('eligible must be boolean.')
        current_members=current_members.loc[current_members.eligible.fillna(False).astype(bool)]
    if len(snapshot)==0 or len(current_members)==0: return pd.DataFrame()
    decision_day=utc_timestamp(decision_at).tz_convert('Australia/Sydney').tz_localize(None).normalize()
    schedule=calendar.loc[calendar.session==decision_day]
    if len(schedule)!=1: raise InputError('Decision date must be in the supplied ASX session calendar.')
    cutoff=schedule.expected_event_date.iloc[0] if 'expected_event_date' in schedule else decision_day
    if pd.isna(cutoff): return pd.DataFrame()
    if cutoff>decision_day or cutoff not in set(calendar.session): raise InputError('Expected source date must be a known session no later than decision.')
    history_dates=pd.DatetimeIndex(calendar.loc[calendar.session<=cutoff,'session'])
    rows=[]
    groups={name:group.set_index('event_date') for name,group in snapshot.groupby('security_id',sort=False,observed=True)}
    for member in current_members.to_dict('records'):
        name=member['security_id']; data=groups.get(name,pd.DataFrame(index=pd.DatetimeIndex([]))).reindex(history_dates)
        def values(column):
            return pd.to_numeric(data[column],errors='coerce').to_numpy(float) if column in data else np.full(len(data),np.nan)
        u=values('utilisation'); q=values('on_loan'); l=values('lendable'); s=values('shares_outstanding'); b=values('broker_count')
        for column,x in [('on_loan',q),('lendable',l),('shares_outstanding',s),('broker_count',b)]:
            if np.any(x[np.isfinite(x)]<0): raise InputError(f'{name}: negative {column}')
        present=np.isfinite(u[-1]) and np.isfinite(q[-1]) and np.isfinite(b[-1]) and np.isfinite(s[-1]) and s[-1]>0
        invalid_u=(~np.isnan(u))&((~np.isfinite(u))|(u<0)|(u>100))
        artifact=bool(invalid_u[-1])
        safe_u=np.where(invalid_u,np.nan,u)
        mask_full=mask_function(calendar,events,name,decision_at)
        mask=mask_full[:len(history_dates)]
        raw={'scarcity':safe_u,'positioning':np.divide(q,s,out=np.full_like(q,np.nan),where=s>0),'participation':np.log1p(b)}
        result=dict(member,session=decision_day,decision_at=utc_timestamp(decision_at),data_cutoff=cutoff,
                    latest_row_missing=not present,data_artifact=artifact,masked_share=float(mask[-config.window:].mean()),
                    observed_history=int(np.isfinite(u).sum()),covered_session_span=len(history_dates),
                    invalid_utilisation_count=int(invalid_u[-config.window:].sum()),
                    annual_fee=values('annual_fee')[-1],source_available_at=data.available_at.iloc[-1] if 'available_at' in data else pd.NaT)
        for theme,series in raw.items():
            regime_column={'scarcity':'utilisation_definition','positioning':'quantity_definition','participation':'count_definition'}[theme]
            regimes=data[regime_column].to_numpy() if regime_column in data else None
            history=_regime_reset(series,regimes)
            transformed=history.copy(); transformed[mask]=np.nan
            flow_history=transformed
            if theme=='positioning':
                flow_history=_regime_reset(q,regimes); flow_history[mask]=np.nan
            slope,curve,count=ema_function(flow_history,config.half_lives,config.ema_min_observations)
            if theme=='positioning':
                slope=slope/s[-1] if s[-1]>0 else np.nan
                curve=curve/s[-1] if s[-1]>0 else np.nan
            moments=trailing_moments(transformed,config.window,config.min_observations)
            current=series[-1]
            if not np.isfinite(current) or not np.isfinite(moments['std']): unusual=np.nan
            elif moments['std']==0: unusual=0.
            else: unusual=float(np.clip((current-moments['mean'])/moments['std'],-4,4))
            result[f'{theme}_level']=current
            result[f'{theme}_flow']=slope
            result[f'{theme}_curvature']=curve
            result[f'{theme}_unusualness']=unusual
            result[f'{theme}_valid_count']=moments['count']
            if theme=='scarcity': result['scarcity_instability']=np.log1p(moments['std']**2) if np.isfinite(moments['std']) else np.nan
        result['optional_active_lender_fraction']=np.nan
        if {'active_lenders','total_lenders'}.issubset(data):
            fraction=lender_function(data.active_lenders,data.total_lenders)
            result['optional_active_lender_fraction']=fraction.iloc[-1]
            result['active_lenders']=data.active_lenders.iloc[-1]; result['total_lenders']=data.total_lenders.iloc[-1]
        fee=values('annual_fee')
        result['optional_fee_level']=np.log1p(fee[-1]*1e4) if np.isfinite(fee[-1]) else np.nan
        fee_regimes=data.fee_definition.to_numpy() if 'fee_definition' in data else None
        # Unidentified fee history cannot support a risk estimator.
        fee_mom=trailing_moments(fee,config.window,config.min_observations,fee_regimes) if fee_regimes is not None else {'std':np.nan,'count':0}
        result['optional_fee_std']=np.log1p(fee_mom['std']*1e4) if np.isfinite(fee_mom['std']) else np.nan
        result['fee_valid_count']=fee_mom['count']
        k=config.change_window
        result['quantity_growth']=np.nan; result['supply_withdrawal']=np.nan; result['optional_demand_quadrant']=np.nan
        if len(data)>k:
            if q[-1]>0 and q[-1-k]>0: result['quantity_growth']=np.log(q[-1]/q[-1-k])
            if l[-1]>0 and l[-1-k]>0: result['supply_withdrawal']=-np.log(l[-1]/l[-1-k])
            same_fee_regime=fee_regimes is not None and pd.notna(fee_regimes[-1]) and np.all(fee_regimes[-1-k:]==fee_regimes[-1])
            if same_fee_regime and np.isfinite([fee[-1],fee[-1-k],result['quantity_growth']]).all():
                df=fee[-1]-fee[-1-k]; dq=result['quantity_growth']
                result['optional_demand_quadrant']=float(int(df>0 and dq>0)-int(df<0 and dq<0))
        rows.append(result)
    result=pd.DataFrame(rows).sort_values('security_id').reset_index(drop=True)
    for theme in ['scarcity','positioning','participation']:
        for family in ['level','flow','curvature','unusualness']:
            column=f'{theme}_{family}'; result['raw_'+column]=result[column]
            result[column]=cross_section(result[column],config.clip_quantiles)
        level=result[f'{theme}_level']
        group=result.gics_sector.fillna('UNKNOWN') if 'gics_sector' in result else pd.Series('MARKET',index=result.index)
        counts=level.groupby(group,observed=True).transform('count')
        peer=group.where(counts>=10,'MARKET')
        medians=level.groupby(group,observed=True).transform('median')
        market_median=level.median() if level.notna().any() else np.nan
        medians=medians.where(counts>=10,market_median)
        result[f'{theme}_within_gics']=level-medians
    result['raw_scarcity_instability']=result.scarcity_instability
    result['scarcity_instability']=cross_section(result.scarcity_instability,config.clip_quantiles)
    for column in ['optional_active_lender_fraction','optional_fee_level','optional_fee_std','optional_demand_quadrant']:
        result['raw_'+column]=result[column]; result[column]=cross_section(result[column],config.clip_quantiles)
    return result

def build_scores(features,config=Config()):
    if len(features)==0: return features.copy()
    result=features.copy()
    levels=features[['scarcity_level','positioning_level','participation_level']]
    signs=np.asarray(config.theme_signs,dtype=float)
    if signs.shape!=(3,) or not np.isin(signs,[-1,1]).all(): raise InputError('Declare three orientation signs, each+1 or-1.')
    complete=levels.notna().all(axis=1)
    baseline=(levels*signs).sum(axis=1)/3.
    baseline=baseline.where(complete)
    # A supplied frozen baseline is retained verbatim up to final affine z-scoring.
    if 'baseline_score' in features: baseline=features.baseline_score.where(complete)
    result['baseline']=finite_z(baseline)
    flows=features[['scarcity_flow','positioning_flow','participation_flow']].copy()*signs
    result['flow_fallback']=flows.isna().any(axis=1)
    path=fixed_overlay(flows)
    result['path_score']=path
    result['overlay']=result.baseline+config.kappa*finite_z(path).fillna(0.)
    result.loc[~complete,['baseline','overlay']]=np.nan
    if config.use_optional_signals:
        for column in ['optional_active_lender_fraction','optional_fee_level','optional_fee_std','optional_demand_quadrant']:
            result['candidate_'+column]=result.baseline+config.kappa*finite_z(features[column]).fillna(0.)
    return result

def universe_at(universe,session,decision_at):
    data=universe.copy(); data['session']=pd.to_datetime(data.session).dt.normalize()
    data['available_at']=utc_series(data.available_at,'universe available_at')
    data=data.loc[(data.session==pd.Timestamp(session).normalize())&(data.available_at<=utc_timestamp(decision_at))]
    keys=['security_id','session','available_at']
    for _,group in data.loc[data.duplicated(keys,keep=False)].groupby(keys,observed=True):
        if len(group.drop_duplicates())>1: raise InputError('Conflicting point-in-time universe vintages.')
    return data.sort_values(keys).drop_duplicates(['session','security_id'],keep='last').reset_index(drop=True)

def _build_feature_panel_reference(lending,sessions,universe,config=Config(),events=None):
    calendar=validate_inputs(lending,sessions,universe)
    output=[]
    for row in calendar.itertuples():
        members=universe_at(universe,row.session,row.decision_at)
        if len(members):
            snapshot=features_at(lending,calendar,members,row.decision_at,config,events)
            if len(snapshot): output.append(build_scores(snapshot,config))
    return pd.concat(output,ignore_index=True) if output else pd.DataFrame()

# %% Executable labels and dependence-aware paired inference
def make_labels(prices,sessions,horizon=20):
    calendar=prepare_sessions(sessions)
    if not {'open_at','close_at'}.issubset(calendar): raise InputError('Evaluation needs actual ASX open_at/close_at times.')
    if not {'security_id','session','open','close'}.issubset(prices): raise InputError('Prices need security_id,session,open,close on a consistent distribution/adjustment basis.')
    if not isinstance(horizon,int) or horizon<1: raise InputError('Forecast horizon must be a positive session count.')
    data=prices.copy(); data['session']=pd.to_datetime(data.session).dt.normalize(); data['security_id']=data.security_id.astype(str)
    if data.duplicated(['security_id','session']).any(): raise InputError('Duplicate prices; reconcile the price source.')
    output=[]
    for name,group in data.groupby('security_id',sort=False,observed=True):
        path=group.set_index('session').reindex(calendar.session)
        for j in range(len(calendar)-horizon):
            entry_j=j+1; exit_j=j+horizon
            entry=path.open.iloc[entry_j]; exit=path.close.iloc[exit_j]
            observed=bool(np.isfinite([entry,exit]).all() and entry>0 and exit>=0)
            if calendar.open_at.iloc[entry_j]<=calendar.decision_at.iloc[j]:
                raise InputError('Execution open must be strictly after decision; change schedule, not an arbitrary price shift.')
            # Do not bridge a missing security price path or implicit delisting.
            observed=observed and not path.close.iloc[entry_j:exit_j+1].isna().any()
            row=dict(session=calendar.session.iloc[j],security_id=name,entry_session=calendar.session.iloc[entry_j],
                     exit_session=calendar.session.iloc[exit_j],entry_at=calendar.open_at.iloc[entry_j],
                     exit_at=calendar.close_at.iloc[exit_j],label_available_at=calendar.close_at.iloc[exit_j] if observed else pd.NaT,
                     entry_price=entry,exit_price=exit,forward_return=exit/entry-1. if observed else np.nan,outcome_observed=observed)
            output.append(row)
    return pd.DataFrame(output)

def paired_block_inference(values,block_length=20,replications=999,seed=7):
    """Exploratory circular-block percentile interval; one-sided alternative mean>0."""
    x=np.asarray(values,dtype=float); x=x[np.isfinite(x)]; n=len(x)
    empty={'status':'insufficient','n_dates':n,'mean':np.nan,'lower':np.nan,'upper':np.nan,'p_value':np.nan,'block_length':block_length}
    if n<2*block_length or n<8: return empty
    rng=np.random.default_rng(seed); offsets=np.arange(block_length); means=np.empty(replications)
    for b in range(replications):
        starts=rng.integers(0,n,size=math.ceil(n/block_length))
        indices=((starts[:,None]+offsets)%n).ravel()[:n]
        means[b]=x[indices].mean()
    mu=float(x.mean()); centered=means-mu
    p=(1+np.count_nonzero(centered>=mu))/(replications+1)
    lo,hi=np.quantile(means,[.025,.975])
    return dict(status='diagnostic',n_dates=n,mean=mu,lower=float(lo),upper=float(hi),p_value=float(p),block_length=block_length)

def holm_adjust(pvalues):
    p=np.asarray(pvalues,dtype=float); result=np.full(len(p),np.nan); valid=np.flatnonzero(np.isfinite(p))
    order=valid[np.argsort(p[valid])]; running=0.
    for rank,j in enumerate(order):
        running=max(running,(len(order)-rank)*p[j]); result[j]=min(1.,running)
    return result

# %% Fixed research models, never an automatic winner search
def chronological_predictions(frame,config=Config(),methods=('ridge','lasso','elastic_net','pcr','trees')):
    from sklearn.linear_model import Ridge, Lasso, ElasticNet
    from sklearn.ensemble import HistGradientBoostingRegressor
    result=frame.copy().sort_values(['session','security_id']).reset_index(drop=True)
    columns=[c for c in result if c.endswith(('_level','_flow','_curvature','_unusualness','_instability','_within_gics')) and not c.startswith(('raw_','optional_','candidate_'))]
    if not columns: raise InputError('No registered feature columns for research models.')
    for name in methods: result[name]=np.nan
    result['fit_at']=pd.Series(pd.NaT,index=result.index,dtype='datetime64[ns, UTC]')
    result['latest_training_label_at']=pd.Series(pd.NaT,index=result.index,dtype='datetime64[ns, UTC]')
    result['model_input_count']=2*len(columns)
    dates=np.sort(result.session.unique()); fitted=None; trained_on=-config.refit_sessions
    for j,day in enumerate(dates):
        test_mask=result.session==day; cutoff=utc_timestamp(result.loc[test_mask,'decision_at'].iloc[0])
        if j-trained_on>=config.refit_sessions:
            train_mask=(result.session<day)&mature_labels(result,cutoff)&result.forward_return.notna()
            train=result.loc[train_mask].copy()
            if train.session.nunique()<config.minimum_train_sessions: continue
            target=-train.groupby('session',observed=True).forward_return.transform(lambda x:cross_section(x,(0.,1.)))
            okay=target.notna(); train=train.loc[okay]; target=target.loc[okay]
            raw=train[columns].to_numpy(float)
            x=np.column_stack([np.nan_to_num(raw,nan=0.),~np.isfinite(raw)])
            weights=(1/train.groupby('session',observed=True).security_id.transform('count')).to_numpy(float)
            center=np.average(x,axis=0,weights=weights)
            scale=np.sqrt(np.average((x-center)**2,axis=0,weights=weights)); scale[scale==0]=1.
            x=(x-center)/scale
            models={}
            for name in methods:
                if name=='ridge': model=Ridge(alpha=10.)
                elif name=='lasso': model=Lasso(alpha=.001,max_iter=20000,tol=1e-5)
                elif name=='elastic_net': model=ElasticNet(alpha=.001,l1_ratio=.5,max_iter=20000,tol=1e-5)
                elif name=='trees': model=HistGradientBoostingRegressor(max_depth=2,max_iter=40,learning_rate=.05,min_samples_leaf=max(10,int(len(x)*.01)),l2_regularization=10.,random_state=7,early_stopping=False)
                elif name=='pcr':
                    covariance=(x.T*weights)@x/weights.sum()
                    vectors=np.linalg.svd(covariance,hermitian=True)[0][:,:min(3,x.shape[1])]
                    model=Ridge(alpha=10.).fit(x@vectors,target,sample_weight=weights)
                    models[name]=(model,vectors); continue
                else: raise InputError(f'Unknown registered research model: {name}')
                model.fit(x,target,sample_weight=weights); models[name]=(model,None)
            fitted=(models,center,scale,cutoff,utc_series(train.label_available_at).max())
            trained_on=j
        if fitted is None: continue
        models,center,scale,fit_at,last_label=fitted
        raw=result.loc[test_mask,columns].to_numpy(float)
        x=np.column_stack([np.nan_to_num(raw,nan=0.),~np.isfinite(raw)])
        x=(x-center)/scale
        for name,(model,vectors) in models.items():
            predictions=model.predict(x@vectors if vectors is not None else x)
            result.loc[test_mask,name]=finite_z(pd.Series(predictions)).to_numpy()
        result.loc[test_mask,'fit_at']=fit_at
        result.loc[test_mask,'latest_training_label_at']=last_label
    return result

# %% Same-universe stock legs; raw monetary returns
def evaluate_legs(frame,config=Config(),models=('baseline','overlay')):
    required={'session','security_id','entry_price','exit_price','entry_at','exit_at'}
    if not required.issubset(frame): raise InputError(f'Portfolio evaluation needs {sorted(required)}')
    rows=[]
    for day,group in frame.groupby('session',sort=True,observed=True):
        common=group.loc[group[list(models)].notna().all(axis=1)].copy()
        if 'data_artifact' in common: common=common.loc[~common.data_artifact.fillna(True)]
        for side,direction in [('long',1),('short',-1)]:
            universe=common if side=='long' else common.loc[common_short_feasibility(common)]
            if len(universe)<2: continue
            count=max(1,int(math.floor(config.leg_fraction*len(universe))))
            for model in models:
                selected=universe.sort_values([model,'security_id'],ascending=[side=='long',True]).iloc[:count]
                gross=[]; net=[]; fees=[]; costs=[]
                unpriced=0
                for row in selected.to_dict('records'):
                    entry=float(row['entry_price']); exit=float(row['exit_price'])
                    observed=bool(np.isfinite([entry,exit]).all() and entry>0 and exit>=0 and row.get('outcome_observed',True))
                    if not observed:
                        unpriced+=1; gross.append(np.nan); net.append(np.nan); fees.append(np.nan); costs.append(np.nan)
                        continue
                    gross.append(direction*(exit/entry-1.))
                    fee=row.get('annual_fee',np.nan); cost=row.get('round_trip_cost_bps',np.nan)
                    days=(utc_timestamp(row['exit_at'])-utc_timestamp(row['entry_at'])).total_seconds()/86400.
                    if np.isfinite(cost) and (side=='long' or np.isfinite(fee)):
                        net.append(position_return(entry,exit,direction,fee,days,cost))
                        fees.append(fee*days/365. if side=='short' else 0.); costs.append(cost/10000.)
                    else:
                        net.append(np.nan); fees.append(np.nan); costs.append(np.nan)
                rows.append(dict(session=day,side=side,model=model,n_names=len(selected),eligible_count=len(universe),
                                 gross_return=float(np.mean(gross)),net_return=float(np.mean(net)),borrow_cost=float(np.mean(fees)),
                                 execution_cost=float(np.mean(costs)),selected_ids=','.join(selected.security_id.astype(str)),
                                 unpriced_selected=unpriced,
                                 return_convention='fixed entry notional; entry annual fee held constant; scenario estimate',
                                 label_available_at=selected.exit_at.max()))
    return pd.DataFrame(rows)

def comparison_report(legs,config=Config()):
    rows=[]
    if len(legs)==0: return pd.DataFrame()
    for side,part in legs.groupby('side',observed=True):
        table=part.pivot(index='session',columns='model',values='net_return')
        if not {'baseline','overlay'}.issubset(table): continue
        delta=(table.overlay-table.baseline).dropna()
        # Full overlapping holding-period series requires at least horizon-sized blocks.
        inference=paired_block_inference(delta,config.horizon)
        if part.unpriced_selected.sum()>0 or part.net_return.isna().any():
            inference.update(status='incomplete_outcomes_or_costs',mean=np.nan,lower=np.nan,upper=np.nan,p_value=np.nan)
        rows.append(dict(side=side,comparison='overlay minus baseline',**inference))
    report=pd.DataFrame(rows)
    if len(report): report['holm_p_value']=holm_adjust(report.p_value)
    return report

def stock_slices(frame):
    """Pooled stock-date sector/index coverage and composition, not daily aggregation.

    Frozen scores are never reranked to search for good sectors. Counts and averages
    pool all stock-date rows; they are not equal-date averages or sector performance.
    Only supplied sector labels are supported, not GICS4/6/8 hierarchy views.
    """
    rows=[]
    for field in ['gics_sector','index_name','index_asx200','index_asx300']:
        if field not in frame: continue
        for value,group in frame.groupby(field,dropna=False,observed=True):
            rows.append({'slice_field':field,'slice':str(value),'stock_dates':len(group),'n_stocks':group.security_id.nunique(),
                         'baseline_coverage':group.baseline.notna().mean(),'overlay_coverage':group.overlay.notna().mean(),
                         'average_raw_utilisation':group.raw_scarcity_level.mean(),'score_mean':group.overlay.mean()})
    return pd.DataFrame(rows)

def capacity_report(frame,notional_per_leg=None,max_adv_participation=None):
    if notional_per_leg is None or max_adv_participation is None:
        return pd.DataFrame([{'status':'not_assessed','reason':'Declare portfolio notional and maximum ADV participation; score ranks do not establish capacity.'}])
    if notional_per_leg<=0 or not 0<max_adv_participation<=1: raise InputError('Invalid capital/participation mandate.')
    if not {'adv_shares','borrow_available','entry_price'}.issubset(frame):
        return pd.DataFrame([{'status':'not_assessed','reason':'Execution-side ADV shares/locate quantity missing; lendable panel inventory is not a locate.'}])
    result=frame[['session','security_id','entry_price','adv_shares','borrow_available']].copy()
    result['execution_capacity_dollars']=result.entry_price*result.adv_shares*max_adv_participation
    result['borrow_capacity_dollars']=result.entry_price*result.borrow_available
    result['single_name_capacity_dollars']=result[['execution_capacity_dollars','borrow_capacity_dollars']].min(axis=1)
    result['mandate_leg_notional']=notional_per_leg; result['status']='constraint_diagnostic_not_portfolio_capacity'
    return result

def run_analysis(lending,sessions,universe,prices,events=None,config=Config(),mode='REAL INPUT - RESEARCH ONLY'):
    features=build_feature_panel(lending,sessions,universe,config,events)
    labels=make_labels(prices,sessions,config.horizon)
    joined=features.merge(labels,on=['session','security_id'],how='left',validate='one_to_one') if len(features) and len(labels) else pd.DataFrame()
    predictions=chronological_predictions(joined,config) if config.run_research_models and len(joined) else joined
    # Complete holding-period dates are common to all stocks; missing individual
    # outcomes never determine stock eligibility or replace selected positions.
    completed=pd.to_datetime(sessions.session).iloc[:-config.horizon]
    leg_input=joined.loc[joined.session.isin(completed)] if len(joined) else joined
    legs=evaluate_legs(leg_input,config) if len(leg_input) else pd.DataFrame()
    return {'features':features,'labels':labels,'predictions':predictions,'legs':legs,'comparisons':comparison_report(legs,config),
            'stock_slices':stock_slices(features) if len(features) else pd.DataFrame(),
            'metadata':{'mode':mode,'alpha_validated':False,'baseline':'supplied baseline_score' if 'baseline_score' in universe else 'declared equal-theme research baseline, not recovered user baseline',
                        'net_returns':'entry-fee and supplied execution-cost scenarios, not actual paid-cost validation',
                        'capacity':'not established','evidence_status':'exploratory_retrospective_no_untouched_holdout',
                        'session_calendar':'synthetic weekdays, not ASX-verified' if mode.startswith('SYNTHETIC') else 'user-supplied sessions; no independent exchange-calendar verification'}}

# %% Controlled synthetic inputs (stock-crowding machinery, not evidence)
def synthetic_inputs(sessions_count=330,securities_count=24,seed=17):
    rng=np.random.default_rng(seed)
    dates=pd.bdate_range('2023-01-03',periods=sessions_count)  # intentionally not asserted to be an ASX holiday calendar
    local=[day.tz_localize('Australia/Sydney') for day in dates]
    sessions=pd.DataFrame({'session':dates,'expected_event_date':dates,'open_at':[d+pd.Timedelta(hours=10) for d in local],
                           'close_at':[d+pd.Timedelta(hours=16) for d in local],'decision_at':[d+pd.Timedelta(hours=17) for d in local]})
    rows=[]; members=[]; price_rows=[]
    sectors=['Materials','Financials','Real Estate','Industrials']
    for i in range(securities_count):
        name=f'SYNTH_STOCK_{i:03d}'; shares=1e8*(1+i/10)
        u=np.clip(15+i+np.cumsum(rng.normal(0,.6,sessions_count)),1,95)
        lendable=shares*.25*np.exp(np.cumsum(rng.normal(0,.002,sessions_count)))
        q=lendable*u/100.
        fee=np.maximum(0.,.002+.08*(u/100)**3+rng.normal(0,.0001,sessions_count))
        prices=40*np.exp(np.cumsum(rng.normal(0,.012,sessions_count)))
        for j,day in enumerate(dates):
            rows.append(dict(security_id=name,event_date=day,available_at=sessions.close_at.iloc[j]+pd.Timedelta(minutes=15),
                             utilisation=u[j],on_loan=q[j],lendable=lendable[j],shares_outstanding=shares,
                             broker_count=float(2+i%12),active_lenders=float(2+i%5),total_lenders=10.,annual_fee=fee[j],fee_definition='synthetic_continuous_borrower_v1'))
            members.append(dict(security_id=name,session=day,available_at=sessions.open_at.iloc[j]-pd.Timedelta(hours=1),
                                eligible=True,gics_sector=sectors[i%4],borrowable=True,borrow_available=1e6,
                                adv_shares=2e6,round_trip_cost_bps=10.,index_asx200=i<securities_count*.75,index_asx300=True))
            price_rows.append(dict(security_id=name,session=day,open=prices[j],close=prices[j]*(1+rng.normal(0,.002))))
    return {'lending':pd.DataFrame(rows),'sessions':sessions,'universe':pd.DataFrame(members),'prices':pd.DataFrame(price_rows)}

# %% Local CSV/Parquet entry point: never substitutes demo data
def run_local_exports(settings,config=Config()):
    tables=['lending','sessions','universe','prices']
    missing=[f'{name}_path / {name}_columns' for name in tables if not settings.get(name+'_path') or not settings.get(name+'_columns')]
    if missing:
        return {'status':'setup_required','missing':missing,'message':'Fill the explicit local export maps. No real-data result has been produced.'}
    declarations=['vintages_are_as_received','row_availability_is_max_input','point_in_time_universe','consistent_corporate_actions','prices_include_distributions']
    if not all(settings.get(key) is True for key in declarations):
        return {'status':'setup_required','missing':[key for key in declarations if settings.get(key) is not True],
                'message':'Confirm source/price conventions; a flag cannot repair a final-revised archive.'}
    try:
        inputs={name:load_table(settings[name+'_path'],settings[name+'_columns']) for name in tables}
        if 'expected_event_date' not in inputs['sessions']:
            raise InputError('Real ASX sessions need expected_event_date from the verified vendor/calendar lag contract; never infer it from latest delivery.')
        if 'annual_fee' in inputs['lending']:
            inputs['lending']['annual_fee']=canonical_fee(inputs['lending'].annual_fee,settings.get('fee_unit'))
            if settings.get('fee_kind') not in ['actual_borrower','indicative','benchmark']:
                raise InputError('Declare fee_kind actual_borrower, indicative or benchmark.')
            if settings.get('fee_kind')=='benchmark':
                multiplier=settings.get('borrow_fee_multiplier')
                if multiplier is None or multiplier<1: raise InputError('Benchmark lender fees require an explicit borrower markup scenario.')
                inputs['lending']['annual_fee']*=multiplier
        if settings.get('events_path'):
            inputs['events']=load_table(settings['events_path'],settings['events_columns'])
        result=run_analysis(**inputs,config=config)
        result['status']='research_complete'; result['metadata']['fee_kind']=settings.get('fee_kind','missing')
        return result
    except (ValueError,OSError,KeyError,TypeError) as error:
        return {'status':'input_error','message':str(error),'alpha_validated':False}

# %% Stock-index positioning matrix: no price/valuation/turnover proxies
def index_crowding_scores(metrics,normalize=False):
    """Daily rank across stock indices. Optional own-history z uses252/252 exactly."""
    frame=pd.DataFrame(metrics).astype(float)
    if not frame.index.is_unique or not frame.columns.is_unique: raise InputError('Index metric row/column labels must be unique.')
    frame=frame.replace([np.inf,-np.inf],np.nan)
    if normalize:
        mean=frame.rolling(252,min_periods=252).mean()
        sd=frame.rolling(252,min_periods=252).std(ddof=1)
        frame=(frame-mean)/sd.where(sd>0)
    # ranks divided by finite N: ties receive average rank, range(0,1].
    return frame.rank(axis=1,method='average',pct=True,na_option='keep')

def index_calendar(sessions):
    calendar=prepare_sessions(sessions)
    if 'close_at' not in calendar:
        raise InputError('Index scoring requires an explicit close_at cutoff; a later decision_at is not the market close.')
    calendar['cutoff_at']=calendar.decision_at.where(calendar.decision_at<=calendar.close_at,calendar.close_at)
    return calendar

def initial_index_metrics(vintages,sessions):
    required={'index_id','event_date','available_at','positioning_metric'}
    if not required.issubset(vintages): raise InputError(f'Index aggregates require {sorted(required)}')
    data=vintages.copy(); data['event_date']=pd.to_datetime(data.event_date).dt.normalize()
    data['available_at']=utc_series(data.available_at,'index initial-release available_at')
    keys=['index_id','event_date','available_at']
    for _,group in data.loc[data.duplicated(keys,keep=False)].groupby(keys,observed=True):
        if len(group.drop_duplicates())>1: raise InputError('Conflicting initial-release index metrics.')
    data=data.sort_values(keys).drop_duplicates(['index_id','event_date'],keep='first')
    calendar=index_calendar(sessions)
    calendar['source_event_date']=calendar.expected_event_date if 'expected_event_date' in calendar else calendar.session
    merged=data.merge(calendar[['session','source_event_date','cutoff_at']],left_on='event_date',right_on='source_event_date',how='inner')
    merged.loc[merged.available_at>merged.cutoff_at,'positioning_metric']=np.nan
    matrix=merged.pivot(index='session',columns='index_id',values='positioning_metric')
    return matrix.reindex(index=calendar.session).rename_axis(index='session')

def aggregate_stock_positioning(stocks,memberships):
    """Equal-stock mean Q/S after an EXTERNALLY provided PIT ADV mask.

    Inputs are already first-release decision snapshots; call initial-release
    selection before this helper, never final-revised exports. Missing included
    constituents make their index metric missing, rather than changing weights.
    """
    required={'session','security_id','on_loan','shares_outstanding','adv_eligible'}
    if not required.issubset(stocks) or not {'session','security_id','index_id'}.issubset(memberships):
        raise InputError('Stock aggregation needs PIT Q,S,ADV eligibility and dated index membership.')
    if stocks.duplicated(['session','security_id']).any() or memberships.duplicated(['session','security_id','index_id']).any():
        raise InputError('Duplicate stock observations or index memberships.')
    data=memberships.merge(stocks,on=['session','security_id'],how='left',validate='many_to_one')
    flags=data.adv_eligible
    if not flags.dropna().isin([True,False,0,1]).all(): raise InputError('ADV eligibility must be an explicit PIT boolean mask.')
    # Unknown ADV eligibility is missing, not silently an exclusion.
    data['known_excluded']=flags.eq(False)
    data=data.loc[~data.known_excluded].copy()
    if (data.on_loan.dropna()<0).any() or (data.shares_outstanding.dropna()<=0).any(): raise InputError('Q/S needs nonnegative Q and positive matching shares outstanding.')
    data['metric']=data.on_loan/data.shares_outstanding
    data.loc[data.adv_eligible.isna(),'metric']=np.nan
    grouped=data.groupby(['session','index_id'],observed=True).metric
    means=grouped.mean(); valid=grouped.count(); total=grouped.size()
    return means.where(valid==total).unstack('index_id').sort_index()

# %% Constant-correlation Ledoit-Wolf estimator (not sklearn's identity target)
# Mathematical implementation following covCor.m (01/2021), with sample n=T-1.
# https://github.com/oledoit/covShrinkage/blob/main/covCor.m
LEDOIT_WOLF_BSD_NOTICE = '''Copyright (c) 2014-2021, Olivier Ledoit and Michael Wolf
All rights reserved.
Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.'''

def constant_correlation_shrinkage(observations):
    y=np.asarray(observations,dtype=float)
    if y.ndim!=2 or len(y)<3 or y.shape[1]<2 or not np.isfinite(y).all():
        raise InputError('Shrinkage needs a finite observations-by-indices matrix.')
    if y.shape[1]>200: raise InputError('This estimator is scoped to at most200 stock indices, not7000stock columns.')
    x=y-y.mean(axis=0); sample_sd=x.std(axis=0,ddof=1)
    if np.any(sample_sd==0): raise InputError('Remove zero-variance index changes before shrinkage.')
    x=x/sample_sd; m=len(x)-1; p=x.shape[1]
    sample=x.T@x/m
    variances=np.diag(sample).copy(); sd=np.sqrt(variances)
    mean_r=(np.sum(sample/np.outer(sd,sd))-p)/(p*(p-1))
    target=mean_r*np.outer(sd,sd); np.fill_diagonal(target,variances)
    x2=x*x; pi_matrix=x2.T@x2/m-sample*sample
    pi=float(pi_matrix.sum())
    theta=(x*x*x).T@x/m-variances[:,None]*sample
    np.fill_diagonal(theta,0.)
    rho=float(np.trace(pi_matrix)+mean_r*np.sum((sd[None,:]/sd[:,None])*theta))
    gamma=float(np.sum((sample-target)**2))
    intensity=0. if gamma<=np.finfo(float).eps*p else float(np.clip((pi-rho)/(m*gamma),0,1))
    correlation=(1-intensity)*sample+intensity*target
    correlation=(correlation+correlation.T)/2
    diagonal=np.sqrt(np.diag(correlation)); correlation/=np.outer(diagonal,diagonal)
    return correlation,intensity

def _correlation_spectrum(correlation):
    from scipy.linalg import svd
    c=np.array(correlation,dtype=float,copy=True)
    if c.ndim!=2 or c.shape[0]!=c.shape[1] or not np.isfinite(c).all(): raise InputError('AR requires a finite square index correlation matrix.')
    if not np.allclose(c,c.T,atol=1e-10) or np.trace(c)<=0: raise InputError('AR matrix must be symmetric with positive trace; never zero its diagonal.')
    singular=svd(c,compute_uv=False,check_finite=False,lapack_driver='gesdd')
    if singular.sum()>np.trace(c)+1e-8*len(c): raise InputError('AR input is not positive semidefinite.')
    ridge=bool(singular[-1]<=np.finfo(float).eps*len(c)*singular[0])
    if ridge:
        c.flat[::len(c)+1]+=1e-6
        singular=svd(c,compute_uv=False,check_finite=False,lapack_driver='gesdd')
    return singular,ridge,c

def absorption_from_correlation(correlation,k):
    singular,_,_= _correlation_spectrum(correlation)
    if not 1<=k<=len(singular): raise InputError('k outside the active index dimension.')
    return float(singular[:k].sum()/singular.sum())

def absorption_ratio(crowding_scores,window=60):
    """Exactly60changes[t-60:t], current score only controls missing eligibility.

    O(T*N^3) small index matrices; stores only latest matrix, not T*N*N arrays.
    """
    from scipy.stats import rankdata
    from threadpoolctl import threadpool_limits
    scores=pd.DataFrame(crowding_scores).astype(float)
    if scores.shape[1]>200: raise InputError('AR expects at most200 index columns; do not pass the7000-equity matrix.')
    if not scores.index.is_unique or not scores.columns.is_unique or not scores.index.is_monotonic_increasing:
        raise InputError('Score dates and index labels must be unique, dates increasing; retain missing sessions.')
    array=scores.to_numpy()
    if np.any(np.isinf(array)) or np.any((array[np.isfinite(array)]<0)|(array[np.isfinite(array)]>1)):
        raise InputError('Crowding scores must lie in[0,1], with NaN for unavailable indices.')
    if window!=60: raise InputError('The registered AR correlation window is60 sessions.')
    columns=['AR','N','k','uniform_baseline','n_observations','dropped_missing','dropped_constant','shrinkage','mean_correlation']
    result=pd.DataFrame(np.nan,index=scores.index,columns=columns)
    result['shrinkage_applied']=False; result['ridge_added']=False
    result['cohort_changed']=False
    # Upstream daily percentile peers can change while the final AR cohort does
    # not. Keep both diagnostics; neither is an automatic trading threshold.
    finite_cohort=np.isfinite(array)
    signatures=[row.tobytes() for row in np.packbits(finite_cohort,axis=1)]
    ranking_changes=np.array([False]+[signatures[j]!=signatures[j-1] for j in range(1,len(signatures))],dtype=bool)
    result['ranking_cohort_size']=finite_cohort.sum(axis=1)
    result['ranking_cohort_changed']=ranking_changes
    result['ranking_cohort_changed_in_window']=False
    latest=None; latest_at=None
    prior_chosen=None
    with threadpool_limits(limits=1):
        for t in range(window+1,len(scores)):
            result.loc[scores.index[t],'ranking_cohort_changed_in_window']=bool(ranking_changes[t-window:t].any())
            changes=np.diff(array[t-window-1:t],axis=0)
            eligible=np.isfinite(changes).all(axis=0)&np.isfinite(array[t])
            dropped=int((~eligible).sum()); chosen=np.flatnonzero(eligible)
            ranked=rankdata(changes[:,chosen],axis=0,method='average') if len(chosen) else np.empty((window,0))
            variable=ranked.std(axis=0,ddof=1)>0
            constant=int((~variable).sum()); chosen=chosen[variable]; ranked=ranked[:,variable]
            n=len(chosen); k=n//5
            if prior_chosen is not None:
                result.loc[scores.index[t],'cohort_changed']=not np.array_equal(chosen,prior_chosen)
            prior_chosen=chosen.copy()
            result.iloc[t,result.columns.get_indexer(['N','k','uniform_baseline','n_observations','dropped_missing','dropped_constant'])]=[n,k,k/n if n else np.nan,window,dropped,constant]
            if n<20: continue
            x=ranked-ranked.mean(axis=0); x/=x.std(axis=0,ddof=1)
            if n>60:
                corr,shrinkage=constant_correlation_shrinkage(x)
                result.loc[scores.index[t],'shrinkage_applied']=True
            else: corr=x.T@x/(window-1); shrinkage=0.
            mean_r=(corr.sum()-np.trace(corr))/(n*(n-1))
            singular,ridge,used= _correlation_spectrum(corr)
            result.loc[scores.index[t],['AR','shrinkage','mean_correlation','ridge_added']]=[singular[:k].sum()/singular.sum(),shrinkage,mean_r,ridge]
            latest=pd.DataFrame(used,index=scores.columns[chosen],columns=scores.columns[chosen]); latest_at=scores.index[t]
    result['delta_AR']=delta_ar(result.AR)
    return {'series':result,'latest_correlation':latest,'matrix_asof':latest_at,
            'definition':'Spearman correlation of lagged stock-index crowding score changes; adaptation, not return-covariance AR'}

def delta_ar(ar):
    values=pd.Series(ar,dtype=float)
    short=values.rolling(15,min_periods=15).mean()
    long=values.rolling(252,min_periods=252).mean()
    sd=values.rolling(252,min_periods=252).std(ddof=1)
    # Constant histories are undefined, not zero-fragility observations.
    return (short-long)/sd.where(sd>np.finfo(float).eps)

# %% Initial-release stock aggregation and price-free matrix file adapter
def aggregate_initial_stock_vintages(lending,memberships,sessions):
    """Vectorized joins: no repeated per-day historical scan or equity covariance."""
    needed={'security_id','event_date','available_at','on_loan','shares_outstanding'}
    member_needed={'session','security_id','index_id','available_at','adv_eligible'}
    if not needed.issubset(lending) or not member_needed.issubset(memberships):
        raise InputError('Initial-release stock aggregation needs dated Q,S,vintage times and dated index/ADV membership.')
    calendar=index_calendar(sessions)
    calendar['source_event_date']=calendar.expected_event_date if 'expected_event_date' in calendar else calendar.session
    stock=lending.copy(); stock['event_date']=pd.to_datetime(stock.event_date).dt.normalize()
    stock['available_at']=utc_series(stock.available_at)
    keys=['security_id','event_date','available_at']
    for _,group in stock.loc[stock.duplicated(keys,keep=False)].groupby(keys,observed=True):
        if len(group.drop_duplicates())>1: raise InputError('Conflicting stock initial-release vintages.')
    first=stock.sort_values(keys).drop_duplicates(['security_id','event_date'],keep='first')
    first=first.merge(calendar[['session','source_event_date','cutoff_at']],left_on='event_date',right_on='source_event_date',how='inner')
    for field in ['on_loan','shares_outstanding']:
        first[field]=pd.to_numeric(first[field],errors='raise')
        first.loc[first.available_at>first.cutoff_at,field]=np.nan
    members=memberships.copy(); members['session']=pd.to_datetime(members.session).dt.normalize()
    members['available_at']=utc_series(members.available_at,'membership available_at')
    members=members.merge(calendar[['session','cutoff_at']],on='session',how='inner',validate='many_to_one')
    members=members.loc[members.available_at<=members.cutoff_at]
    mkeys=['session','security_id','index_id','available_at']
    for _,group in members.loc[members.duplicated(mkeys,keep=False)].groupby(mkeys,observed=True):
        if len(group.drop_duplicates())>1: raise InputError('Conflicting index-membership vintages.')
    members=members.sort_values(mkeys).drop_duplicates(['session','security_id','index_id'],keep='last')
    if (members.groupby(['session','security_id'],observed=True).adv_eligible.nunique(dropna=False)>1).any():
        raise InputError('ADV eligibility cannot differ for the same stock/date across index memberships.')
    flags=members[['session','security_id','adv_eligible']].drop_duplicates()
    positions=first[['session','security_id','on_loan','shares_outstanding']].merge(flags,on=['session','security_id'],how='outer',validate='one_to_one')
    result=aggregate_stock_positioning(positions,members[['session','security_id','index_id']])
    return result.reindex(index=calendar.session)

def run_index_exports(settings):
    """Fast path requires aggregate positioning vintages + calendar; NO prices."""
    names=['index_metrics','sessions']
    missing=[f'{name}_path / {name}_columns' for name in names if not settings.get(name+'_path') or not settings.get(name+'_columns')]
    if missing: return {'status':'setup_required','missing':missing,'message':'Map initial-release index positioning metrics and scoring sessions; no prices required.'}
    try:
        data={name:load_table(settings[name+'_path'],settings[name+'_columns']) for name in names}
        metrics=initial_index_metrics(data['index_metrics'],data['sessions'])
        scores=index_crowding_scores(metrics,normalize=settings.get('normalize_252',False))
        output=absorption_ratio(scores)
        output.update(status='research_complete',metrics=metrics,scores=scores,alpha_validated=False)
        return output
    except (ValueError,OSError,KeyError,TypeError) as error:
        return {'status':'input_error','message':str(error),'alpha_validated':False}


# %% Invocation-local stock preparation (shared feature math, no global rebinding)
def _prepared_ema_contrasts(maximum_history):
    """Cache only one O(H*T) immutable decay geometry per half-life grid."""
    geometry = {}

    def contrasts(values, half_lives=(1,2,4,8,16,32,64,128), min_count=250):
        x = np.asarray(values,dtype=float)
        valid = np.isfinite(x); count = int(valid.sum())
        if count < min_count:
            return np.nan,np.nan,count
        key = tuple(half_lives)
        if key not in geometry:
            h = np.asarray(half_lives,dtype=float)
            if len(h)<3 or np.any(h<=0) or np.any(np.diff(h)<=0):
                raise InputError('Half-lives require at least3 increasing positive values.')
            ages = np.arange(maximum_history-1,-1,-1,dtype=float)
            kernel = np.exp2(-ages[None,:]/h[:,None])
            u = np.log2(h); u = u-u.mean()
            linear = u/np.linalg.norm(u)
            quadratic = u*u; quadratic -= quadratic.mean()
            quadratic -= linear*np.dot(linear,quadratic)
            quadratic /= np.linalg.norm(quadratic)
            for array in (kernel,linear,quadratic): array.setflags(write=False)
            geometry[key] = kernel,linear,quadratic
        kernel,linear,quadratic = geometry[key]
        # Same per-stock masked multiplication and matrix-vector reduction as
        # reference; no recursive EMA or cross-stock batched roundoff changes.
        weights = kernel[:,-len(x):]*valid[None,:]
        curve = (weights@np.where(valid,x,0.))/weights.sum(axis=1)
        return float(-linear@curve),float(quadratic@curve),count

    return contrasts


def _prepare_stock_context(lending,sessions,universe,config=None,events=None):
    """Private copies and static indexes only; as-of selection remains fresh."""
    config = Config() if config is None else config
    calendar = validate_inputs(lending,sessions,universe)
    data = lending.copy(deep=True)
    data["security_id"] = data.security_id.astype(str)
    data["event_date"] = pd.to_datetime(data.event_date,errors="raise").dt.normalize()
    if data.event_date.dt.tz is not None:
        raise InputError('event_date must be a local ASX session date without a timezone.')
    data["available_at"] = utc_series(data.available_at)
    keys = ["security_id","event_date","available_at"]
    conflict_rows = []
    for key,group in data.loc[data.duplicated(keys,keep=False)].groupby(keys,sort=False,observed=True):
        if len(group.drop_duplicates())>1:
            conflict_rows.append((key[1],key[2]))
    data = data.drop_duplicates().sort_values(keys).reset_index(drop=True)

    def history_asof_prepared(frame,decision_at):
        decision = utc_timestamp(decision_at)
        local_day = decision.tz_convert("Australia/Sydney").tz_localize(None).normalize()
        if any(day<=local_day and available<=decision for day,available in conflict_rows):
            raise InputError('Conflicting values at the same security/event_date/available_at; resolve the source conflict.')
        selected = data.loc[(data.available_at<=decision)&(data.event_date<=local_day)]
        return selected.drop_duplicates(["security_id","event_date"],keep="last").reset_index(drop=True)

    members = universe.copy(deep=True)
    members["session"] = pd.to_datetime(members.session).dt.normalize()
    members["available_at"] = utc_series(members.available_at,"universe available_at")
    universe_groups = {day:group for day,group in members.groupby("session",sort=False,observed=True)}
    empty_members = members.iloc[:0]

    def universe_at_prepared(frame,session,decision_at):
        group = universe_groups.get(pd.Timestamp(session).normalize(),empty_members)
        selected = group.loc[group.available_at<=utc_timestamp(decision_at)]
        key = ["security_id","session","available_at"]
        for _,duplicates in selected.loc[selected.duplicated(key,keep=False)].groupby(key,observed=True):
            if len(duplicates.drop_duplicates())>1:
                raise InputError('Conflicting point-in-time universe vintages.')
        return selected.sort_values(key).drop_duplicates(["session","security_id"],keep="last").reset_index(drop=True)

    prepared_events = None if events is None else events.copy(deep=True)
    event_groups = {}
    events_ready = False
    calendar_dates = pd.DatetimeIndex(calendar.session)

    def event_mask_prepared(sessions_arg,events_arg,security_id,decision_at):
        nonlocal events_ready,event_groups
        mask = np.zeros(len(calendar_dates),dtype=bool)
        # Match reference error boundaries: unused events are not validated on
        # empty/no-feature paths. Parse once when a mask is actually requested.
        if not events_ready:
            if prepared_events is not None and len(prepared_events):
                required = {"event_id","security_id","event_date","available_at","event_type","status"}
                if not required.issubset(prepared_events):
                    raise InputError(f'Events require {sorted(required)}')
                prepared_events["available_at"] = utc_series(prepared_events.available_at,"event available_at")
                # String keys match reference filtering without rewriting raw
                # payloads: integer1 and string'1' can still be conflicting rows.
                event_groups = {name:group for name,group in
                                prepared_events.groupby(prepared_events.security_id.astype(str),sort=False,observed=True)}
            events_ready = True
        group = event_groups.get(str(security_id))
        if group is None: return mask
        selected = group.loc[group.available_at<=utc_timestamp(decision_at)]
        key = ["event_id","available_at"]
        for _,duplicates in selected.loc[selected.duplicated(key,keep=False)].groupby(key,observed=True):
            if len(duplicates.drop_duplicates())>1:
                raise InputError('Conflicting event revision timestamp.')
        selected = selected.sort_values(key).drop_duplicates("event_id",keep="last")
        offsets = {"dividend":(-10,2),"meeting":(-20,2)}
        for row in selected.itertuples():
            if row.status=="cancelled": continue
            if row.status!="active" or row.event_type not in offsets:
                raise InputError('Event status/type is not defined; use active/cancelled and dividend/meeting.')
            day = pd.Timestamp(row.event_date).normalize()
            if day not in calendar_dates:
                raise InputError('Announced record date absent from ASX calendar; include the relevant future sessions.')
            index = calendar_dates.get_loc(day); low,high = offsets[row.event_type]
            mask[max(0,index+low):min(len(calendar_dates),index+high+1)] = True
        return mask

    def latest_lender_fraction(active,total):
        # The public panel validator already checked the complete source once.
        # Reference features_at uses only this result's final value. Delegate
        # the one-row arithmetic to preserve nullable/string numeric behavior.
        return lender_fraction(active.iloc[-1:],total.iloc[-1:])

    return {"calendar":calendar,"lending":data,"events":prepared_events,
            "universe_at":universe_at_prepared,"history_asof":history_asof_prepared,
            "event_mask":event_mask_prepared,"lender_fraction":latest_lender_fraction,
            "ema_contrasts":_prepared_ema_contrasts(len(calendar))}


def build_feature_panel(lending,sessions,universe,config=Config(),events=None):
    """Invocation-local preparation with fresh as-of snapshots and shared feature math."""
    prepared=_prepare_stock_context(lending,sessions,universe,config,events)
    output=[]
    for row in prepared["calendar"].itertuples():
        members=prepared["universe_at"](universe,row.session,row.decision_at)
        if len(members):
            snapshot=_features_at_impl(prepared["lending"],prepared["calendar"],members,
                                      row.decision_at,config,prepared["events"],_prepared=prepared)
            if len(snapshot): output.append(build_scores(snapshot,config))
    return pd.concat(output,ignore_index=True) if output else pd.DataFrame()
