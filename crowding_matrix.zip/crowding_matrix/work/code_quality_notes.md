# Code quality repairs and measured bounds

This pass repairs concrete software defects and measured repeated work. It changes no predictor, model, ranking policy, input feed or trading rule. Passing the listed controls is not a claim that every possible input is covered or that the code is globally optimal.

| Defect | Correct behavior now checked independently |
|---|---|
| Nullable ADV eligibility could discard an unknown constituent | Mixed/all-unknown object and nullable Boolean cohorts, including physical Parquet files, keep the aggregate missing; no partial mean or invented weights |
| Missing IDs became scored string placeholders | Actual missing/blank join IDs fail before string conversion; literal nonblank IDs preserve case, spaces, leading zeros and NA-like text |
| Nullable missing prices crashed numeric checks | Numeric arrays use explicit NaN; missing paths remain unobserved, and a selected missing-price stock is not replaced |
| Invalid Config silently changed selection/history | Central construction checks positive integer windows/counts, natural fraction/quantile domains and finite coefficients before empty exits; signed kappa and positive fractional half-lives remain valid |
| Empty AR created a phantom row | Empty index/output remains empty and latest matrix/as-of remain None |
| Infinite position quantities/denominators could produce false ratios | Known quantities must be finite and in domain; unknown remains missing |
| Infinite borrow availability passed short feasibility | Known infinity is rejected; unknown availability is explicitly False |
| Capacity used the available constraint when another was unknown | Both limits are required; unknown capacity stays NaN with not_assessed_missing_constraint status |

Independent expected-value tests also retain uncapped short squeeze losses and unchanged selection under missing outcomes/costs. Reference parity supplements those tests; it does not replace them.

The stock path computes seventeen normalizations in one columnwise block with each column's finite count, quantiles, midranks and missingness. Three sector-level median adjustments share group structure while retaining separate valid counts and fallback medians. Matched lender fractions are computed once per canonical source row and carried with their exact vintage. Masks, as-of selection and normalized scores are still fresh per decision. Empty missing-stock frames are allocated only when needed, and the fee array is converted once per row history.

The archived public runtime is the actual pre-repair/pre-batch source fdbc5ca6…; the current public runtime is a separate namespace. Paired measurements therefore describe the combined repair and optimization pass on identical valid fixtures, not an isolated optimization experiment. Both modules, input fingerprints, default configurations and all output values/types/order are checked, except the columns the 2026-10-30 methodology fixes deliberately add or change; those are declared in the benchmark driver and reported with their differences. Known defective inputs are covered by the independent regressions rather than expected to match the old implementation.

| Identical synthetic workload | Archived public | Current public | Observed ratio |
|---|---:|---:|---:|
|330sessions ×8stocks, all330decisions, original seed33 stage fixture|10.0816s|6.3065s|1.599×|
|330historysessions ×200stocks,10decisions|3.5921s|2.2862s|1.571×|
|330historysessions ×300stocks,10decisions|5.0060s|3.1973s|1.566×|
|330sessions ×200stocks, all330decisions, revisions/omissions|95.3792s|54.1679s|1.761×|

These are ordinary one-run wall times in fresh worker processes with one native thread; imports/fixture preparation and parity/export checks are outside the timed panel call. Process CPU and process-lifetime peak RSS are recorded separately. Full200-stock peak RSS was 400.43MiB before and 408.76MiB after, including libraries, fixture and outputs; faster does not imply a memory reduction. These timings include the 2026-10-30 methodology fixes; the same full 200-stock workload took 47.2558s before them, so the fixes cost roughly 15% (separate single runs). Do not compare these directly with earlier tracemalloc-instrumented timings or extrapolate them to7000stocks/HPC/database workloads.

Runtime, catalogue, profiler and tests are formatted and split at real top-level boundaries into small purpose-labeled cells. The plot is staged after its matrix prerequisites, before the remaining stock definitions. There are no runtime source-loader imports or hidden exec strings. The execution runner checks source-part completeness and semantic AST digests, then records the saved artifact's digest and any local failure purpose. Ruff is build-time tooling only.

The strategy explanation is explicit: long/short score selection is mirrored; short feasibility and entry-fee scenarios differ. Fixed holding periods are used on both sides. There are no separate learned buy/sell engines or dynamic exit triggers. Positive supplied availability is not an order-sized firm locate; fee/recall tail risk is not an integrated execution engine. The standalone cover ledger remains separate. Low short-lending crowding is not direct evidence of crowded-long ownership.
