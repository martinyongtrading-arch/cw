"""Compare actual archived/public and current/public code on one valid fixture.

This is a combined correctness-repair plus optimization comparison, not an
isolated performance attribution. Each implementation runs in a fresh child
process with one BLAS/OpenMP thread. Nothing runs merely by importing this file.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import runpy
import subprocess
import sys
import time

for variable in (
    "OMP_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
):
    os.environ[variable] = "1"

WORK = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")


def worker(args):
    import numpy as np
    import pandas as pd
    import psutil
    import sklearn.ensemble
    from threadpoolctl import threadpool_info, threadpool_limits

    source_hash = digest(args.source)
    api = runpy.run_path(str(args.source))
    helpers = runpy.run_path(str(WORK / "benchmark_asx_scale.py"))
    lending, calendar, universe, _, fixture = helpers["fixture_for"](
        api, args.size, sessions_count=330, decisions=10, seed=741
    )
    if args.full:
        universe = api["synthetic_inputs"](
            sessions_count=330, securities_count=args.size, seed=741
        )["universe"]
        fixture["evaluation_decisions"] = len(calendar)
        fixture["evaluation_dates"] = calendar.session.tolist()
        fixture["evaluation_universe_rows"] = len(universe)
        fixture["full_330_decision_backfill_measured"] = True
    identity = hashlib.sha256()
    for frame in (lending, calendar, universe):
        identity.update(
            pd.util.hash_pandas_object(frame, index=True).to_numpy().tobytes()
        )
        identity.update(str(list(frame.columns)).encode())
        identity.update(str(frame.dtypes.astype(str).tolist()).encode())
    config = api["Config"]()
    process = psutil.Process()
    with threadpool_limits(limits=1):
        pools = threadpool_info()
        if any(pool.get("num_threads", 1) != 1 for pool in pools):
            raise RuntimeError("One-thread BLAS/OpenMP constraint was not effective")
        memory_before = process.memory_info()._asdict()
        cpu_start = time.process_time()
        wall_start = time.perf_counter()
        panel = api["build_feature_panel"](lending, calendar, universe, config)
        wall_seconds = time.perf_counter() - wall_start
        cpu_seconds = time.process_time() - cpu_start
        memory_after = process.memory_info()._asdict()
    after_hash = digest(args.source)
    if source_hash != after_hash:
        raise RuntimeError("Implementation source changed during its measured call")
    expected_rows = args.size * fixture["evaluation_decisions"]
    if (
        len(panel) != expected_rows
        or panel.duplicated(["session", "security_id"]).any()
    ):
        raise AssertionError(
            "Unexpected output row count or duplicate security/session"
        )
    result = {
        "status": "measured",
        "implementation": "public build_feature_panel",
        "source_path": str(args.source.resolve()),
        "source_sha256": source_hash,
        "source_sha256_after": after_hash,
        "fixture_sha256": identity.hexdigest(),
        "fixture": fixture,
        "config_defaults": asdict(config),
        "ordinary_wall_seconds": wall_seconds,
        "process_cpu_seconds": cpu_seconds,
        "memory_before_bytes": memory_before,
        "memory_after_bytes": memory_after,
        "process_lifetime_peak_rss_bytes": memory_after.get("peak_wset"),
        "memory_scope": "fresh process; pre/post RSS and Windows lifetime peak working set include imports, fixture and outputs; no tracemalloc or sampling thread",
        "feature_rows": len(panel),
        "feature_columns": len(panel.columns),
        "decision_dates": int(panel.session.nunique()),
        "baseline_nonmissing_rows": int(panel.baseline.notna().sum()),
        "overlay_nonmissing_rows": int(panel.overlay.notna().sum()),
        "latest_row_missing_rows": int(panel.latest_row_missing.sum()),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "native_threadpools": pools,
        "warnings_are_errors": True,
        "versions": {
            name: importlib.metadata.version(name)
            for name in [
                "numpy",
                "pandas",
                "scipy",
                "scikit-learn",
                "threadpoolctl",
                "psutil",
            ]
        },
        "timing_scope": "one ordinary call; includes validation/preparation/all selected decisions/concat; excludes imports, fixture generation, fixture hashing, parity and export",
    }
    args.output.mkdir(parents=True, exist_ok=True)
    panel.to_pickle(args.output / "output.pkl")
    write_json(args.output / "measurement.json", result)
    print(
        json.dumps(
            {
                "source": args.source.name,
                "stocks": args.size,
                "decisions": result["decision_dates"],
                "wall_seconds": wall_seconds,
                "cpu_seconds": cpu_seconds,
                "rows": len(panel),
            }
        ),
        flush=True,
    )


def launch(source, size, folder, full):
    folder.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        "-W",
        "error",
        "-u",
        str(Path(__file__).resolve()),
        "--worker",
        "--source",
        str(source),
        "--size",
        str(size),
        "--output",
        str(folder),
    ]
    if full:
        command.append("--full")
    with (folder / "worker.log").open("w", encoding="utf-8") as stream:
        child = subprocess.Popen(
            command,
            cwd=str(WORK.parent),
            stdout=stream,
            stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        started = time.perf_counter()
        try:
            while True:
                try:
                    code = child.wait(timeout=30)
                    break
                except subprocess.TimeoutExpired:
                    print(
                        f"PROGRESS {source.name}: {size}stocks elapsed={time.perf_counter() - started:.0f}s",
                        flush=True,
                    )
        except BaseException:
            # Only this child's handle is affected; no process enumeration.
            child.terminate()
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=10)
            raise
    if code:
        raise RuntimeError(
            f"Worker failed with code{code}; see {folder / 'worker.log'}"
        )
    return json.loads((folder / "measurement.json").read_text(encoding="utf-8"))


def main(args):
    import numpy as np
    import pandas as pd

    archive = WORK / "code_quality_baseline.py"
    current = WORK / "notebook_source.py"
    args.output.mkdir(parents=True, exist_ok=True)
    result = {
        "status": "running",
        "synthetic_only": True,
        "scope": "actual archived-public versus current-public combined repair+optimization on valid synthetic stock histories",
        "baseline_label": "actual pre-repair/pre-batch archived public build_feature_panel",
        "current_label": "current repaired+batched public build_feature_panel",
        "baseline_source_sha256": digest(archive),
        "current_source_sha256": digest(current),
        "fixture_helper_sha256": digest(WORK / "benchmark_asx_scale.py"),
        "driver_sha256": digest(Path(__file__)),
        "workloads": [],
        "limitations": [
            "One fresh-process timing per case; OS/allocator caches and other app activity uncontrolled.",
            "Differences combine correctness repairs and optimization; no isolated attribution.",
            "Valid synthetic inputs do not exercise all new rejection paths.",
            "No empirical alpha, paid borrow, capacity, HPC, database or7000-stock certification.",
        ],
    }
    write_json(args.output / "benchmark.json", result)
    for size in args.sizes:
        suffix = f"{size}stocks_" + ("330decisions" if args.full else "10decisions")
        print(f"Measuring {suffix}: archived public then current public", flush=True)
        before = launch(archive, size, args.output / (suffix + "_archived"), args.full)
        after = launch(current, size, args.output / (suffix + "_current"), args.full)
        if before["fixture_sha256"] != after["fixture_sha256"]:
            raise AssertionError(
                "Implementations did not receive identical synthetic fixtures"
            )
        if before["config_defaults"] != after["config_defaults"]:
            raise AssertionError("Archived and current Config defaults differ")
        left = pd.read_pickle(args.output / (suffix + "_archived") / "output.pkl")
        right = pd.read_pickle(args.output / (suffix + "_current") / "output.pkl")
        left = (
            left.sort_values(["session", "security_id"])
            .reset_index(drop=True)
            .sort_index(axis=1)
        )
        right = (
            right.sort_values(["session", "security_id"])
            .reset_index(drop=True)
            .sort_index(axis=1)
        )
        pd.testing.assert_frame_equal(
            left, right, check_exact=False, rtol=1e-10, atol=1e-12, check_dtype=True
        )
        maximum = 0.0
        for name in left.select_dtypes(include=["number"]):
            a, b = left[name].to_numpy(float), right[name].to_numpy(float)
            valid = np.isfinite(a) & np.isfinite(b)
            if valid.any():
                maximum = max(maximum, float(np.max(np.abs(a[valid] - b[valid]))))
        result["workloads"].append(
            {
                "stocks": size,
                "archived_public": before,
                "current_public": after,
                "fixture_and_default_config_match": True,
                "output_parity": {
                    "passed": True,
                    "strict_dtypes_and_missingness": True,
                    "maximum_absolute_numeric_difference": maximum,
                    "rtol": 1e-10,
                    "atol": 1e-12,
                },
                "observed_combined_speedup_this_fixture_only": before[
                    "ordinary_wall_seconds"
                ]
                / after["ordinary_wall_seconds"],
            }
        )
        write_json(args.output / "benchmark.json", result)
    if (
        digest(archive) != result["baseline_source_sha256"]
        or digest(current) != result["current_source_sha256"]
    ):
        raise RuntimeError("An implementation changed during the comparison")
    result["status"] = "measured"
    result["source_hashes_unchanged_after_all_cases"] = True
    write_json(args.output / "benchmark.json", result)
    print(
        json.dumps({"status": result["status"], "output": str(args.output)}), flush=True
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", nargs="+", type=int, default=[200, 300])
    parser.add_argument("--full", action="store_true")
    parser.add_argument("--output", type=Path, default=WORK / "code_quality_benchmark")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--source", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--size", type=int, help=argparse.SUPPRESS)
    arguments = parser.parse_args()
    worker(arguments) if arguments.worker else main(arguments)
