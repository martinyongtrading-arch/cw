# Stock crowding across indices and sectors

Research date: 30 October 2026. Published results, vendor claims and hypotheses below are not validation of this notebook's signals. All comparisons concern stocks. No futures, options, macro or other asset-class signal is introduced.

| Stock comparison | Evidence or official context | Frozen comparison and limitation |
|---|---|---|
| ASX200 versus incremental ASX300 | Official index methodology differentiates the large/liquid200 and broader300. Small Ordinaries is ASX300 minus ASX100, not stocks201–300. | Use historical ASX200 and the disjoint ASX300-minus-ASX200 sleeve; report fullASX300 separately. Smaller-stock lending and executable capacity differences are hypotheses. |
| BeyondASX300 | All Ordinaries targets500largeASXsecurities with different liquidity/investable-weight eligibility. | AllOrdinaries-minus-ASX300 is exploratory. Missing loans do not mean uncrowded. |
| US large/small stock indices | Federal Reserve research at the Russell1000/2000cutoff, principal2006–2018sample, finds passive ownership can raise lending supply and short interest/utilisation together with little fee change. | Freeze the score and compare dated Russell1000/2000membership; ownership/supply changes are not automatically bearish demand. |
| Developed exUS | Saffi/Sigurdsson study lending constraints and efficiency across26countries,2005–2008. EAFE is large/midcap, not allcap, and includesAustralia. | Remove Australia for external replication and report country slices. Do not assume one international lending regime. |
| Japan | JPX reporting/public-disclosure thresholds differ; price restrictions affect execution in stressed stocks. | TOPIX/MSCIJapanmembership does not substitute for actual borrow availability. |
| HongKong | Regulated shorting uses designated securities, covered sales and applicable tick rules. | Combine historical stock-index membership with contemporaneous eligibility; do not treat all indexstocks as shortable. |
| Europe/UK | Public short-position reports are threshold-censored and regimes differ by jurisdiction and time. | Keep public positions separate from vendor on-loan fields; no splice across changing rules. |
| AustralianMaterials/mining | No direct published validation of this frozen signal in Australianmining was found. | Commodity/financing shocks and capacity differences are hypotheses; GICSMaterials is not identical to mining. |
| Financials/RealEstate | GICS separated RealEstate in2016; historical sector labels change. | Use contemporaneous labels; report stock count and concentration. Do not backfill current classifications. |

Scores are computed on their frozen eligible cross-section **before** diagnostic sector/index slicing. Slices report coverage and composition, not independently retuned models. Where using index aggregates, keep dated membership/weights and report the fraction removed by the supplied ADV mask. ADV percentiles control relative selection; they do not establish absolute execution capacity. Overlapping indices share stock inputs and therefore mechanical correlation.

Primary sources:

- [S&P/ASX index methodology](https://www.spglobal.com/spdji/en/methodology/article/sp-asx-australian-indices-methodology/)
- [Comerton-Forde etal, Australian short-selling metrics; ASX200 sample2012–2014](https://bizpep.com/shortsales/ComertonFordeAssessingInformationContentShortSellingMetricsUsingDailyDisclosures.pdf)
- [Federal Reserve, passive ownership and securities lending,2022](https://www.federalreserve.gov/econres/ifdp/files/ifdp1365.pdf)
- [Saffi/Sigurdsson author paper record](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=949027)
- [MSCI EAFE definition](https://www.msci.com/indexes/index/990300/msci-eafe-index)
- [JPX short-sale rules](https://www.jpx.co.jp/english/equities/trading/regulations/02.html)
- [HKEX regulated short selling](https://www.hkex.com.hk/Services/Trading/Securities/Overview/Regulated-Short-Selling?sc_lang=en)
- [ESMA significant net short-position disclosure](https://www.esma.europa.eu/publications-and-data/interactive-single-rulebook/ssr/article-6-public-disclosure-significant-net)
- [FCA short-position notification/disclosure](https://www.fca.org.uk/markets/short-selling/notification-disclosure-net-short-positions)
- [S&P/MSCI GICS RealEstate announcement](https://press.spglobal.com/2014-11-10-S-P-Dow-Jones-Indices-And-MSCI-Announce-The-Creation-Of-A-Real-Estate-Sector-In-The-Global-Industry-Classification-Standard-GICS-Structure)
- [S&P securities-finance research summary, vendor claims; pp33–34 crowding](https://cdn.ihsmarkit.com/www/pdf/0124/Securities-Finance---Summary-of-Research-Papers---Oct-2023.pdf)
- [ASIC short-position publication timing](https://www.asic.gov.au/regulatory-resources/markets/short-selling/short-selling-reporting-short-position-reporting)
- [FINRA short interest versus daily short volume](https://www.finra.org/investors/insights/short-interest)

# Small stock-signal menu and independent critic

These are bounded, disabled-by-default research alternatives, not an enumeration search. Existing20-session changes and250-session risk windows are reused. Implementation priority is not an expected-performance ranking.

| Candidate | Natural-unit definition | Mechanism and guard | Fragility0robust–10fragile |
|---|---|---|---:|
| Supply/quantity decomposition | cQ=log(Q_t/Q_t-20); cL=−log(L_t/L_t-20) | Separates borrowing growth from supply withdrawal. ΔlogU=cQ+cL only for matched populations/units. Positive endpoints only; zeros excluded explicitly, neverepsilon-filled. |4|
| Fee level | log(1+annual_fee_bps/1bp) | Price of borrowing constraint, also a direct cost. A high value is not automatically a profitable short. |4|
| Fee-level standard deviation | log(1+sd250(fee_bps,ddof1)/1bp) | Holding-cost uncertainty; min200real observations, no filling, no sqrt250annualisation. Known fee-definition changes reset history. Not equivalent to fitted published ShortRisk. |6|
| Active-lender fraction | A/N | A distinct lenders with open loans, N SAMEentitytype/panel/stock/date with total inventory including lent stock; requireA subsetN. ZeroNundefined; A>Ninvalid. Not ActiveUtilisation's proprietary inventory filter. |7|
| Fee/quantity quadrant | +1 ifΔ20fee>0andΔ20logQ>0; −1 ifboth<0; otherwise0 | Demand-consistent, not structural identification in an aggregate panel. Missing endpoints remainmissing; zero is unclassified, not uncrowded. |6|

Construct first in natural units; then use the same decision-time cross-section for normalisation. Do not separately normaliseQandLandclaimtheir logidentity still holds. Fee volatility's return-premium interpretation is contested; the user's experience of potency remains an observation that has not been independently checked here. U×Q/S was rejected from the initial menu because it counts the sameQnumerator twice without establishing incremental economic content. No new model family is needed to inspect these simple ingredients.

Sources: [Cohen/Diether/Malloy](https://onlinelibrary.wiley.com/doi/10.1111/j.1540-6261.2007.01269.x), [Engelberg/Reed/Ringgenberg author paper](https://uncipc.org/wp-content/uploads/2017/06/Reed_2018-11wp.pdf), [Muravyev/Pearson/Pollet counterevidence](https://jhfinance.web.unc.edu/wp-content/uploads/sites/12369/2016/11/2017JH_MuravyevPearsonPollet.pdf), [RBA Australian stock lending](https://www.rba.gov.au/publications/bulletin/2014/dec/5.html), [S&P factor definitions, vendor source](https://cdn.ihsmarkit.com/www/pdf/0923/Securities-Finance-Research---Insights-from-South-Korea---December-2022.pdf).

# Index positioning matrix and absorption-ratio specification

The aggregate positioning metric is the **equal-stock mean of on-loan quantity/shares outstanding** within each historical stock index after its supplied point-in-time ADV eligibility mask. This comes from the bundle's Positioning theme. It uses no valuation, OHLCV proxy or inferred holdings. A ready-made aggregate metric can enter directly. Missing included constituent metrics make that index aggregate unavailable rather than silently changing its weights.

Component1 ranks aggregate metrics across indices each day with average ranks divided by finite index count, giving values in(0,1]. It is a relative measure: it cannot reveal a common absolute increase across all indices. Optional own-history znormalisation uses252sessions and min_periods252; default rawQ/S aggregation needs no time normalisation. For aggregate vintages use the **initial release only**, and leave a daymissing when its initial release was unavailable at that day's decision. This component differs deliberately from the stock framework's latest-vintage-known-at-decision research history.

Component2 uses exactly60first differences endingt−1, requiring61score rows. Rank each index's changes **through time within that window**, standardise those ranks, then form anN×N Spearman correlation. Drop incomplete or constant columns, not time rows; recalculateNandk=N//5, requireN≥20. AtN>60 use constant-correlation Ledoit–Wolf shrinkage following the authors'2021estimator and sample denominatorT−1. The proseN>60rule takes precedence over the contradictory0.5×windowpseudocode. SVD of the correlation matrix yields its nonnegative eigenvalues directly; do not square them. A singularmatrix gets1e−6diagonalridge. The diagonal is retained. Only the latest matrix is stored; no7000×7000matrix or dailyN×Narchive is allocated.

AR=sum(topkeigenvalues)/trace. Uniform eigenvalues implyAR=k/N, approximately0.2, **not1/N**. delta_AR=(SMA15(AR)−SMA252(AR))/SD252(ARlevels,ddof1), all full windows. A zero denominator ismissing. The threshold±1is a descriptive standardised shift, not a calibrated probability or trading rule.

This is an **adaptation to ranked stock-crowding changes**, not replication of Kritzmanetal's original asset-return covariance estimator. Rank transformation discards magnitude and is not a general tail-dependence estimator. Constant-correlation shrinkage also affects the spectrum. Overlapping stock-index memberships and daily cross-sectional ranking create mechanical dependence. The latest index labels, N,k,uniformbaseline, missing/constant exclusions, shrinkage andridge diagnostics are retained.

Primary sources: [Kritzmanetal2011, StateStreet-hosted paper](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/275a6997-b913-47da-b487-948d83f7765e/jpm_principal_components_as_a_measure_of_systemic_risk.pdf), [Kinlaw/Kritzman/Turkington2012](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/a95eda2f-5397-4528-ba3c-34ef4c2060ab/jpm_toward_determining_systemic_importance.pdf), [Ledoit/Wolf constant-correlation paper](https://econ-papers.upf.edu/papers/691.pdf), [author's exact2021code](https://github.com/oledoit/covShrinkage/blob/main/covCor.m), [sklearn's different scaled-identity target](https://scikit-learn.org/stable/modules/generated/sklearn.covariance.LedoitWolf.html).

No claim is made that score-AR leads return co-movement. A return-AR of stocks selected by prior available crowding scores answers a different conditional question and may reflect common sector or market exposures. PositionHHI needs actual compatible nonnegative positions; inverseHHI is effective concentration, not independence. Neither extra data set is fetched or invented, and neither is required to run the implemented score-matrix path.

# GICS2/4/6/8 and equity-index consult

The April2026GICS methodology has11sectors,25industrygroups,74industries and163sub-industries. Its hierarchy is2-digitSector →4-digitIndustryGroup →6-digitIndustry →8-digitSub-Industry. Example:15Materials →1510Materials →151040Metals&Mining →15104030Gold. These are descriptive views of the **same frozen stock broker/lending scores**, not independent model inputs. [MSCI/S&P methodology, April2026edition](https://www.msci.com/indexes/documents/methodology/1_MSCI_Global_Industry_Classification_Standard_GICS_Methodology_20250220.pdf)

Use supplied effective-date and availability history. Derive ancestors only from validated supplied detail, never descendants from a sector label. Historical ASX export formats could zero-fill unavailable detail:15104000representedindustry-level information and15100000industry-group information. An8-character string therefore does not alone establish sub-industry detail; check the actual export/taxonomy vintage. [Historical ASX format example](https://asxonline.com/content/dam/asxonline/public/notices/2018/mar/ASX%20Market%20Information%20Notice%201618%20Appendix%201%20-%20Updated%20GICS%20Code%20Table%20and%20GICS%20Description.pdf)

Sector-label summaries are implemented and pool stock-date rows across the supplied sample. GICS4/6/8 hierarchy views are methodology-only and are not implemented in this notebook; supplied detailed codes alone do not enable them. The runtime accepts dated sector labels, not validated GICS code parsing. For a future supplied hierarchy, fine groups may be sparse: eligible/valid/classification-known counts, observed weight mass and unclassified residual are necessary context. Parent means reconcile using child counts/weights, not a mean of unequal child means. A classification-only change must not alter the underlying stock score.

Equal-stock averages of per-stockQ/S or matchedutilisation are interpretable summaries. Pooling raw share counts across securities changes weights when a stock splits. Summed broker counts do not become unique independent participants. Fee group averages are not executable borrow costs. With incomplete coverage, an observed-stock group mean is distinct from the strict complete-index aggregate used by the ARpath.

ASX200/300/AllOrdinaries and their disjoint differences diagnose size/composition; nested-index agreement is not independent confirmation. Keep GICS levels separate rather than putting every parent/child into the same ARmatrix. Eleven2-digit sectors alone do not meet the unchangedN≥20ARrequirement. FTSEGEIS usesICB, so its sector labels must not silently become GICS. Applying supplied stockGICS toFTSEconstituents is a separate customview. [S&P/ASX methodology](https://www.spglobal.com/spdji/en/documents/methodologies/methodology-sp-asx-australian-indices.pdf), [FTSEGEIS rules](https://www.lseg.com/content/dam/ftse-russell/en_us/documents/ground-rules/ftse-global-equity-index-series-ground-rules.pdf)

Global equity-index comparisons need supplier-aligned aggregates, a declared commonUTCcutoff and the real local-source session mapping. The ASXsource calendar is not an automatic global calendar. A hierarchy display, a new index cohort or a constituent reclassification cannot silently rerank or retune the stock score.
