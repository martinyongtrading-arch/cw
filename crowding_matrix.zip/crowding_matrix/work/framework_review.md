# Independent structural review: stock crowding framework

**Scope and verdict.** This reviews `framework.md` as submitted, not its attached handoff instructions. It concerns crowding in individual stocks through equity lending. Sector, industry and stock-index membership may define evaluation slices; they do not introduce other asset classes or trading instruments. No market data were loaded, models fitted, performance estimated or empirical perturbation tests run. The four passes below are a bounded structural review, not four rounds of empirical validation. The proposed implementation can correct these defects; those corrections do not retroactively improve the submitted framework's scores.

The design has useful separation of availability, economic mechanisms, feature families and incremental evaluation. It is nevertheless unsuitable for production as written. Its main weakness is that several careful-sounding safeguards do not enforce the property claimed: a lag is not a vintage, horizon orthogonality is not feature independence, a return rank is not money, and a separate testing block is not a fresh error budget.

## Pass 1 — architecture, evidence and required corrections

Scores are **0 = unsound, 10 = sound**, qualitative structural judgements with no statistical calibration. Question numbering deliberately retains the original omission of 8.

| Dimension | Score | Specific issues (framework section) | Suggested fix | Literature reference |
|---|---:|---|---|---|
| 1. Logical consistency | 4 | Horizon curvature called acceleration; fixed-prior replication claimed despite nonlinear scaling (§§5.2,6.3). | Rename curvature; treat prior similarity as approximate. | Direct algebraic counterexamples in this review. |
| 2. Bias control | 3 | Guessed lags do not establish vintages; repeated blocks reuse alpha (§§3.4,5.1,9.5). | Reconstruct as-of histories; allocate one programme error budget. | [Romano–Wolf](https://econ-papers.upf.edu/papers/712.pdf). |
| 3. Robustness to parameter fragility | 3 | Thresholds and availability-pattern scaling change exposures discontinuously (§§5.7,6.2). | Freeze weights/cohort and run declared perturbations. | Structural audit; no published threshold validates these defaults. |
| 4. Resistance to overengineering | 2 | Model ladders precede a decisive incremental question (§§6.4–6.8,10). | Start with baseline versus one fixed slope overlay. | [Romano–Wolf](https://econ-papers.upf.edu/papers/712.pdf), for selection control. |
| 5. Regime robustness | 4 | Field-definition changes can masquerade as economic history (§§3.1,5.3,7). | Reset histories at confirmed measurement breaks. | [Engelberg–Reed–Ringgenberg](https://uncipc.org/wp-content/uploads/2017/06/Reed_2018-11wp.pdf), economic risk motivation only. |
| 6. Costs and implementation | 3 | Recall haircut and return ranks are not monetary holdings (§§8.2,9.6). | Use signed un-clipped cashflows and explicit borrow scenarios. | [RBA equity lending](https://www.rba.gov.au/publications/bulletin/2014/dec/5.html). |
| 7. Falsifiability | 4 | New blocks/redesigns allow repeated opportunities to pass (§§9.5,9.8). | One registered comparison, explicit failure and unused evidence. | [Romano–Wolf](https://econ-papers.upf.edu/papers/712.pdf). |
| 9. Feature construction audit | 2 | Absence-to-zero and gap updates can manufacture flows (§§5.1–5.2). | Preserve missing sessions and declare causal EMA weights. | [pandas EWM semantics](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.ewm.html). |

### Critical issue: the information set is not yet defined

Sections 3.4 and 5.1 permit a conservative guessed lag. This cannot establish that an algorithmic historical observation existed then. An event date identifies what an observation describes; `available_at` identifies when its vintage became usable. Selecting the latest revised history once and then rolling it leaks revisions into earlier decisions even if every output is shifted.

**Require a canonical field contract and reconstruct the entire input history as of each decision timestamp.** Select the latest eligible vintage for each stock/event-date/field. Include denominators, universe membership and announced events in that availability contract. Resolve or reject conflicting identical-timestamp vintages explicitly. A single row timestamp is acceptable only when it bounds every field used in the row. Label files without real vintages as retrospective research inputs; do not certify them as point-in-time. Archive future deliveries without overwriting prior vintages.

The absence rule is independently critical: a missing covered-stock row becomes zero loans, zero brokers and sometimes zero utilisation. A delivery omission therefore becomes an apparent liquidation, followed by an apparent rebuilding when delivery resumes. **Preserve absence as missing.** Distinguish confirmed economic zero, undefined ratio, missing delivery and confirmed exit. Unchanged values alone do not prove stale data; valid inventory can remain constant.

### Major issue: the mathematics does not support the names

For a steady temporal ramp, an infinite-history EMA is the current level minus the ramp rate times the EMA's mean lag. That mean lag is nonlinear in log half-life. Projecting those EMAs onto a quadratic in log half-life therefore generally produces nonzero curvature even though temporal acceleration is zero. **Rename it horizon curvature and remove its default acceleration interpretation and directional weight.** A genuine second-difference construction is a different, separately justified feature.

If the horizon basis is orthonormal, projected covariance is still `B' Sigma B`; it is diagonal only under additional conditions on the horizon covariance. **Use orthogonality to describe the basis, not independent economic information.** Likewise, a combination-correlation formula derived from Pearson covariance is an identity under its assumptions, not proof that two features complement one another. Effective rank measures covariance geometry, not incremental predictive content; a low-variance direction can still matter.

**Delete the effective-rank stopping rule and the claim that stronger ridge shrinkage exactly reproduces O2.** O2 includes date-dependent standard deviations, clipping and availability-pattern transformations. A single fixed prior vector generally cannot reproduce that nonlinear, changing mapping. Retain effective rank and prior similarity as diagnostics only.

### Major issue: the comparison changes more than the signal

Trimming each model's own most-crowded hard-to-borrow tail changes the tested stocks as the score changes. Availability-pattern z-scores also make one stock's overlay scale depend on other stocks with the same missing-feature pattern. Small patterns can receive large, unstable rescaling. The result combines a feature experiment, universe experiment and missingness experiment.

**Freeze one decision-time feasibility set before comparing models. Fix family weights; give missing optional features a neutral contribution without renormalising the remaining families upward.** Report missingness and coverage losses. Use a single eligible stock cohort for same-date normalisation and paired evaluation. Keep stock selection based on the score distinct from feasibility. Preserve a complete-case analysis only as a labelled sensitivity.

### Major issue: cost and inferential gates do not match deployment

A mean normal-score return can improve while dollar losses worsen, because ranks discard magnitudes. Clipped targets are a possible fitting choice, but clipped or ranked evaluation cannot measure squeeze losses, capital drawdown or financing needs. A signed return over nine sessions after recall is not inherently a cost: it can have either sign and can duplicate price exposure already included elsewhere.

**Evaluate actual signed holdings and un-clipped cashflows.** Specify entry, exit, rebalance, borrow accrual, execution charges and deterministic forced-cover scenarios. Accrue annual fee rates over the contractual calendar-day basis, including non-trading days. Do not double-count distributions already included in total returns. Separate known realised costs from prospective estimates and unknown locates. Historical descriptions of Australian lending contracts establish the relevance of recalls and intermediation, not the current terms of a particular loan. [RBA, *The Equity Securities Lending Market*](https://www.rba.gov.au/publications/bulletin/2014/dec/5.html)

Applying Holm at the same alpha to successive independent blocks does not control the probability of any false rejection across the whole programme at that alpha. Logging an experiment records selection; it does not remove selection. **Register one initial comparison and one global error-budget policy before looking at outcomes.** Treat later ideas as new research requiring unused evidence or an explicitly allocated remaining budget. Dependence-aware multiple testing is possible, but its assumptions and resampling design remain part of the procedure. [Romano and Wolf, author working paper](https://econ-papers.upf.edu/papers/712.pdf)

### Literature boundary

Published equity-lending findings motivate hypotheses; they do not establish transportability to these ASX fields, histories, costs or definitions. Fee/quantity identification in one lender's data is not automatically equivalent to a quadrant built from vendor aggregates. [Cohen, Diether and Malloy, *Supply and Demand Shifts in the Shorting Market*](https://diether.org/papers/supplyanddemand.pdf)

Historical fee variance is related to the short-selling-risk literature, but the main ShortRisk measure projects fee variance on other characteristics. A rolling fee standard deviation is not a replication of that fitted measure. [Engelberg, Reed and Ringgenberg, author working paper](https://uncipc.org/wp-content/uploads/2017/06/Reed_2018-11wp.pdf) An earlier primary working paper by Muravyev, Pearson and Pollet challenges a substantial lending-fee risk premium using option-implied fees. This is competing mechanism evidence, not proof that a fee feature cannot forecast stock returns; options are cited as research identification only, not added to this stock framework. [Muravyev, Pearson and Pollet, 2016 working paper](https://jhfinance.web.unc.edu/wp-content/uploads/sites/12369/2016/11/2017JH_MuravyevPearsonPollet.pdf)

## Pass 2 — newly exposed issues only

**The masking rules weaken the stated minimum.** Requiring 80% of unmasked sessions while permitting half the window to be masked allows only 40% of the original window to contain observations. A 250-session statistic may then use 100 observations despite the separate 200-observation convention. **Apply minimum valid observations against the full declared session window.** Report masks separately and do not silently redefine the window's denominator.

**The gap EMA assigns the newest observation to the whole gap.** The update `(1-lambda^g)*x_t` puts increasing weight on the newly observed endpoint as the gap length grows; it is not an innocent implementation of skipping unknown observations. **Declare one causal missing-data rule and normalise weights over actual observed session positions.** Require adequate history and coverage for every horizon. `adjust`, `ignore_na` and `min_periods` are substantive choices, not interchangeable API details. [pandas EWM reference](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.ewm.html)

**Clipping is not strictly monotonic.** It creates ties and destroys distinctions at the tail; trees are not invariant to that information loss. Repeated clipping at field, theme and final score levels can also change the linear weights the design claims to preserve. **Clip once at a declared feature stage if required; preserve raw values and evaluate un-clipped outcomes.** A utilisation value above 100 may signal a population mismatch. Capping it does not fix that mismatch.

**Calendar dates alone are insufficient at a refit boundary.** A label ending on the refit date may not be available before a morning fit. **Compare label availability timestamps with the actual fit cutoff**, rather than admitting equality solely by date. Causal feature-window overlap between training and test is not automatically leakage; overlapping forward labels and unobserved end returns are different problems.

**Corporate actions can manufacture flows.** Splitting Q but not S, or mixing adjusted historical quantities with contemporary unadjusted denominators, breaks Q/S. Dividing a projected quantity by current shares outstanding avoids one denominator-change effect but does not make quantity flow identical to a change in ownership fraction. **Specify consistent split units, security identity and point-in-time denominator timing.** Test a synthetic split for invariance and label the economic quantity actually measured.

## Pass 3 — most likely production failure and cheapest experiment

The most likely operational failure is a vendor delivery or definition discontinuity being interpreted as new stock crowding. Missing rows, contributor changes, revised algorithmic inventories and fee resets all propagate into the high-weight flow family and longer-window unusualness or instability. Cross-sectional normalisation can conceal a common break while exaggerating affected subsets. This is a qualitative ranking of structural exposure, not an estimated probability.

The cheapest no-market-data experiment is a small deterministic panel with a session calendar and six synthetic stocks: constant values, rising values, falling values, a split, a missing delivery and a revised historical event. Give every record an availability timestamp. Recompute a decision before and after appending a future revision; earlier output must be identical. Delete a row; it must not become an economic zero. Introduce a known definition change; its rolling histories must reset or become unavailable. Apply a two-for-one split consistently; utilisation and Q/S must be unchanged. A flat field must have zero variability and zero EMA contrast. A linear ramp must expose the original curvature misinterpretation. These are machinery invariants, with no claim about alpha.

## Pass 4 — monitor and fallback, then stop

The final issue is that falling back to the baseline can preserve the same broken data dependency. If an overlay fails, a separately validated baseline is a sensible fallback. If both depend on corrupted utilisation, missing rows or an unverified vendor vintage, the baseline is not a safe substitute.

**Separate model failure from input failure.** Monitor arrival delays, missingness, field ranges, definition versions, feasible short coverage, turnover and realised-versus-assumed costs. On optional-feature failure, neutralise that contribution under fixed weights. On failure of mandatory baseline inputs or short feasibility, suppress new affected decisions and use the independently approved position-management procedure; do not manufacture scores or assume a locate. Record decisions and the exact vintages used. Stop this structural review here: four passes, no open-ended refinement loop.

## Feature-construction audit

Fragility is **0 = robust, 10 = fragile**, opposite to the framework soundness scores. These are provisional structural assessments. **LB means load-bearing**, not look-ahead bias: “yes” identifies features whose failure materially changes the baseline or the default overlay; “conditional” identifies dependencies that become load-bearing only if promoted. Actual dependence and perturbation effects require user data. Current observations are legitimate when actually available at the decision timestamp; `shift(1)` is neither universally required nor a cure for unknown availability.

### All 16 template features

| Template feature(s) | Count | Fragility | Structural LB | Required construction correction |
|---|---:|---:|---|---|
| Scarcity level: utilisation | 1 | 6 | Yes: baseline | Declare plain/Active, value/share basis, population and units. Validate denominator; preserve zero versus missing. Do not cure invalid ratios by capping. |
| Positioning level: on-loan measure | 1 | 6 | Yes: baseline | Freeze actual baseline formula, Q/S or otherwise. Require consistent adjustments, population and denominator vintage. |
| Participation level: broker/agent count | 1 | 6 | Yes: baseline | Define entity type and active meaning. Counts of transactions, intermediaries and beneficial owners are not interchangeable. |
| Scarcity, Positioning, Participation EMA slopes | 3 | 7 | Yes: default overlay | Use session-indexed, causal, normalised weights with fixed horizons, adequate coverage and matched units. Explain slope sign and effective memory; no claim of new independent information. |
| Scarcity, Positioning, Participation horizon curvatures | 3 | 9 | Conditional; default weights currently expose score | Remove acceleration name and default directional weight. Report as diagnostic until independently justified. Orthogonality alone does not validate it. |
| Scarcity, Positioning, Participation own-history unusualness | 3 | 8 | Conditional; substantial default path weight | Declare whether current bar enters moments. Prefer an explicitly prior-window reference when the question is surprise versus prior history. Fix variance floor in natural units; flag constant history instead of disguising unavailable evidence. |
| Scarcity utilisation instability | 1 | 8 | Conditional | Define variance of levels, not changes; ddof, units, 250 sessions and at least 200 valid observations. Trend and bounded support confound a risk interpretation. Reset at definition breaks. |
| Scarcity, Positioning, Participation within-GICS levels | 3 | 7 | Conditional | Use contemporaneously known classification and one eligible stock cohort. Declare small-group fallback and tie rules. Subtracting a peer median does not isolate stock-specific causality. |
| **Total** | **16** | | | |

For rolling features, separate the exact calendar window, minimum valid count, observed span, missing count and masked count. Two stocks with 200 valid observations within the same 250 sessions can still have different effective histories. Do not compress missing sessions or count repeated forward fills as fresh observations. Store coverage diagnostics beside scores. Long EMA half-lives can retain substantial initialisation influence after 250 observations; the history rule is a convention, not a proof of convergence.

### Optional features, flags and stock cross-sectional states

| Construction | Fragility | LB | Audit |
|---|---:|---|---|
| Active lender fraction A/N | 8 | Conditional if promoted | Require matched distinct-entity sets and A subset N. N must include the same population's lent inventory; broker count is not a valid substitute. N=0 is undefined, A=0 with N>0 valid, A>N invalid. Report low-N discreteness and contributor changes. |
| Fee level and fee-level standard deviation | 7 / 8 | Conditional if promoted | Use actual annualised fee rates in declared units; DCBS bins and rebates are not interchangeable rates. Require consistent definition/population and reset confirmed breaks. Neither a universal 2018 cutoff nor an invented revision lag establishes comparability. |
| Days to cover Q/ADV | 7 | Conditional | Match share units and exact trailing volume window. Zero/near-zero volume and trading suspensions destabilise the ratio. Do not infer the actual time needed to exit a position. |
| Supply change and lender concentration | 8 | Conditional | Supply depends on panel definitions; concentration requires actual lender shares, not just counts. Unknown denominator scope disables the feature. |
| Float-scaled positioning | 8 | Conditional | Require point-in-time float and effective dates; revisions, unlocks and index-methodology changes can dominate. |
| Polynomial terms and interactions | 8 | Conditional | Define raw units or training-only scaling. Centered products include low-low as well as high-high; retain main effects. Ranks avoid units but remain cohort-dependent. Multiple thresholds are additional hypotheses. |
| Missing, stale, event and unborrowable flags | 7 | Conditional; mandatory for controls | These describe observation or implementation state, not established return predictors. Use announcement timestamps; never backfill knowledge of an event. Missing supply is not proven unborrowability. |
| Sector/industry crowding and stock-market state summaries | 7 | Conditional | Construct only from the eligible equity universe known then. Freeze weights and membership. A state computed from revised constituents is not historical state. No new asset-class signals. |

### Independent audit of the bounded five-candidate menu

1. **Quantity/supply decomposition:** report `Delta log U = Delta log Q - Delta log L` only where all quantities are positive, definitions match and the vendor ratio actually uses them. It is an accounting decomposition, not three independent signals. Retain zero-loan onset/exit counts; do not replace log zero by an arbitrary epsilon. Verdict: useful diagnostic; no extra default weight.
2. **Fee level:** `log1p(fee_bp/1 bp)` is a transparent stock-lending state variable, conditional on confirmed field meaning and units. The one-basis-point scale is a declared transformation choice. Lender-side or indicative fees are not automatically the investor's executable cost. Verdict: conditional diagnostic, not a validated short decision.
3. **Fee standard deviation:** use the sample SD of annualised fee levels over exactly 250 stock-market sessions, minimum 200 observations, no fill, no square-root-of-250 annualisation. State current-bar inclusion; require a single definition regime. SD measures dispersion of rates, not realised borrowing-cost uncertainty conditional on all information. Verdict: requested research candidate; no asserted risk premium or expected return sign.
4. **Active lender fraction:** A/N measures participation among matched eligible lenders, not spare loan capacity, lender concentration or Active Utilisation. Two stocks with A/N=1 can have very different lending quantities and capacity. Changing A/N can reflect numerator activity, denominator entry or contributor coverage. Verdict: conditional on proprietary dictionary confirmation; provisional fragility 8/10.
5. **Twenty-session fee/quantity quadrant:** `+1` for both increasing, `-1` for both decreasing, zero for opposite signs is a descriptive demand-shift hypothesis. Require positive Q endpoints, exact session spacing, matched fee and quantity populations, and explicit ties. Report excluded zero endpoints. A movement within an aggregated vendor panel does not automatically identify an exogenous demand shift. Verdict: at most one separately registered comparison after baseline machinery passes; no threshold or horizon search.

Do not add a sixth interaction merely to fill a menu. Utilisation times Q/S reuses Q through two ratios and has no established incremental mean-return interpretation here. Neither algebraic novelty nor a plausible crowding story proves potency. The five candidates remain optional, disabled by default, and stock-specific.

### Required synthetic perturbations and invariants

**Local +/-10% audit:** perturb utilisation, quantity, supply, fee and count inputs separately at a named decision. Track raw feature, normalised score, availability, eligibility and selected-stock changes. For integer counts use feasible neighbouring integers as well as reporting the intended percentage; do not create fractional lenders. For bounded utilisation retain valid domains. Repeat thresholds themselves at 90% and 110% of their declared settings, with integer windows rounded by a declared rule. Test immediately below/at/above minimum history, denominator floors, HTB cutoffs, percentile edges and peer-count fallbacks. The demand quadrant can flip on arbitrarily small changes near zero; report that discontinuity rather than calling it robust.

**Global +/-20% audit:** multiply all eligible stocks' positive levels by 0.8 or 1.2 where meaningful. A common positive rescaling should preserve ranks unless a stated floor, bound, log transform, eligibility rule or normaliser changes the result. Scaling Q and L together preserves U; scaling A and N together preserves A/N where integral. Scaling fee levels also scales fee SD before nonlinear transformations. Expose these expected identities and exceptions. Change units from basis points to decimal rates and verify canonical values agree. These are proposed tests, not measured results.

Also run a separately labelled global configuration stress: shorten or lengthen all temporal parameters by 20%, and move numerical thresholds by 20%, while retaining valid domains, ordered horizons, integer counts and the explicit weight-sum contract. Do not move calendar timestamps, alter field definitions or select the best stressed configuration. Report which switches change coverage or decisions and identify the responsible rule. A blanket multiplication of every number is not a coherent alternative model; these bounded stresses diagnose dependence on chosen defaults.

**Temporal tests:** append future observations and future revisions; earlier outputs must remain unchanged. Perturb the current observation: current-inclusive features may change, explicitly prior-only reference moments must not. Change an observation outside a finite rolling window: that window's statistic must not change. EMA dependence can extend beyond a nominal minimum-history length; do not pretend it is a finite window unless truncated. Distinguish overlapping historical features, which may be causal, from overlapping unobserved labels, which require purging and correct availability.

## Final disposition

| Final score — as submitted | Soundness / 10 |
|---|---:|
| 1. Logical consistency | 4 |
| 2. Bias control | 3 |
| 3. Robustness to parameter fragility | 3 |
| 4. Resistance to overengineering | 2 |
| 5. Regime robustness | 4 |
| 6. Costs and implementation | 3 |
| 7. Falsifiability | 4 |
| 8. Ratio integrity — later claims | 3 |
| 9. Feature construction audit | 2 |
| 10. Covariance audit — later claims | 2 |
| 11. Universe audit — later claims | 3 |
| 13. Crowding as spectral concentration — later claims | 3 |
| 14. Non-stationarity interpretation — later claims | 4 |

No score is upgraded for proposed fixes. Rows8,10,11,13and14 score the later supplied claims, with justification in their supplements below; they were not present in the original bundle. No dimension12 was specified.

The top three risks, ranked qualitatively by blast radius times plausibility, are: **(1)** false crowding created by unavailable/revised/missing data or changing ranking peers; **(2)** apparently successful selection produced by many changing features, samples and testing blocks; **(3)** short-leg returns that disappear or reverse after realistic borrow, turnover and forced-cover cashflows. These rankings describe design exposure, not observed failure frequencies. Overlapping stock indices can also create a high absorption ratio without a new crowded trade.

The minimum viable framework is an explicitly mapped, timestamped stock panel; the frozen baseline; one fixed EMA-slope overlay with fixed theme weights and neutral missing contributions; one common feasibility set; one registered chronological comparison; and an un-clipped signed cashflow evaluator. Keep the 16-feature library as inspectable diagnostics. Keep the five optional candidates off until their field contracts are met. Retain diagnostic failure and inconclusive outcomes without automatically trying the next model.

For the later price-free index component, the minimum is initial-release aggregateQ/S, same-day ranks across supplied stock indices, the required lagged60-change Spearman matrix, declared constant-correlation shrinkage, SVD absorption share and15/252delta-AR with cohort diagnostics. The symbolic formula catalogue is an exported research ledger, not another stage in that default score. This retains the proposed positioning/concentration mechanism; no predictive edge has yet been established.

**Three criteria that can kill the entire deployable framework:**

1. Mandatory baseline inputs cannot be reconstructed as known at decision time or cannot be replaced by verified fields. This kills historical validation and deployment claims for both baseline and overlay; a prospective archive can support a new study later.
2. A predeclared economically relevant baseline effect fails on unused, adequately informative evidence under correct costs and execution, with no independently justified deployable leg. A failed overlay alone does not meet this criterion; revert to a baseline only if it independently passes.
3. The intended stock exposures cannot be implemented within independently set liquidity, borrow, funding and loss constraints under the declared stress scenarios. Failure restricted to an optional feature disables that feature; failure of one short expression does not invalidate an independently tested long-only baseline, but it does kill claims for the original required long-short deployment.

An inconclusive estimate is not evidence of no effect. Conversely, preserving an unfalsified economic story is not evidence of a usable strategy. The notebook's synthetic tests can validate engineering contracts only; actual investment evidence remains absent.

## Supplemental audit — pasted ratio, covariance and universe advice

This supplement audits the later pasted conversation as claims, not as authority to change execution mode or copy another agent's implementation. It does not reopen the four-pass review. Dimensions 8, 10 and 11 below were added by the later request; absorption ratio was not defined in the original framework. All proposed measurements concern individual-stock crowding.

| New dimension | Provisional soundness of pasted claims / 10 | Required correction |
|---|---:|---|
| 8. Ratio integrity | 3 | Validate numerator/denominator populations, units, domain and availability; retain undefined ratios. |
| 10. Covariance audit | 2 | Preserve a valid correlation/covariance matrix, distinguish rank axes, specify shrinkage target and use the correct spectrum. |
| 11. Universe audit | 3 | Freeze point-in-time eligibility, show coverage and constituent changes, distinguish liquidity proxies from executable capacity. |

**Ratios.** Log ratios are neither generally bounded nor automatically stationary. For positive A/B, `log(A/B)` is unbounded in both directions; even a bounded fraction can approach zero and have an unbounded negative logarithm. Transformations do not remove changing vendor definitions or stochastic trends. Flooring a denominator changes the economic quantity and can turn undefined or barely observed capacity into an artificial signal. Require domain checks, raw denominator diagnostics and an explicitly justified alternative definition if necessary. A VIF cutoff of 5 is a heuristic, not a universal redundancy or model-validity boundary; VIF also cannot detect availability leakage.

**Covariance and absorption ratio.** For a positive-semidefinite N-stock correlation matrix R, define `AR_k = sum(top k eigenvalues)/trace(R)`. An identity matrix gives `k/N`, not zero; a rank-one matrix gives one for any k>=1. Singular values of R equal its nonnegative eigenvalues, so do not square those singular values. Squaring applies instead when deriving covariance eigenvalues from the singular values of the centered observation matrix. Zeroing R's diagonal makes its trace zero and, unless the result is the zero matrix, necessarily creates an indefinite matrix. It destroys this variance-fraction interpretation.

On a dates-by-stocks panel, `rank(axis=0)` ranks each stock through time, whereas `rank(axis=1)` ranks stocks within each date. The former can construct rolling Spearman correlations; it is not daily cross-sectional ranking. Specify which operation defines the input and which defines the dependence measure. [pandas rank documentation](https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.rank.html) Rank correlation is resistant to marginal scale changes but does not guarantee robust measurement of joint tail losses or distinguish positive from negative common-factor exposure in an absorption spectrum.

Scikit-learn's LedoitWolf shrinks toward a scaled identity, not a constant-correlation target. Name the actual estimator and target; standardise ranked inputs consistently and convert estimated covariance to correlation if that is the declared AR object. [LedoitWolf documentation](https://scikit-learn.org/stable/modules/generated/sklearn.covariance.LedoitWolf.html) Use a common observation set, handle constant columns explicitly, and check symmetry, diagonal and eigenvalue tolerance. Pairwise deletion need not produce a positive-semidefinite matrix. Sixty changes require 61 score observations; if the changes must all precede decision t, end that score history at t-1. A sample centered on only 60 changes has rank at most 59 before shrinkage, so finite-window dimensionality itself affects concentration.

**Universe and interpretation.** ADV percentiles describe relative liquidity, not order size, participation, borrow availability or actual capacity. Define whether the worst 5% of stocks is selected at the current decision or at each historical observation; changing membership changes the estimand. Keep historical eligibility and delisted stocks appropriately represented. Report N, k, missingness and turnover beside AR, and compare like definitions: N and shrinkage changes can move AR without changing economic crowding. There is no basis without data to assert that the worst 5% has AR near one or that high AR forecasts a squeeze. Use identity, rank-one, constant-column, missing-column and future-perturbation fixtures before interpreting any stock-market output.

## Supplemental dimension 13 — crowding as spectral concentration

**Provisional soundness of the proposed interpretation: 3/10.** This later addition distinguishes C, absorption ratio of changes in stock-crowding scores; A, return absorption ratio within the most crowded 20% of stocks; and B, concentration of supplied stock-position capital across funds. These are different statistical objects. Calling C leading, A confirming and B structural does not establish a common mechanism, timing order or forecast. No extra feature or dataset is required to pass this review.

**C is not proven to lead A.** The absorption-ratio literature studies concentration of return variation, not a demonstrated lead from this vendor's stock-lending score changes. Its empirical conclusions cannot be transferred by renaming the input matrix. [Kritzman, Li, Page and Rigobon, original article](https://globalmarkets.statestreet.com/research/service/public/v1/article/insights/pdf/v2/275a6997-b913-47da-b487-948d83f7765e/jpm_principal_components_as_a_measure_of_systemic_risk.pdf) Correlation means dependence, not convergence of positions: two series can move in parallel while their distance grows. Moreover, reversing the signs of selected series produces a correlation matrix with the same eigenvalues. Thus high C can reflect coordinated opposite movements, shared measurement changes or common normalisation, rather than everyone building the same stock exposure. Any lead-lag claim needs a separately specified prospective test, not a lag chosen after viewing spikes.

**A does not uniquely confirm crowding.** Return dependence within selected stocks can reflect common market or sector exposure. Correlation AR and covariance AR also differ: the latter weights volatility, so their levels are not interchangeable. Finite-window spectral concentration can be noisy, particularly with many stocks relative to observations. [Laloux, Cizeau, Potters and Bouchaud, author paper](https://www.cfm.com/wp-content/uploads/2022/12/234-1999-random-matrix-theory-and-financial-correlations.pdf) For a decision at t, select the top-20% stock cohort using only scores actually available by t-1 and use a trailing return window ending no later than t-1 under the declared return-availability convention. Freeze that selected cohort within that calculation. Membership, sector composition, N, k and excluded constant/missing stocks must accompany the output; their changes can move A. Do not present an endpoint-selected historical cohort as if it had been selected throughout its lookback.

**B measures concentration, not independence.** For comparable nonnegative stock-position capital `a_f`, let `p_f = a_f/sum(a_f)`, `HHI = sum(p_f^2)` and `PR = 1/HHI`. Zero total capital gives an undefined result. Use explicit gross nonnegative exposure if that is the desired object; never divide signed positions by net capital, which can be zero or close to zero. Percent-of-NAV weights from different funds do not become actual cross-fund capital without a compatible size convention. HHI's sum-of-squares definition measures concentration. [US Department of Justice, HHI definition](https://www.justice.gov/atr/herfindahl-hirschman-index) Its reciprocal is an effective count under that weighting convention, not a number of statistically independent funds or trading decisions. Identical allocations can coexist with either identical or unrelated fund strategies. With a fixed definition, PR falls when HHI rises; a claim that both spike together is algebraically inconsistent.

**Keep the implementation bounded.** Retain C as the main requested diagnostic. Enable A only if suitably defined individual-stock returns are already supplied; do not fetch or require returns merely to complete this extension. Enable B only if compatible nonnegative position weights are supplied. Do not infer fund positions from lender counts, add 13F or flow feeds, or require three-series agreement. Leave absent components explicitly unavailable. Synthetic identity/rank-one examples, position-weight rescaling, equal-versus-single-fund concentration and future-data invariance can validate the calculations; they cannot establish common spikes, causal crowding, leading behaviour or investment usefulness.

## Supplemental dimension 14 — spectral estimation and state stability

**Provisional soundness of the pasted interpretation: 4/10.** A raw-versus-cleaned spectrum comparison can diagnose estimator dependence; it does not establish that omitting Marchenko–Pastur (MP) filtering deflates AR during stress. Neither nonstationarity nor noise has a universal directional effect on this ratio. MP reference laws depend on a sampling model and aspect ratio; rank ties, temporal dependence, overlapping equity indices and changing constituents depart from the simplest assumptions. Spectral cleaning is an alternative estimator with choices, not an automatic restoration of truth. [Laloux and coauthors](https://www.cfm.com/wp-content/uploads/2022/12/234-1999-random-matrix-theory-and-financial-correlations.pdf) Constant-correlation shrinkage also has a specific target and intensity; keep it identifiable rather than describing all regularisation as MP correction. [Ledoit–Wolf reference implementation](https://github.com/oledoit/covShrinkage/blob/main/covCor.m)

Preserve the requested 60-change AR window and full 252-observation delta-AR baseline. A long normalisation window adapts slowly, but “more than 120 days creates six-month bias” is not a general theorem. The effect depends on the break, feature and weighting rule. A trailing standardised change exceeding two is not automatically a calibrated probability or trading alarm. Requiring two windows to confirm it adds another design choice, dependence and potential search; neither two-window confirmation nor MP filtering is required for a sound implementation.

Changing cohorts can move the spectrum without a common economic shock. Report cohort changes, N, missing/constant exclusions and shrinkage status; do not automatically reject 252 days after every constituent change. Fixed-window cliffs and exponentially weighted persistence trade off responsiveness against noise. An EWM alternative needs its own effective-history and missingness contract and should remain a labelled sensitivity. None of these diagnostics proves leading information or licenses choosing whichever window gives the preferred narrative.
