"""Synthetic ASX-sized stock-feature benchmark; never an investment backtest.

Prepare with --prepare-only before coordinating execution with other workers.
Both implementations receive 330 historical sessions and a universe containing
only the last ten requested decision dates. They therefore evaluate ten feature
snapshots, not a full 330-decision backfill. Timing excludes fixture generation,
imports, parity checks and exports. Memory is a separate one-decision call.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import runpy
import threading
import time
import tracemalloc

# Set these before importing libraries; threadpoolctl below also applies limits
# to the numerical/OpenMP libraries already loaded before measured operations.
for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
              "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_name] = "1"

import numpy as np
import pandas as pd
import scipy.linalg
import sklearn.ensemble
from threadpoolctl import threadpool_info, threadpool_limits

WORK = Path(__file__).resolve().parent


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")


def fixture_for(api, securities, sessions_count=330, decisions=10, seed=741):
    if sessions_count < 300 or not 6 <= decisions < sessions_count - 275:
        raise ValueError("Need >=300 historical sessions, >=6 evaluation decisions, and revisions after event275.")
    fixture = api["synthetic_inputs"](sessions_count=sessions_count,
                                      securities_count=securities, seed=seed)
    lending = fixture["lending"].copy()
    calendar = fixture["sessions"].copy()
    universe = fixture["universe"].copy()
    dates = pd.DatetimeIndex(calendar.session)
    ids = sorted(lending.security_id.unique())
    rng = np.random.default_rng(seed + 1)
    # The standard demo's utilisation starts at15+stock_number, which would cap
    # many of200/300 stocks at95. Use varied synthetic paths at either size.
    for security in ids:
        mask = lending.security_id.eq(security)
        count = int(mask.sum())
        utilisation = np.clip(rng.uniform(8, 55) + np.cumsum(rng.normal(0, .5, count)), 1, 90)
        lending.loc[mask, "utilisation"] = utilisation
        lending.loc[mask, "on_loan"] = lending.loc[mask, "lendable"].to_numpy() * utilisation / 100
        lending.loc[mask, "annual_fee"] = .002 + .06 * (utilisation / 100) ** 3
        lending.loc[mask, "broker_count"] = np.clip(
            rng.integers(3, 12) + np.cumsum(rng.choice([-1, 0, 1], count, p=[.1, .8, .1])), 0, 20)
    calendar["expected_event_date"] = calendar["session"]
    universe["index_asx200"] = universe.security_id.isin(ids[:min(200, securities)])
    universe["index_asx300"] = True
    evaluation_dates = dates[-decisions:]
    outage = evaluation_dates[2]
    full_outage = lending.event_date.eq(outage)
    individual_missing = (
        (lending.event_date.eq(dates[100]) & lending.security_id.isin(ids[::13])) |
        (lending.event_date.eq(evaluation_dates[4]) & lending.security_id.isin(ids[::17])) |
        (lending.event_date.eq(evaluation_dates[-1]) & lending.security_id.isin(ids[::19]))
    )
    omissions = {"whole_session_rows_removed": int(full_outage.sum()),
                 "individual_rows_removed": int(individual_missing.sum())}
    lending = lending.loc[~(full_outage | individual_missing)].copy()
    revision_frames = []
    revision_specs = [
        (dates[70], evaluation_dates[1], 1.08),
        (dates[180], evaluation_dates[5], .93),
        (dates[275], evaluation_dates[-2], 1.05),
    ]
    for event_date, release_date, multiplier in revision_specs:
        revised = lending.loc[lending.event_date.eq(event_date) &
                              lending.security_id.isin(ids[::11])].copy()
        release = calendar.loc[calendar.session.eq(release_date), "close_at"].iloc[0]
        revised["available_at"] = release + pd.Timedelta(minutes=30)
        revised["utilisation"] = (revised.utilisation * multiplier).clip(0, 100)
        revised["on_loan"] = revised.lendable * revised.utilisation / 100
        revision_frames.append(revised)
    unavailable = lending.loc[lending.event_date.eq(dates[90]) &
                               lending.security_id.isin(ids[::23])].copy()
    unavailable["available_at"] = calendar.decision_at.iloc[-1] + pd.Timedelta(days=5)
    unavailable["utilisation"] = 99.
    unavailable["on_loan"] = unavailable.lendable * .99
    revision_frames.append(unavailable)
    revisions = pd.concat(revision_frames, ignore_index=True)
    lending = pd.concat([lending, revisions], ignore_index=True)
    # Shuffle source rows so file order cannot become a vintage-selection rule.
    lending = lending.sample(frac=1, random_state=seed).reset_index(drop=True)
    evaluation_universe = universe.loc[universe.session.isin(evaluation_dates)].copy()
    final_universe = universe.loc[universe.session.eq(evaluation_dates[-1])].copy()
    metadata = {
        "synthetic_only": True, "nominal_universe": f"ASX{securities}-sized synthetic",
        "seed": seed, "history_sessions": sessions_count,
        "evaluation_decisions": decisions, "evaluation_dates": evaluation_dates.tolist(),
        "expected_event_date_contract": "same-session synthetic release, explicitly declared",
        "securities": securities, "input_lending_rows_including_revisions": len(lending),
        "unique_security_event_pairs": int(lending[["security_id", "event_date"]].drop_duplicates().shape[0]),
        "evaluation_universe_rows": len(evaluation_universe),
        "late_revision_rows": len(revisions) - len(unavailable),
        "future_unavailable_revision_rows": len(unavailable),
        "whole_session_outage_date": outage, **omissions,
        "calendar_note": "synthetic weekdays; not a verified ASX holiday calendar",
        "full_330_decision_backfill_measured": False,
    }
    return lending, calendar, evaluation_universe, final_universe, metadata


def canonical(frame):
    return frame.sort_values(["session", "security_id"]).reset_index(drop=True).sort_index(axis=1)


def parity(reference, candidate):
    left, right = canonical(reference), canonical(candidate)
    pd.testing.assert_frame_equal(left, right, check_exact=False, rtol=1e-10,
                                  atol=1e-12, check_dtype=True, check_like=False)
    maximum_difference = 0.
    for column in left.select_dtypes(include=["number"]).columns:
        a = left[column].to_numpy(dtype=float)
        b = right[column].to_numpy(dtype=float)
        valid = np.isfinite(a) & np.isfinite(b)
        if valid.any():
            maximum_difference = max(maximum_difference, float(np.max(np.abs(a[valid] - b[valid]))))
    return {"passed": True, "rows": len(left), "columns": len(left.columns),
            "decision_dates": int(left.session.nunique()),
            "rtol": 1e-10, "atol": 1e-12,
            "maximum_absolute_numeric_difference": maximum_difference,
            "baseline_nonmissing": int(left.baseline.notna().sum()),
            "overlay_nonmissing": int(left.overlay.notna().sum()),
            "latest_row_missing": int(left.latest_row_missing.sum())}


def timed(operation, repetitions, progress):
    durations = []
    output = None
    for repetition in range(repetitions):
        gc.collect()
        progress(f"wall call {repetition + 1}/{repetitions}")
        start = time.perf_counter()
        output = operation()
        durations.append(time.perf_counter() - start)
    return output, {"wall_seconds": durations,
                    "wall_median_seconds": float(np.median(durations)),
                    "wall_repetitions": repetitions,
                    "wall_label": "single uninstrumented run" if repetitions == 1 else "median of uninstrumented runs"}


def memory_sample(operation):
    gc.collect()
    tracemalloc.start()
    start = time.perf_counter()
    try:
        output = operation()
        _, peak = tracemalloc.get_traced_memory()
        elapsed = time.perf_counter() - start
    finally:
        tracemalloc.stop()
    return output, {"additional_traced_peak_MiB": peak / 2 ** 20,
                    "instrumented_memory_call_seconds_not_wall_benchmark": elapsed,
                    "evaluated_decisions": 1,
                    "scope": "one final decision using330session history; prebuilt inputs excluded; not process RSS or whole ten-decision peak"}


def full_asx200_profile(output_path):
    """One public full backfill; process RSS sampling, never tracemalloc."""
    import psutil
    source = WORK / "notebook_source.py"
    start_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    api = runpy.run_path(str(source))
    cfg = api["Config"]()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    print("Preparing full330-decision x200-stock synthetic fixture", flush=True)
    lending, calendar, _, _, metadata = fixture_for(api, 200)
    # Restore the full330-date membership table; do not expand the ten-date
    # evaluation table backward or infer past membership from the final date.
    universe = api["synthetic_inputs"](sessions_count=330, securities_count=200,
                                        seed=741)["universe"]
    metadata["evaluation_decisions"] = len(calendar)
    metadata["evaluation_dates"] = calendar.session.tolist()
    metadata["evaluation_universe_rows"] = len(universe)
    metadata["full_330_decision_backfill_measured"] = True
    process = psutil.Process()
    stop = threading.Event()
    readings = []
    sample_errors = []
    rss_before = process.memory_info().rss
    windows_peak_before = getattr(process.memory_info(), "peak_wset", None)
    result = {
        "status": "running", "scope": "one synthetic full330-decision x200-stock public-runtime backfill",
        "implementation": "notebook_source.build_feature_panel", "fixture": metadata,
        "source_sha256_start": start_hash, "config_defaults": asdict(cfg),
        "python": platform.python_version(), "platform": platform.platform(),
        "versions": {name: importlib.metadata.version(name) for name in
                     ["numpy", "pandas", "scipy", "scikit-learn", "threadpoolctl", "psutil"]},
        "timing_repetitions": 1, "tracemalloc_used": False,
        "timing_excludes": ["imports", "fixture generation", "output serialization"],
        "memory_method": "process RSS sampled every20ms during operation, includes prebuilt inputs; Windows lifetime peak_wset also captured when available",
        "memory_note": "RSS sampler overhead included in wall/CPU; sampled operation peak can miss briefer peaks; lifetime peak includes fixture/import setup",
        "rss_before_operation_MiB": rss_before / 2 ** 20,
        "windows_lifetime_peak_before_MiB": None if windows_peak_before is None else windows_peak_before / 2 ** 20,
        "open_unmeasured": ["full330-decision ASX300 backfill", "full7000-stock vintage backfill", "HPC scaling", "database query/transfer plans"],
    }

    def monitor():
        since = time.perf_counter()
        last_report = since
        while not stop.wait(.02):
            try:
                readings.append(process.memory_info().rss)
            except psutil.Error as error:
                sample_errors.append(str(error))
            now = time.perf_counter()
            if now - last_report >= 30:
                print(f"FULL_PROFILE_PROGRESS elapsed={now-since:.1f}s sampled_peak_RSS={max([rss_before]+readings)/2**20:.2f}MiB", flush=True)
                last_report = now

    with threadpool_limits(limits=1):
        result["threadpools"] = threadpool_info()
        if any(pool.get("num_threads", 1) != 1 for pool in result["threadpools"]):
            raise RuntimeError("One-thread BLAS/OpenMP contract not satisfied")
        write_json(output_path, result)
        worker = threading.Thread(target=monitor, name="asx-profile-rss", daemon=True)
        worker.start()
        print("FULL_PROFILE_START public build_feature_panel;330decisions;200stocks", flush=True)
        wall_start = time.perf_counter()
        cpu_start = time.process_time()
        try:
            panel = api["build_feature_panel"](lending, calendar, universe, cfg)
            cpu_seconds = time.process_time() - cpu_start
            wall_seconds = time.perf_counter() - wall_start
        finally:
            stop.set()
            worker.join(timeout=5)
        readings.append(process.memory_info().rss)
        end_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        windows_peak_end = getattr(process.memory_info(), "peak_wset", None)
        result.update({
            "status": "completed", "source_sha256_end": end_hash,
            "source_unchanged_during_run": start_hash == end_hash,
            "wall_seconds": wall_seconds, "cpu_seconds": cpu_seconds,
            "output_rows": len(panel), "output_columns": len(panel.columns),
            "output_decisions": int(panel.session.nunique()),
            "output_securities": int(panel.security_id.nunique()),
            "output_column_names": panel.columns.tolist(),
            "baseline_nonmissing_rows": int(panel.baseline.notna().sum()),
            "overlay_nonmissing_rows": int(panel.overlay.notna().sum()),
            "latest_row_missing_rows": int(panel.latest_row_missing.sum()),
            "duplicate_security_session_rows": int(panel.duplicated(["session", "security_id"]).sum()),
            "sampled_peak_operation_RSS_MiB": max([rss_before] + readings) / 2 ** 20,
            "rss_after_operation_MiB": readings[-1] / 2 ** 20,
            "rss_samples": len(readings), "rss_sampling_errors": sample_errors,
            "windows_process_lifetime_peak_RSS_MiB": None if windows_peak_end is None else windows_peak_end / 2 ** 20,
        })
        write_json(output_path, result)
        if start_hash != end_hash:
            raise AssertionError("Runtime source changed during full profile")
        if len(panel) != 330 * 200 or panel.session.nunique() != 330:
            raise AssertionError("Unexpected full-backfill output dimensions")
        if panel.duplicated(["session", "security_id"]).any():
            raise AssertionError("Duplicate security/session output rows")
        print(f"FULL_PROFILE_COMPLETE wall={wall_seconds:.6f}s cpu={cpu_seconds:.6f}s rows={len(panel)} columns={len(panel.columns)} peak_operation_RSS={result['sampled_peak_operation_RSS_MiB']:.2f}MiB", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", nargs="+", type=int, default=[200, 300])
    parser.add_argument("--sessions", type=int, default=330)
    parser.add_argument("--decisions", type=int, default=10)
    parser.add_argument("--repetitions", type=int, default=1)
    parser.add_argument("--output", type=Path, default=WORK / "asx_scale_benchmark")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--full-asx200", action="store_true",
                        help="Run one full330-decision x200-stock public-runtime RSS/CPU profile instead of ten-decision comparison")
    args = parser.parse_args()
    if args.full_asx200:
        full_asx200_profile(WORK / "performance" / "full_asx200_benchmark.json")
        return
    if args.repetitions < 1 or any(size <= 0 for size in args.sizes):
        parser.error("Sizes and repetitions must be positive.")
    args.output.mkdir(parents=True, exist_ok=True)
    progress_path = args.output / "progress.log"

    def progress(message):
        line = time.strftime("%Y-%m-%d %H:%M:%S") + " " + message
        print(line, flush=True)
        with progress_path.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")

    source = WORK / "notebook_source.py"
    api = runpy.run_path(str(source))
    cfg = api["Config"]()
    result = {"scope": "synthetic ASX-sized feature decisions; no investment validation",
              "python": platform.python_version(), "platform": platform.platform(),
              "config_defaults": asdict(cfg),
              "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
              "implementations": {"baseline": "notebook_source._build_feature_panel_reference",
                                  "candidate": "notebook_source.build_feature_panel"},
              "timing_excludes": ["imports", "fixture generation", "parity checks", "export writes", "tracemalloc"],
              "cache_note": "fresh numerical outputs per call; OS/allocator caches uncontrolled; candidate immutable geometry cache may warm",
              "open_unmeasured": ["full330-decision ASX200/300 backfill", "full7000-stock vintage backfill", "HPC scaling", "database query/transfer plans"],
              "versions": {name: importlib.metadata.version(name) for name in ["numpy", "pandas", "scipy", "scikit-learn", "threadpoolctl"]},
              "workloads": []}
    baseline_function = api["_build_feature_panel_reference"]
    candidate_function = api["build_feature_panel"]
    with threadpool_limits(limits=1):
        result["threadpools"] = threadpool_info()
        uncontrolled = [pool for pool in result["threadpools"] if pool.get("num_threads", 1) != 1]
        if uncontrolled:
            raise RuntimeError(f"Thread limit not effective: {uncontrolled}")
        for size in args.sizes:
            progress(f"preparing{args.sessions}historysessions x{size}stocks;{args.decisions}evaluated decisions")
            lending, calendar, universe, final_universe, metadata = fixture_for(
                api, size, args.sessions, args.decisions)
            entry = {"fixture": metadata}
            result["workloads"].append(entry)
            if args.prepare_only:
                continue
            baseline_call = lambda: baseline_function(lending, calendar, universe, cfg)
            candidate_call = lambda: candidate_function(lending, calendar, universe, cfg)
            progress(f"ASX{size} baseline uninstrumented timing")
            baseline, baseline_timing = timed(baseline_call, args.repetitions, progress)
            progress(f"ASX{size} candidate uninstrumented timing")
            optimized, candidate_timing = timed(candidate_call, args.repetitions, progress)
            entry["baseline"] = baseline_timing
            entry["candidate"] = candidate_timing
            progress(f"ASX{size} numerical/output parity")
            try:
                entry["parity"] = parity(baseline, optimized)
            except AssertionError as error:
                entry["parity"] = {"passed": False, "error": str(error)}
                result["status"] = "failed_numerical_parity"
                write_json(args.output / "benchmark.json", result)
                raise
            if entry["parity"]["decision_dates"] != args.decisions:
                raise AssertionError("Actual evaluated decision count differs from declared workload.")
            if entry["parity"]["rows"] != size * args.decisions:
                raise AssertionError("Actual feature rows differ from the full synthetic decision cohort.")
            entry["observed_speedup_this_fixture_only"] = (
                baseline_timing["wall_median_seconds"] / candidate_timing["wall_median_seconds"])
            progress(f"ASX{size} separate baseline final-decision memory call")
            baseline_one, entry["baseline_memory_one_decision"] = memory_sample(
                lambda: baseline_function(lending, calendar, final_universe, cfg))
            progress(f"ASX{size} separate candidate final-decision memory call")
            candidate_one, entry["candidate_memory_one_decision"] = memory_sample(
                lambda: candidate_function(lending, calendar, final_universe, cfg))
            entry["memory_call_output_parity"] = parity(baseline_one, candidate_one)
            memory_actual = canonical(baseline_one)
            memory_expected = canonical(baseline.loc[
                baseline.session.eq(calendar.session.iloc[-1])])
            # The outage-only snapshot contributes an all-NaT object column to
            # the multi-date concat. Compare timestamp values after canonical
            # UTC typing only for this cross-workload check. Baseline/candidate
            # parity above remains strict on every original output dtype.
            for frame in (memory_actual, memory_expected):
                frame["source_available_at"] = pd.to_datetime(
                    frame.source_available_at, utc=True, errors="raise")
            pd.testing.assert_frame_equal(memory_actual, memory_expected,
                check_exact=False, rtol=1e-10, atol=1e-12)
            entry["cross_workload_comparison_timestamp_normalization"] = "source_available_at to UTC; other dtypes strict"
            entry["final_decision_memory_output_matches_timed_run"] = True
            del baseline, optimized, baseline_one, candidate_one
            write_json(args.output / "benchmark.json", result)
            progress(f"ASX{size} complete; parity passed")
    result["status"] = "prepared_only_no_benchmark_executed" if args.prepare_only else "completed_synthetic_benchmark"
    write_json(args.output / ("prepared_manifest.json" if args.prepare_only else "benchmark.json"), result)
    progress(result["status"])


if __name__ == "__main__":
    main()
