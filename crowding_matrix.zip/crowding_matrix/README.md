# Stock crowding notebook

Open [ASX_Crowding_Framework.ipynb](ASX_Crowding_Framework.ipynb) and run all cells. All runtime definitions, research and tests are inside the notebook. The `work/` sources are packaging and review material, not runtime dependencies.

![Synthetic matrix workflow preview](review/notebook_preview.png)

The code-quality repair fixes nullable/missing input handling, join IDs, configuration domains, finite borrow/position constraints and incomplete capacity rows. The stock path batches17normalizations and precomputes lender fractions per source vintage. Purpose-labeled, formatted code cells are bounded to99lines; the plot comes after its small matrix prerequisites, and configuration remains visible.

The main path is a daily **stock-index positioning matrix**, at most200indices: aggregate Q/shares outstanding, cross-sectional percentile ranks, 60lagged Spearman change correlations, constant-correlation shrinkage, SVD absorption ratio and full252-session delta-AR. It requires no stock-price input. More than200columns are rejected before quadratic allocation.

Use the **Input contract** cells to map localCSVorParquet exports. Index aggregates need dated initial releases and scoring sessions. The optional ASX stock-feature path also needs actual exchange sessions, verified expected source date, point-in-time universe and consistently adjusted stock-price inputs. No real vendor schema or investment result is assumed.

Install dependencies if needed with `python -m pip install -r requirements.txt`. No installation is performed by the notebook. A working Python Jupyter kernel is required.

The default run uses controlled synthetic fixtures. Exported Parquet files under `crowding_outputs/` are labelled synthetic. Tests validate machinery, never alpha, capacity, actual fees or a causal leading indicator. The stock path uses invocation-local input preparation and immutable EMA geometry; one shared feature implementation and a reference loop support parity tests. The direct index path is the fast workflow for the200-indexmatrix.

The notebook opens with the matrix plots and a compact symbolic shortlist. Full reviews, feature audits, top30 interpretations, numerical previews and implementation code are folded. The840-row formula ledger preserves rejection and duplicate reasons;372 are unique conditional symbolic candidates, not validated alphas. Mean pairwise normalized AST overlap in the30-formula slate is0.1734, a syntax proxy rather than empirical independence.

Every ledger row includes expected_fragility_mode, and the top30 reuses those descriptions. The broader original design is not fully implemented: an untouched purged holdout is absent, and forced-cover/optional-candidate/model portfolio comparisons are not integrated. The requested analytical +/-10%/20% review is fulfilled; comprehensive proposed sensitivity validation has not been run. The14names fulfill symbolic-generation scope without a numeric extractor request, and return-AR/position-HHI remain reviewed conditional constructions without runnable paths. See the folded coverage ledger for provenance and scope. Entity broker counts require finite nonnegative integers without rounding; average/weighted vendor quantities cannot silently use that mapping. Passing checks does not establish a flawless, globally optimal or universally statistically valid framework.

Supplied sector-label summaries pool stock-date observations. The GICS2/4/6/8research consult is fulfilled;4/6/8hierarchy views are not implemented. Paired fresh-process measurements compare the actual archived pre-repair public runtime with the current public runtime on identical valid fixtures: full 330×8 stock backfill 10.08→6.31 seconds; full 330×200 backfill 95.38→54.17 seconds, with exact parity on the 38 columns that the 2026-10-30 methodology fixes do not deliberately change (7 added and 32 changed columns are reported separately). The 200-stock process peak was 400.43→408.76 MiB, so faster does not imply less memory. Before those fixes the current runtime measured 47.26 seconds on the same full workload; the fixes cost roughly 15% (separate single runs). These measure the combined repair/optimization pass, not an isolated algorithm change. Prior reports remain historical with their source hashes. FullASX300/7000-stock backfills and database/HPC scaling remain **OPEN**. Expensive profiling is off by default.

Methodology fixes from the 2026-10-30 review: the overlay keeps its fixed 0.5 flow weight when stocks lack flows; overlay-minus-baseline inference uses non-overlapping holding periods from the first date with flow information; absent rows and blank definition labels follow one continue-and-count policy on every path; each decision ranks features only among stocks with all mandatory current levels and reports eligible, delivered and scored counts; overflowing Q/S, invalid supplied index metrics, undated index rows, invalid single lender-count legs, negative fees and invalid fee markups fail explicitly; AR reports zero-change shares and a persistent structure-change flag for delta-AR. Open items are listed in the implementation notes.

Build-time external verification:

Rebuilding additionally uses Ruff0.16.4 (`requirements-build.txt`). Ruff is never imported or invoked by the delivered notebook.

```
python work/build_notebook.py
python -m pytest --basetemp=work/pytest_tmp
python -u work/execute_notebook.py
```

On an environment with unrelated auto-loaded pytest plugins, set `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1` for this test process. This project does not use those plugins.

The execution runner treats warnings as errors, runs a fresh kernel and writes `work/verification.json` with the final saved notebook's SHA-256, cell-source digest, package versions and execution timestamps. Rebuilding or editing the notebook invalidates that digest; execute the saved revision again. Jupyter requires local kernel IPC permitted by the host environment.
