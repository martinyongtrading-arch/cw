"""Independent expectations and parity for the promoted runtime helpers."""

from pathlib import Path
import runpy

import numpy as np
import pandas as pd
import pytest


@pytest.fixture(scope="module")
def api():
    root = Path(__file__).resolve().parents[1]
    source = root / "work" / "notebook_source.py"
    assert source.exists(), "The promoted notebook runtime is required"
    return runpy.run_path(str(source))


def test_batch_normalizer_independent_ties_missing_and_constant_values(api):
    frame = pd.DataFrame(
        {
            "ties": [1.0, 1.0, 3.0, np.nan],
            "constant": [7.0, 7.0, np.nan, 7.0],
            "missing": [np.nan, np.inf, -np.inf, np.nan],
            "mixed": [0.0, np.inf, 2.0, "bad"],
        },
        index=[9, 4, 1, 7],
    )
    result = api["_cross_section_frame"](frame, (0.0, 1.0))
    expected = pd.DataFrame(
        {
            "ties": [
                -0.43072729929545756,
                -0.43072729929545756,
                0.967421566101701,
                np.nan,
            ],
            "constant": [0.0, 0.0, np.nan, 0.0],
            "missing": [np.nan] * 4,
            "mixed": [-0.6744897501960817, np.nan, 0.6744897501960817, np.nan],
        },
        index=frame.index,
    )
    pd.testing.assert_frame_equal(result, expected, rtol=0.0, atol=5e-15)


def test_batch_normalizer_independent_clipping_creates_expected_ties(api):
    frame = pd.DataFrame({"x": [0.0, 1.0, 2.0, 3.0, 100.0]})
    result = api["_cross_section_frame"](frame, (0.5, 0.9))
    expected = pd.DataFrame(
        {"x": [-0.5244005127080409] * 3 + [0.5244005127080407, 1.2815515655446004]}
    )
    pd.testing.assert_frame_equal(result, expected, rtol=0.0, atol=5e-15)


def test_batch_17_columns_match_reference_per_column_exactly(api):
    rng = np.random.default_rng(1729)
    frame = pd.DataFrame(
        rng.integers(-4, 5, size=(31, 17)).astype(float),
        columns=[f"c{i}" for i in range(17)],
    )
    frame.iloc[::3, ::2] = np.nan
    frame["c0"] = np.nan
    frame["c1"] = 5.0
    frame.loc[0, "c3"] = np.inf
    expected = pd.DataFrame(
        {name: api["cross_section"](frame[name], (0.01, 0.99)) for name in frame}
    )
    actual = api["_cross_section_frame"](frame, (0.01, 0.99))
    pd.testing.assert_frame_equal(actual, expected, check_exact=True)


def test_invalid_clipping_is_rejected_before_all_missing_batch_return(api):
    all_missing = pd.DataFrame({"x": [np.nan, np.nan]})
    with pytest.raises(ValueError, match="clip"):
        api["_cross_section_frame"](all_missing, (0.9, 0.1))
    with pytest.raises(ValueError, match="clip"):
        api["_cross_section_frame"](pd.DataFrame({"x": [1.0]}), (0.9, 0.1))


def test_gics_uses_each_columns_valid_count_and_its_own_market_median(api):
    levels = pd.DataFrame(
        {
            "scarcity": [0.0] * 10 + [100.0] * 10,
            "positioning": [1.0] * 9 + [np.nan] + [9.0] * 10,
            "participation": [np.nan] * 20,
        }
    )
    groups = pd.Series(["A"] * 10 + ["B"] * 10)
    result = api["_within_gics_levels"](levels, groups)
    assert result.scarcity.eq(0.0).all()
    assert result.positioning.iloc[:9].eq(-8.0).all()
    assert np.isnan(result.positioning.iloc[9])
    assert result.positioning.iloc[10:].eq(0.0).all()
    assert result.participation.isna().all()


def test_grouped_gics_matches_three_reference_paths(api):
    rng = np.random.default_rng(43)
    levels = pd.DataFrame(
        rng.normal(size=(43, 3)), columns=["scarcity", "positioning", "participation"]
    )
    levels.loc[::4, "positioning"] = np.nan
    levels.loc[::6, "scarcity"] = np.nan
    groups = pd.Series(
        pd.Categorical(
            ["A"] * 12 + ["B"] * 20 + ["C"] * 11, categories=["A", "B", "C", "unused"]
        )
    )
    expected = levels.copy()
    for column in levels:
        series = levels[column]
        counts = series.groupby(groups, observed=True).transform("count")
        medians = series.groupby(groups, observed=True).transform("median")
        medians = medians.where(
            counts >= 10, series.median() if series.notna().any() else np.nan
        )
        expected[column] = series - medians
    actual = api["_within_gics_levels"](levels, groups)
    pd.testing.assert_frame_equal(actual, expected, check_exact=True)


def test_precomputed_fraction_tracks_selected_vintage_without_touching_payload(api):
    rows = pd.DataFrame(
        {
            "security_id": ["A", "A", "A"],
            "event_date": ["2024-01-02"] * 3,
            "available_at": [
                "2024-01-03T00:00:00Z",
                "2024-02-01T00:00:00Z",
                "2024-03-01T00:00:00Z",
            ],
            "active_lenders": [2.0, 0.0, np.nan],
            "total_lenders": [4.0, 0.0, 10.0],
            "utilisation": [20.0] * 3,
            "on_loan": [20.0] * 3,
            "lendable": [100.0] * 3,
            "shares_outstanding": [1000.0] * 3,
            "broker_count": [2.0] * 3,
            "_prepared_lender_fraction": [-999.0] * 3,
        }
    )
    sessions = pd.DataFrame(
        {"session": ["2024-01-02"], "decision_at": ["2024-01-02T08:00:00Z"]}
    )
    universe = pd.DataFrame(
        {
            "session": ["2024-01-02"],
            "security_id": ["A"],
            "eligible": [True],
            "gics_sector": ["Materials"],
            "available_at": ["2024-01-02T00:00:00Z"],
        }
    )
    original = rows.copy(deep=True)
    original_sessions = sessions.copy(deep=True)
    original_universe = universe.copy(deep=True)
    prepared = api["_prepare_stock_context"](rows, sessions, universe)
    column = prepared["lender_fraction_column"]
    assert column not in rows
    assert prepared["lending"]["_prepared_lender_fraction"].eq(-999.0).all()
    pd.testing.assert_frame_equal(rows, original)
    pd.testing.assert_frame_equal(sessions, original_sessions)
    pd.testing.assert_frame_equal(universe, original_universe)
    for date, expected in [
        ("2024-01-04T00:00:00Z", 0.5),
        ("2024-02-02T00:00:00Z", np.nan),
        ("2024-03-02T00:00:00Z", np.nan),
    ]:
        selected = prepared["history_asof"](prepared["lending"], date)
        actual = selected[column].iloc[-1]
        assert np.isnan(actual) if np.isnan(expected) else actual == expected
        reference = api["history_asof"](rows, date)
        pd.testing.assert_frame_equal(
            selected.drop(columns=[column]), reference, check_exact=True
        )
    # Preparing fractions does not perform an eager timestamp conflict audit.
    conflicted = pd.concat(
        [rows, rows.iloc[[-1]].assign(active_lenders=3.0)], ignore_index=True
    )
    prepared_conflict = api["_prepare_stock_context"](conflicted, sessions, universe)
    assert (
        len(
            prepared_conflict["history_asof"](
                prepared_conflict["lending"], "2024-01-04T00:00:00Z"
            )
        )
        == 1
    )
    with pytest.raises(ValueError, match="Conflicting"):
        prepared_conflict["history_asof"](
            prepared_conflict["lending"], "2024-04-01T00:00:00Z"
        )
    pd.testing.assert_frame_equal(rows, original)
