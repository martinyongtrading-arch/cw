"""Independent expected-value input-contract regressions; no market data."""
from pathlib import Path
import runpy

import numpy as np
import pandas as pd
import pytest


@pytest.fixture(scope="module")
def api():
    return runpy.run_path(str(Path(__file__).parents[1] / "work" / "notebook_source.py"))


def quality_sessions():
    days = pd.date_range("2024-01-02", periods=3)
    local = [day.tz_localize("Australia/Sydney") for day in days]
    return pd.DataFrame({"session": days,
        "open_at": [day + pd.Timedelta(hours=10) for day in local],
        "close_at": [day + pd.Timedelta(hours=16) for day in local],
        "decision_at": [day + pd.Timedelta(hours=17) for day in local]})


def quality_positions(flags):
    day = pd.Timestamp("2024-01-02")
    stocks = pd.DataFrame({"session": [day, day], "security_id": ["A", "B"],
        "on_loan": [10., 20.], "shares_outstanding": [100., 100.],
        "adv_eligible": flags})
    members = pd.DataFrame({"session": [day, day], "security_id": ["A", "B"],
        "index_id": ["X", "X"]})
    return stocks, members


@pytest.mark.parametrize("kind,dtype", [("mixed", "object"), ("mixed", "boolean"), ("unknown", "object"), ("unknown", "boolean")])
def test_quality_unknown_adv_never_silently_excludes_constituents(api, kind, dtype):
    values = [True, pd.NA] if kind == "mixed" else [pd.NA, pd.NA]
    stocks, members = quality_positions(pd.Series(values, dtype=dtype))
    result = api["aggregate_stock_positioning"](stocks, members)
    assert "X" in result.columns and pd.Timestamp("2024-01-02") in result.index
    assert pd.isna(result.loc[pd.Timestamp("2024-01-02"), "X"])


@pytest.mark.parametrize("kind", ["mixed", "unknown"])
def test_quality_nullable_adv_survives_physical_parquet_missing(api, tmp_path, kind):
    values = [True, pd.NA] if kind == "mixed" else [pd.NA, pd.NA]
    stocks, members = quality_positions(pd.Series(values, dtype="boolean"))
    path = tmp_path / ("quality_adv_" + kind + ".parquet")
    stocks.to_parquet(path, index=False)
    loaded = api["load_table"](path, {column: column for column in stocks.columns})
    assert loaded.adv_eligible.isna().sum() == (1 if kind == "mixed" else 2)
    result = api["aggregate_stock_positioning"](loaded, members)
    assert "X" in result.columns and pd.Timestamp("2024-01-02") in result.index
    assert pd.isna(result.loc[pd.Timestamp("2024-01-02"), "X"])


@pytest.mark.parametrize("suffix,bad_kind", [("csv", "null"), ("csv", "blank"), ("csv", "space"), ("parquet", "null"), ("parquet", "blank"), ("parquet", "space")])
def test_quality_mapped_exports_reject_missing_or_blank_security_ids(api, tmp_path, suffix, bad_kind):
    bad = {"null": None, "blank": "", "space": "   "}[bad_kind]
    frame = pd.DataFrame({"Export ID": ["00123", bad], "Value": [1., 2.]})
    path = tmp_path / ("quality_bad_id_" + bad_kind + "." + suffix)
    if suffix == "csv":
        frame.to_csv(path, index=False)
    else:
        frame.to_parquet(path, index=False)
    with pytest.raises(api["InputError"], match="security_id|identifier"):
        api["load_table"](path, {"security_id": "Export ID", "value": "Value"})


@pytest.mark.parametrize("suffix", ["csv", "parquet"])
def test_quality_literal_ids_preserve_case_zeros_and_na_like_text(api, tmp_path, suffix):
    ids = ["00123", "nan", "<NA>", "NA", "MiXeD", " A "]
    frame = pd.DataFrame({"Export ID": ids, "Value": [1., np.nan, 3., 4., 5., 6.]})
    path = tmp_path / ("quality_literal_ids." + suffix)
    if suffix == "csv":
        frame.to_csv(path, index=False)
    else:
        frame.to_parquet(path, index=False)
    loaded = api["load_table"](path, {"security_id": "Export ID", "value": "Value"})
    assert loaded.security_id.tolist() == ids
    assert pd.isna(loaded.value.iloc[1])


@pytest.mark.parametrize("entry,bad_kind", [("history_asof", "null"), ("history_asof", "space"), ("universe_at", "null"), ("universe_at", "space"), ("aggregate_stock_positioning", "null"), ("aggregate_stock_positioning", "space"), ("make_labels", "null"), ("make_labels", "space"), ("features_at", "null"), ("features_at", "space")])
def test_quality_standalone_entries_reject_ids_before_stringification(api, entry, bad_kind):
    bad = pd.NA if bad_kind == "null" else "   "
    sessions = quality_sessions()
    day = sessions.session.iloc[0]
    available = sessions.open_at.iloc[0]
    decision = sessions.decision_at.iloc[0]
    with pytest.raises(api["InputError"], match="security_id|identifier"):
        if entry == "history_asof":
            frame = pd.DataFrame({"security_id": [bad], "event_date": [day], "available_at": [available]})
            api[entry](frame, decision)
        elif entry == "universe_at":
            frame = pd.DataFrame({"security_id": [bad], "session": [day], "available_at": [available]})
            api[entry](frame, day, decision)
        elif entry == "aggregate_stock_positioning":
            stocks, members = quality_positions(pd.Series([True, True]))
            stocks.loc[0, "security_id"] = bad
            members.loc[0, "security_id"] = bad
            api[entry](stocks, members)
        elif entry == "make_labels":
            prices = pd.DataFrame({"security_id": [bad] * 3, "session": sessions.session,
                "open": [100.] * 3, "close": [100., 100., 110.]})
            api[entry](prices, sessions, 2)
        else:
            lending = pd.DataFrame({"security_id": ["A"], "event_date": [day], "available_at": [available],
                "utilisation": [10.], "on_loan": [10.], "lendable": [100.],
                "shares_outstanding": [1000.], "broker_count": [2.]})
            members = pd.DataFrame({"security_id": [bad], "eligible": [True], "gics_sector": ["Materials"]})
            api[entry](lending, sessions, members, decision)


@pytest.mark.parametrize("missing_column", ["open", "close"])
def test_quality_nullable_float_prices_keep_missing_outcomes_unobserved(api, missing_column):
    sessions = quality_sessions()
    prices = pd.DataFrame({"security_id": ["A"] * 3 + ["B"] * 3,
        "session": sessions.session.tolist() * 2,
        "open": pd.Series([100.] * 6, dtype="Float64"),
        "close": pd.Series([100., 100., 110., 100., 100., 110.], dtype="Float64")})
    prices.loc[1 if missing_column == "open" else 2, missing_column] = pd.NA
    labels = api["make_labels"](prices, sessions, 2).set_index("security_id")
    assert not bool(labels.loc["A", "outcome_observed"])
    assert pd.isna(labels.loc["A", "forward_return"])
    assert pd.isna(labels.loc["A", "label_available_at"])
    assert bool(labels.loc["B", "outcome_observed"])
    assert labels.loc["B", "forward_return"] == pytest.approx(.1)


def test_quality_nullable_selected_exit_is_missing_without_replacement(api):
    frame = pd.DataFrame({"session": [pd.Timestamp("2024-01-02")] * 3,
        "security_id": ["A", "B", "C"], "baseline": [3., 2., 1.], "overlay": [3., 2., 1.],
        "borrowable": [True] * 3, "borrow_available": [100.] * 3,
        "entry_price": pd.Series([100.] * 3, dtype="Float64"),
        "exit_price": pd.Series([pd.NA, 90., 110.], dtype="Float64"),
        "entry_at": pd.to_datetime(["2024-01-03T00:00:00Z"] * 3),
        "exit_at": pd.to_datetime(["2024-01-04T00:00:00Z"] * 3),
        "annual_fee": [0.] * 3, "round_trip_cost_bps": [0.] * 3,
        "outcome_observed": [False, True, True]})
    legs = api["evaluate_legs"](frame, api["Config"](leg_fraction=.34))
    shorts = legs.loc[legs.side == "short"]
    assert shorts.selected_ids.tolist() == ["A", "A"]
    assert shorts.eligible_count.tolist() == [3, 3]
    assert shorts.unpriced_selected.tolist() == [1, 1]
    assert shorts.gross_return.isna().all() and shorts.net_return.isna().all()
    assert legs.loc[legs.side == "long", "net_return"].tolist() == pytest.approx([.1, .1])


@pytest.mark.parametrize("field,kind", [("window", "zero"), ("window", "negative"), ("window", "fraction"), ("window", "nan"), ("window", "infinity"), ("window", "boolean"), ("min_observations", "zero"), ("ema_min_observations", "negative"), ("change_window", "fraction"), ("horizon", "zero"), ("minimum_train_sessions", "nan"), ("refit_sessions", "infinity"), ("leg_fraction", "zero"), ("leg_fraction", "negative"), ("leg_fraction", "above_one"), ("leg_fraction", "nan"), ("kappa", "nan"), ("kappa", "infinity")])
def test_quality_config_invalid_scalars_fail_before_empty_feature_exit(api, field, kind):
    values = {"zero": 0, "negative": -1, "fraction": 1.5, "nan": float("nan"),
        "infinity": float("inf"), "boolean": True, "above_one": 1.01}
    with pytest.raises(api["InputError"], match=field):
        config = api["Config"](**{field: values[kind]})
        api["build_scores"](pd.DataFrame(), config)


@pytest.mark.parametrize("kind", ["min_above_window", "half_zero", "half_nonfinite", "half_descending", "clip_reversed", "clip_nonfinite", "sign_count", "sign_invalid"])
def test_quality_config_structural_domains_fail_before_empty_feature_exit(api, kind):
    changes = {
        "min_above_window": {"window": 10, "min_observations": 11},
        "half_zero": {"half_lives": (0, 2, 4)},
        "half_nonfinite": {"half_lives": (1, 2, float("inf"))},
        "half_descending": {"half_lives": (1, 4, 2)},
        "clip_reversed": {"clip_quantiles": (.9, .1)},
        "clip_nonfinite": {"clip_quantiles": (0, float("nan"))},
        "sign_count": {"theme_signs": (1., -1.)},
        "sign_invalid": {"theme_signs": (1., 0., -1.)},
    }
    with pytest.raises(api["InputError"]):
        config = api["Config"](**changes[kind])
        api["build_scores"](pd.DataFrame(), config)


def test_quality_config_preserves_existing_signed_and_fractional_domains(api):
    config = api["Config"](kappa=-.5, half_lives=(.5, 1.5, 4.), window=10,
        min_observations=8, ema_min_observations=250, clip_quantiles=(0., 1.))
    assert config.kappa == -.5 and config.half_lives[0] == .5
    assert config.ema_min_observations > config.window
    assert api["Config"](kappa=0).kappa == 0


def test_quality_empty_ar_keeps_empty_index_and_no_latest_matrix(api):
    index = pd.DatetimeIndex([], name="session")
    scores = pd.DataFrame(index=index, columns=["X", "Y"], dtype=float)
    result = api["absorption_ratio"](scores)
    pd.testing.assert_index_equal(result["series"].index, index)
    assert result["series"].empty
    assert result["latest_correlation"] is None and result["matrix_asof"] is None


@pytest.mark.parametrize("field", ["on_loan", "shares_outstanding"])
def test_quality_infinite_stock_ratios_reject_known_values(api, field):
    stocks, members = quality_positions(pd.Series([True, True]))
    stocks.loc[1, field] = float("inf")
    with pytest.raises(api["InputError"]):
        api["aggregate_stock_positioning"](stocks, members)


@pytest.mark.parametrize("field", ["on_loan", "shares_outstanding"])
def test_quality_unknown_stock_ratio_input_remains_missing(api, field):
    stocks, members = quality_positions(pd.Series([True, True], dtype="boolean"))
    stocks[field] = stocks[field].astype("Float64")
    stocks.loc[1, field] = pd.NA
    result = api["aggregate_stock_positioning"](stocks, members)
    assert pd.isna(result.loc[pd.Timestamp("2024-01-02"), "X"])


def test_quality_borrow_feasibility_requires_known_positive_quantity(api):
    members = pd.DataFrame({"borrowable": pd.Series([True, True, True, True, False, pd.NA], dtype="boolean"),
        "borrow_available": pd.Series([10., 0., -1., pd.NA, 10., 10.], dtype="Float64")})
    result = api["common_short_feasibility"](members)
    assert not result.isna().any()
    assert result.tolist() == [True, False, False, False, False, False]


def test_quality_infinite_locate_is_rejected_instead_of_unlimited_borrow(api):
    members = pd.DataFrame({"borrowable": [True], "borrow_available": [float("inf")]})
    with pytest.raises(api["InputError"]):
        api["common_short_feasibility"](members)


def quality_capacity_inputs():
    return pd.DataFrame({"session": [pd.Timestamp("2024-01-02")], "security_id": ["A"],
        "entry_price": [100.], "adv_shares": [200.], "borrow_available": [15.]})


@pytest.mark.parametrize("field", ["entry_price", "adv_shares", "borrow_available"])
def test_quality_capacity_missing_constraint_never_uses_the_other_limit(api, field):
    frame = quality_capacity_inputs()
    frame[field] = pd.Series([pd.NA], dtype="Float64")
    row = api["capacity_report"](frame, notional_per_leg=10000., max_adv_participation=.1).iloc[0]
    assert pd.isna(row.single_name_capacity_dollars)
    assert row.status == "not_assessed_missing_constraint"
    if field == "borrow_available":
        assert row.execution_capacity_dollars == pytest.approx(2000.)
        assert pd.isna(row.borrow_capacity_dollars)
    if field == "adv_shares":
        assert pd.isna(row.execution_capacity_dollars)
        assert row.borrow_capacity_dollars == pytest.approx(1500.)


@pytest.mark.parametrize("field,kind", [("entry_price", "infinity"), ("adv_shares", "infinity"), ("borrow_available", "infinity"), ("entry_price", "zero"), ("entry_price", "negative"), ("adv_shares", "negative"), ("borrow_available", "negative")])
def test_quality_capacity_known_constraints_have_finite_valid_units(api, field, kind):
    frame = quality_capacity_inputs()
    frame.loc[0, field] = {"infinity": float("inf"), "zero": 0., "negative": -1.}[kind]
    with pytest.raises(api["InputError"]):
        api["capacity_report"](frame, notional_per_leg=10000., max_adv_participation=.1)


def test_quality_capacity_known_limits_and_zero_quantity_have_exact_values(api):
    frame = quality_capacity_inputs()
    row = api["capacity_report"](frame, notional_per_leg=10000., max_adv_participation=.1).iloc[0]
    assert row.execution_capacity_dollars == pytest.approx(2000.)
    assert row.borrow_capacity_dollars == pytest.approx(1500.)
    assert row.single_name_capacity_dollars == pytest.approx(1500.)
    for column in ["adv_shares", "borrow_available"]:
        empty_limit = frame.copy()
        empty_limit.loc[0, column] = 0.
        actual = api["capacity_report"](empty_limit, notional_per_leg=10000., max_adv_participation=.1)
        assert actual.single_name_capacity_dollars.iloc[0] == 0.


@pytest.mark.parametrize("field,kind", [("notional_per_leg", "nan"), ("notional_per_leg", "infinity"), ("max_adv_participation", "nan"), ("max_adv_participation", "infinity")])
def test_quality_capacity_mandate_rejects_nonfinite_values(api, field, kind):
    kwargs = {"notional_per_leg": 10000., "max_adv_participation": .1}
    kwargs[field] = float("nan") if kind == "nan" else float("inf")
    with pytest.raises(api["InputError"]):
        api["capacity_report"](quality_capacity_inputs(), **kwargs)


def test_quality_short_loss_is_not_clipped_at_initial_capital(api):
    assert api["position_return"](100., 300., -1, 0., 1, 0.) == pytest.approx(-2.)
    assert api["position_return"](100., 300., -1, 0., 1, 250.) == pytest.approx(-2.025)


@pytest.mark.parametrize("field", ["on_loan", "shares_outstanding"])
def test_quality_standalone_feature_rejects_infinite_quantity_inputs(api, field):
    sessions = quality_sessions()
    lending = pd.DataFrame({"security_id": ["A"], "event_date": [sessions.session.iloc[0]],
        "available_at": [sessions.open_at.iloc[0]], "utilisation": [10.], "on_loan": [10.],
        "lendable": [100.], "shares_outstanding": [1000.], "broker_count": [2.]})
    lending.loc[0, field] = float("inf")
    members = pd.DataFrame({"security_id": ["A"], "eligible": [True], "gics_sector": ["Materials"]})
    with pytest.raises(api["InputError"]):
        api["features_at"](lending, sessions, members, sessions.decision_at.iloc[0])


def quality_overlay_features():
    """Four scored rows with all flows, one partial, three without flows, one unscored."""
    flows = [(1., .5, -.5), (-1., 0., .2), (.3, -.6, .9), (-.4, .4, -1.2), (.8, np.nan, .1),
        (np.nan, np.nan, np.nan), (np.nan, np.nan, np.nan), (np.nan, np.nan, np.nan), (3., 3., 3.)]
    frame = pd.DataFrame(flows, columns=["scarcity_flow", "positioning_flow", "participation_flow"])
    frame["security_id"] = [f"S{i}" for i in range(len(frame))]
    frame["scarcity_level"] = np.linspace(-1., 1., len(frame))
    frame["positioning_level"] = np.linspace(.5, -.5, len(frame))
    frame["participation_level"] = .1
    frame.loc[8, "scarcity_level"] = np.nan
    return frame


def test_quality_overlay_weight_ignores_rows_without_flows(api):
    result = api["build_scores"](quality_overlay_features())
    contribution = result.overlay - result.baseline
    path = np.array([1., -.8, .6, -1.2]) / 3.
    expected = .5 * (path - path.mean()) / path.std()
    np.testing.assert_allclose(contribution.iloc[:4], expected, atol=1e-12)
    assert contribution.iloc[4] == pytest.approx(.5 * (.3 - path.mean()) / path.std())
    assert contribution.iloc[5:8].tolist() == [0., 0., 0.]
    assert np.isnan(result.overlay.iloc[8])
    assert (result.overlay_flow_cohort == 4).all()


def quality_comparison_legs(flow_from=6, sessions=30, horizon=3):
    """Daily paired legs with overlapping holding periods; flows exist from `flow_from`."""
    days = pd.bdate_range("2024-01-02", periods=sessions + horizon + 1)
    local = [day.tz_localize("Australia/Sydney") for day in days]
    rows = []
    for j in range(sessions):
        for side in ("long", "short"):
            for model, extra in (("baseline", 0.), ("overlay", j / 100.)):
                rows.append({"session": days[j], "side": side, "model": model,
                    "net_return": .01 + extra, "unpriced_selected": 0,
                    "entry_at": local[j + 1] + pd.Timedelta(hours=10),
                    "label_available_at": local[j + horizon] + pd.Timedelta(hours=16),
                    "overlay_flow_cohort": 0 if j < flow_from else 5})
    return pd.DataFrame(rows)


def test_quality_paired_comparison_uses_non_overlapping_informative_dates(api):
    report = api["comparison_report"](quality_comparison_legs())
    used = np.arange(6, 30, 3)
    assert len(report) == 2
    for row in report.to_dict("records"):
        assert row["n_dates"] == len(used) == 8
        assert row["mean"] == pytest.approx(used.mean() / 100.)
        assert row["block_length"] == 1
        assert row["dates_before_flow_information"] == 6


def quality_history(days=8, security_id="A", slope=1.):
    """One stock with a continuous fee definition and quantity history."""
    calendar = pd.date_range("2024-01-02", periods=days)
    local = [day.tz_localize("Australia/Sydney") for day in calendar]
    sessions = pd.DataFrame({"session": calendar,
        "open_at": [day + pd.Timedelta(hours=10) for day in local],
        "close_at": [day + pd.Timedelta(hours=16) for day in local],
        "decision_at": [day + pd.Timedelta(hours=17) for day in local]})
    steps = np.arange(days, dtype=float)
    lending = pd.DataFrame({"security_id": security_id, "event_date": calendar,
        "available_at": [day + pd.Timedelta(hours=16, minutes=15) for day in local],
        "utilisation": 10. + slope * steps, "on_loan": 10. + slope * steps, "lendable": 100.,
        "shares_outstanding": 1000., "broker_count": 2., "annual_fee": .01 + .001 * steps ** 2,
        "fee_definition": "v1", "quantity_definition": "q1"})
    members = pd.DataFrame({"security_id": ["A"], "eligible": [True], "gics_sector": ["Materials"]})
    return lending, sessions, members


def quality_history_features(api, lending, sessions, members, events=None):
    config = api["Config"](window=6, min_observations=4, ema_min_observations=5,
        half_lives=(1, 2, 4), change_window=3)
    return api["features_at"](lending, sessions, members, sessions.decision_at.iloc[-1],
        config, events).iloc[0]


def test_quality_absent_row_and_blank_label_do_not_reset_fee_history(api):
    lending, sessions, members = quality_history()
    lending = lending.drop(index=4).reset_index(drop=True)
    lending.loc[lending.index[-1], "fee_definition"] = None
    row = quality_history_features(api, lending, sessions, members)
    fees = .01 + .001 * np.array([2., 3., 5., 6., 7.]) ** 2
    assert row.fee_valid_count == 5
    assert row.raw_optional_fee_std == pytest.approx(np.log1p(fees.std(ddof=1) * 1e4))
    assert row.blank_definition_label_count == 1


def test_quality_endpoint_growth_requires_one_quantity_definition(api):
    lending, sessions, members = quality_history()
    lending.loc[6:, "quantity_definition"] = "q2"
    row = quality_history_features(api, lending, sessions, members)
    assert np.isnan(row.quantity_growth) and np.isnan(row.raw_optional_demand_quadrant)
    unchanged = quality_history_features(api, *quality_history())
    assert unchanged.quantity_growth == pytest.approx(np.log(17. / 14.))


def test_quality_masked_current_session_is_reported(api):
    lending, sessions, members = quality_history()
    events = pd.DataFrame({"event_id": ["d"], "security_id": ["A"],
        "event_date": [sessions.session.iloc[-1]], "available_at": ["2024-01-01T00:00:00Z"],
        "event_type": ["dividend"], "status": ["active"]})
    assert bool(quality_history_features(api, lending, sessions, members, events).current_session_masked)
    assert not bool(quality_history_features(api, lending, sessions, members).current_session_masked)


def test_quality_overflowing_positioning_ratio_is_rejected(api):
    lending, sessions, members = quality_history()
    lending.loc[lending.index[-1], "shares_outstanding"] = 1e-320
    with pytest.raises(api["InputError"], match="overflow"):
        quality_history_features(api, lending, sessions, members)
    day = sessions.session.iloc[0]
    stocks = pd.DataFrame({"session": [day], "security_id": ["A"], "on_loan": [1.],
        "shares_outstanding": [1e-320], "adv_eligible": [True]})
    memberships = pd.DataFrame({"session": [day], "security_id": ["A"], "index_id": ["X"]})
    with pytest.raises(api["InputError"], match="overflow"):
        api["aggregate_stock_positioning"](stocks, memberships)


def test_quality_positioning_above_one_is_counted_not_rejected(api):
    lending, sessions, members = quality_history()
    lending.loc[lending.index[-2:], "on_loan"] = 1500.
    row = quality_history_features(api, lending, sessions, members)
    assert row.positioning_above_one_count == 2
    assert row.raw_positioning_level == pytest.approx(1.5)


@pytest.mark.parametrize("kind", ["negative", "infinite", "text", "undated", "off_calendar"])
def test_quality_index_metrics_reject_invalid_values_and_dates(api, kind):
    sessions = quality_sessions()
    metrics = pd.DataFrame({"index_id": ["X", "X"], "event_date": list(sessions.session.iloc[:2]),
        "available_at": ["2024-01-01T00:00:00Z"] * 2, "positioning_metric": [.1, .2]})
    if kind == "negative":
        metrics.loc[1, "positioning_metric"] = -.5
    elif kind == "infinite":
        metrics.loc[1, "positioning_metric"] = np.inf
    elif kind == "text":
        metrics["positioning_metric"] = ["0.1", "high"]
    elif kind == "undated":
        metrics.loc[1, "event_date"] = None
    else:
        metrics.loc[1, "event_date"] = pd.Timestamp("2023-12-25")
    with pytest.raises(api["InputError"]):
        api["initial_index_metrics"](metrics, sessions)


def test_quality_initial_stock_vintages_reject_undated_rows(api):
    sessions = quality_sessions()
    day = sessions.session.iloc[0]
    lending = pd.DataFrame({"security_id": ["A", "A"], "event_date": [day, None],
        "available_at": ["2024-01-01T00:00:00Z"] * 2, "on_loan": [1., 2.],
        "shares_outstanding": [10., 10.]})
    members = pd.DataFrame({"session": [day], "security_id": ["A"], "index_id": ["X"],
        "available_at": ["2024-01-01T00:00:00Z"], "adv_eligible": [True]})
    with pytest.raises(api["InputError"]):
        api["aggregate_initial_stock_vintages"](lending, members, sessions)


def quality_export_settings(api, tmp_path):
    inputs = api["synthetic_inputs"](sessions_count=20, securities_count=4, seed=5)
    settings = {key: True for key in ["vintages_are_as_received", "row_availability_is_max_input",
        "point_in_time_universe", "consistent_corporate_actions", "prices_include_distributions"]}
    settings.update(fee_unit="decimal", fee_kind="benchmark")
    for name, frame in inputs.items():
        path = tmp_path / f"quality_markup_{name}.csv"
        frame.to_csv(path, index=False)
        settings[name + "_path"] = str(path)
        settings[name + "_columns"] = {column: column for column in frame.columns}
    return settings


@pytest.mark.parametrize("kind", ["nan", "inf", "boolean", "text", "below_one"])
def test_quality_benchmark_fee_markup_must_be_a_finite_ratio(api, tmp_path, kind):
    settings = quality_export_settings(api, tmp_path)
    settings["borrow_fee_multiplier"] = {"nan": float("nan"), "inf": float("inf"), "boolean": True,
        "text": "2", "below_one": .5}[kind]
    result = api["run_local_exports"](settings, api["Config"](window=5, min_observations=4,
        ema_min_observations=5, half_lives=(1, 2, 4), horizon=2))
    assert result["status"] == "input_error"


def test_quality_benchmark_fee_markup_is_recorded(api, tmp_path):
    settings = quality_export_settings(api, tmp_path)
    settings["borrow_fee_multiplier"] = 1.5
    result = api["run_local_exports"](settings, api["Config"](window=5, min_observations=4,
        ema_min_observations=5, half_lives=(1, 2, 4), horizon=2))
    assert result["status"] == "research_complete", result.get("message")
    assert result["metadata"]["borrow_fee_multiplier"] == 1.5


@pytest.mark.parametrize("active,total", [(-1., None), (None, 2.5), (None, -3.), ("inf", None)])
def test_quality_each_known_lender_count_leg_is_validated(api, active, total):
    with pytest.raises(ValueError):
        api["lender_fraction"](pd.Series([active], dtype=float), pd.Series([total], dtype=float))


def test_quality_negative_borrow_fee_is_rejected(api):
    lending, sessions, members = quality_history()
    lending.loc[lending.index[-1], "annual_fee"] = -.002
    with pytest.raises(api["InputError"]):
        quality_history_features(api, lending, sessions, members)


def test_quality_adjusted_split_history_leaves_positioning_unchanged(api):
    lending, sessions, members = quality_history()
    base = quality_history_features(api, lending, sessions, members)
    adjusted = lending.assign(on_loan=lending.on_loan * 2,
        shares_outstanding=lending.shares_outstanding * 2)
    split = quality_history_features(api, adjusted, sessions, members)
    for column in ["raw_positioning_level", "raw_positioning_flow", "raw_positioning_unusualness"]:
        assert split[column] == pytest.approx(base[column])


def test_quality_unscored_member_does_not_move_the_scored_cohort(api):
    _, sessions, _ = quality_history()
    complete = [quality_history(security_id=name, slope=slope)[0]
        for name, slope in [("A", 1.), ("B", 2.), ("C", -1.)]]
    extreme = quality_history(security_id="D", slope=12.)[0]
    extreme.loc[extreme.index[-1], "utilisation"] = np.nan
    members = pd.DataFrame({"security_id": list("ABCD"), "eligible": True, "gics_sector": "Materials"})
    config = api["Config"](window=6, min_observations=4, ema_min_observations=5,
        half_lives=(1, 2, 4), change_window=3)
    scores = []
    for lending, names in [(pd.concat(complete), "ABC"), (pd.concat(complete + [extreme]), "ABCD")]:
        features = api["features_at"](lending, sessions, members.loc[members.security_id.isin(list(names))],
            sessions.decision_at.iloc[-1], config)
        scores.append(api["build_scores"](features, config).set_index("security_id"))
    columns = ["scarcity_level", "positioning_level", "participation_level", "scarcity_flow",
        "positioning_flow", "participation_flow", "baseline", "overlay"]
    pd.testing.assert_frame_equal(scores[1].loc[list("ABC"), columns], scores[0][columns])
    assert np.isnan(scores[1].loc["D", "scarcity_flow"]) and np.isfinite(scores[1].loc["D", "raw_scarcity_flow"])
    assert scores[1][["eligible_members", "delivered_members", "scored_members"]].iloc[0].tolist() == [4, 3, 3]


def test_quality_ar_structure_flag_persists_and_zero_changes_are_reported(api):
    scores = pd.DataFrame(np.random.default_rng(3).uniform(size=(130, 23)),
        index=pd.bdate_range("2024-01-02", periods=130))
    scores[22] = .5
    scores.iloc[100, 0] = np.nan
    series = api["absorption_ratio"](scores)["series"]
    assert series.zero_change_share.iloc[70] == pytest.approx(1 / 23)
    assert not series.structure_changed_in_delta_window.iloc[:100].any()
    assert series.structure_changed_in_delta_window.iloc[100:].all()


def test_quality_exactly_constant_history_has_zero_dispersion(api):
    moments = api["trailing_moments"](np.full(250, 12.34))
    assert moments["std"] == 0. and moments["count"] == 250


def test_quality_research_models_use_only_registered_features(api):
    dates = pd.bdate_range("2024-01-02", periods=12)
    rows = []
    for j, day in enumerate(dates):
        for i in range(4):
            rows.append({"session": day, "security_id": str(i),
                "decision_at": day.tz_localize("UTC") + pd.Timedelta(hours=17),
                "label_available_at": (day + pd.offsets.BDay(2)).tz_localize("UTC") + pd.Timedelta(hours=16),
                "forward_return": (i - 1.5) * .01, "scarcity_level": i - 1.5, "index_level": (j * i) % 3})
    config = api["Config"](minimum_train_sessions=4, refit_sessions=3, run_research_models=True)
    result = api["chronological_predictions"](pd.DataFrame(rows), config, methods=("ridge",))
    assert (result.model_input_count == 2).all()
