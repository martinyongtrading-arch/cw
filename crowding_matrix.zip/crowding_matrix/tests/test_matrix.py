from pathlib import Path
import runpy
import numpy as np
import pandas as pd
import pytest

@pytest.fixture(scope='module')
def api():
    return runpy.run_path(str(Path(__file__).parents[1]/'work'/'notebook_source.py'))

def f(api,name):
    assert callable(api.get(name)),f'{name}: matrix behavior not implemented'
    return api[name]

def test_initial_metric_parquet_categorical_ids_match_observed_object_cohort(api,tmp_path):
    session=pd.Timestamp('2024-01-02')
    metrics=pd.DataFrame({'index_id':['A','B'],'event_date':[session,session],
                          'available_at':['2024-01-02T04:00:00Z']*2,'positioning_metric':[.1,.2]})
    calendar=pd.DataFrame({'session':[session],'decision_at':['2024-01-02T06:00:00Z'],
                           'close_at':['2024-01-02T05:00:00Z']})
    expected=f(api,'initial_index_metrics')(metrics,calendar)
    metrics['index_id']=pd.Categorical(metrics.index_id,categories=['A','B','UNUSED'])
    path=tmp_path/'categorical_metrics.parquet'; metrics.to_parquet(path,index=False)
    loaded=f(api,'load_table')(path,{c:c for c in metrics})
    assert isinstance(loaded.index_id.dtype,pd.CategoricalDtype)
    actual=f(api,'initial_index_metrics')(loaded,calendar)
    assert list(actual.columns)==['A','B']
    pd.testing.assert_frame_equal(actual,expected,check_column_type=False,check_categorical=False)

def test_stock_aggregation_parquet_categories_do_not_create_phantom_indices(api,tmp_path):
    stocks=pd.DataFrame({'session':[pd.Timestamp('2024-01-02')]*2,'security_id':['s1','s2'],
                         'on_loan':[10.,20.],'shares_outstanding':[100.,100.],'adv_eligible':[True,True]})
    members=pd.DataFrame({'session':stocks.session,'security_id':stocks.security_id,'index_id':['A','B']})
    expected=f(api,'aggregate_stock_positioning')(stocks,members)
    members['index_id']=pd.Categorical(members.index_id,categories=['A','B','UNUSED'])
    path=tmp_path/'categorical_members.parquet'; members.to_parquet(path,index=False)
    loaded=f(api,'load_table')(path,{c:c for c in members})
    actual=f(api,'aggregate_stock_positioning')(stocks,loaded)
    assert list(actual.columns)==['A','B']
    pd.testing.assert_frame_equal(actual,expected,check_column_type=False,check_categorical=False)

def test_uniform_spectrum_benchmark_is_first_fifth(api):
    assert f(api,'absorption_from_correlation')(np.eye(20),4)==pytest.approx(.2)

def test_correlation_singular_values_are_not_squared(api):
    corr=.5*np.ones((20,20))+.5*np.eye(20)
    assert f(api,'absorption_from_correlation')(corr,4)==pytest.approx(.6)

def test_identical_indices_raise_concentration_and_ridge_is_tiny(api):
    value=f(api,'absorption_from_correlation')(np.ones((20,20)),4)
    assert .99999<value<=1

def score_fixture(days=90,indices=25,seed=8):
    rng=np.random.default_rng(seed)
    return pd.DataFrame(rng.uniform(size=(days,indices)),index=pd.bdate_range('2020-01-02',periods=days),columns=[f'INDEX_{i}' for i in range(indices)])

def test_exact_sixty_lagged_changes_and_no_current_bar(api):
    scores=score_fixture()
    run=f(api,'absorption_ratio')
    a=run(scores)['series']
    assert a.AR.iloc[:61].isna().all()
    assert np.isfinite(a.AR.iloc[61])
    changed=scores.copy(); changed.iloc[70:]=1-changed.iloc[70:]
    b=run(changed)['series']
    pd.testing.assert_series_equal(a.AR.iloc[:71],b.AR.iloc[:71])
    assert a.n_observations.iloc[70]==60

def test_drop_incomplete_indices_not_time_rows_recompute_k(api):
    scores=score_fixture(indices=25); scores.iloc[50,0]=np.nan
    result=f(api,'absorption_ratio')(scores)['series']
    row=result.iloc[70]
    assert row.N==24 and row.k==4
    assert row.n_observations==60
    assert row.dropped_missing==1

def test_current_day_nan_excludes_index_without_using_current_changes(api):
    scores=score_fixture(indices=25); scores.iloc[70,0]=np.nan
    row=f(api,'absorption_ratio')(scores)['series'].iloc[70]
    assert row.N==24

def test_below_twenty_indices_returns_missing(api):
    result=f(api,'absorption_ratio')(score_fixture(indices=19))['series']
    assert result.AR.isna().all()

def test_constant_changes_are_not_spearman_inputs(api):
    scores=score_fixture(indices=21); scores.iloc[:,0]=.5; scores.iloc[:,1]=.5
    row=f(api,'absorption_ratio')(scores)['series'].iloc[70]
    assert row.N==19 and np.isnan(row.AR) and row.dropped_constant==2

def test_constant_correlation_shrinkage_preserves_diagonal_and_psd(api):
    x=np.random.default_rng(2).normal(size=(60,80))
    x[:,1]=x[:,0]
    corr,intensity=f(api,'constant_correlation_shrinkage')(x)
    np.testing.assert_allclose(np.diag(corr),1.,atol=1e-12)
    np.testing.assert_allclose(corr,corr.T,atol=1e-12)
    assert 0<=intensity<=1
    assert np.linalg.eigvalsh(corr).min()>-1e-10

def test_shrinkage_trigger_follows_prose_n_greater_than_sixty(api):
    run=f(api,'absorption_ratio')
    a=run(score_fixture(days=63,indices=60))['series'].iloc[-1]
    b=run(score_fixture(days=63,indices=61))['series'].iloc[-1]
    assert not a.shrinkage_applied and b.shrinkage_applied

def test_delta_uses_ar_level_std_full_windows_zero_denominator_missing(api):
    x=pd.Series(np.arange(300,dtype=float)/1000)
    result=f(api,'delta_ar')(x)
    assert result.iloc[:251].isna().all()
    expected=((np.arange(285,300).mean()-np.arange(48,300).mean())/np.arange(48,300).std(ddof=1))
    assert result.iloc[-1]==pytest.approx(expected)
    assert f(api,'delta_ar')(pd.Series([.2]*300)).isna().all()

def test_index_score_ranks_across_indices_and_has_252_full_normalization(api):
    metrics=pd.DataFrame({'a':np.arange(260.),'b':np.arange(260.)+10,'c':np.arange(260.)+20})
    result=f(api,'index_crowding_scores')(metrics)
    assert result.iloc[-1].tolist()==pytest.approx([1/3,2/3,1.])
    z=f(api,'index_crowding_scores')(metrics,normalize=True)
    assert z.iloc[:251].isna().all().all()

def test_initial_index_release_ignores_later_revisions(api):
    dates=pd.bdate_range('2024-01-02',periods=3)
    decisions=pd.DataFrame({'session':dates,'decision_at':[d.tz_localize('UTC')+pd.Timedelta(hours=21) for d in dates],
                            'close_at':[d.tz_localize('UTC')+pd.Timedelta(hours=21) for d in dates]})
    vintages=pd.DataFrame({'index_id':['A','A','B'],'event_date':[dates[0],dates[0],dates[0]],
       'available_at':['2024-01-02T20:00:00Z','2024-01-03T20:00:00Z','2024-01-02T20:00:00Z'],'positioning_metric':[1.,99.,2.]})
    result=f(api,'initial_index_metrics')(vintages,decisions)
    assert result.loc[dates[0],'A']==1.
    assert np.isnan(result.loc[dates[1],'A'])

def test_index_aggregation_is_equity_positioning_not_index_prices(api):
    day=pd.Timestamp('2024-01-02')
    stocks=pd.DataFrame({'session':[day]*3,'security_id':['A','B','C'],'on_loan':[10.,20.,30.],'shares_outstanding':[100.]*3,'adv_eligible':[True,True,False]})
    members=pd.DataFrame({'session':[day]*4,'index_id':['X','X','Y','Y'],'security_id':['A','B','B','C']})
    result=f(api,'aggregate_stock_positioning')(stocks,members)
    assert result.loc[day,'X']==pytest.approx(.15)
    assert result.loc[day,'Y']==pytest.approx(.2)

def test_missing_constituent_metric_does_not_silently_renormalize(api):
    day=pd.Timestamp('2024-01-02')
    stocks=pd.DataFrame({'session':[day]*2,'security_id':['A','B'],'on_loan':[10.,np.nan],'shares_outstanding':[100.,100.],'adv_eligible':[True,True]})
    members=pd.DataFrame({'session':[day]*2,'index_id':['X','X'],'security_id':['A','B']})
    assert np.isnan(f(api,'aggregate_stock_positioning')(stocks,members).loc[day,'X'])

def test_equity_sized_matrix_rejected_before_quadratic_allocation(api):
    with pytest.raises(ValueError,match='200'):
        f(api,'absorption_ratio')(pd.DataFrame(np.full((63,7000),.5)))

def test_stock_index_aggregation_enforces_initial_release_and_close_cutoff(api):
    day=pd.Timestamp('2024-01-02')
    sessions=pd.DataFrame({'session':[day],'expected_event_date':[day],'decision_at':['2024-01-02T06:00:00Z'],'close_at':['2024-01-02T06:00:00Z']})
    lending=pd.DataFrame({'security_id':['A','A','B'],'event_date':[day]*3,'available_at':['2024-01-02T05:00:00Z','2024-01-02T05:30:00Z','2024-01-02T07:00:00Z'],'on_loan':[10.,99.,20.],'shares_outstanding':[100.]*3})
    members=pd.DataFrame({'session':[day]*2,'security_id':['A','B'],'index_id':['X','Y'],'available_at':['2024-01-02T01:00:00Z']*2,'adv_eligible':[True,True]})
    metrics=f(api,'aggregate_initial_stock_vintages')(lending,members,sessions)
    assert metrics.loc[day,'X']==pytest.approx(.1)
    assert np.isnan(metrics.loc[day,'Y'])

def test_unconfigured_index_path_needs_no_prices(api):
    result=f(api,'run_index_exports')({})
    assert result['status']=='setup_required'
    assert all('prices' not in item for item in result['missing'])

def test_index_initial_release_after_close_is_unavailable_even_if_before_decision(api):
    day=pd.Timestamp('2024-01-02')
    sessions=pd.DataFrame({'session':[day],'decision_at':['2024-01-02T07:00:00Z'],'close_at':['2024-01-02T06:00:00Z']})
    data=pd.DataFrame({'index_id':['EARLY','LATE'],'event_date':[day]*2,'available_at':['2024-01-02T05:59:00Z','2024-01-02T06:30:00Z'],'positioning_metric':[1.,2.]})
    result=f(api,'initial_index_metrics')(data,sessions)
    assert result.loc[day,'EARLY']==1. and np.isnan(result.loc[day,'LATE'])

def test_index_path_requires_actual_close_cutoff(api):
    day=pd.Timestamp('2024-01-02')
    data=pd.DataFrame({'index_id':['A'],'event_date':[day],'available_at':['2024-01-02T05:00:00Z'],'positioning_metric':[1.]})
    with pytest.raises(ValueError,match='close_at'):
        f(api,'initial_index_metrics')(data,pd.DataFrame({'session':[day],'decision_at':['2024-01-02T07:00:00Z']}))

def test_changing_ranking_peers_flag_mechanical_ar_even_when_matrix_cohort_stable(api):
    metrics=pd.DataFrame(np.tile(np.arange(1.,27.),(70,1)))
    metrics.iloc[::2,-1]=np.nan
    scores=f(api,'index_crowding_scores')(metrics)
    series=f(api,'absorption_ratio')(scores)['series']
    row=series.iloc[65]
    assert row.N==25 and row.AR>.99999
    assert not row.cohort_changed
    assert row.ranking_cohort_changed_in_window

def test_duplicate_index_can_raise_ar_without_new_economic_information(api):
    corr=np.eye(21); corr[0,20]=corr[20,0]=1.
    original=f(api,'absorption_from_correlation')(np.eye(20),4)
    duplicate=f(api,'absorption_from_correlation')(corr,4)
    assert original==pytest.approx(.2)
    assert duplicate==pytest.approx(5/21,abs=1e-6)
    assert duplicate>original
