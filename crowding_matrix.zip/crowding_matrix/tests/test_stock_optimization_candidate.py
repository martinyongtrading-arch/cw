"""Parity tests for invocation-scoped preparation; no real market data."""
from pathlib import Path
import runpy

import numpy as np
import pandas as pd
import pytest


@pytest.fixture(scope="module")
def api():
    root = Path(__file__).resolve().parents[1]
    return runpy.run_path(str(root / 'work' / 'notebook_source.py'))


def optimization_fixture(api):
    data = api["synthetic_inputs"](sessions_count=18, securities_count=5, seed=741)
    dates = data["sessions"].session
    lending = data["lending"].copy()
    lending["active_lenders"] = 2.0
    lending["total_lenders"] = 4.0
    lending["annual_fee"] = np.linspace(.001, .02, len(lending))
    lending["fee_definition"] = np.where(lending.event_date < dates.iloc[9], "old", "new")
    lending["quantity_definition"] = lending.fee_definition
    # One absent source session and one name with no history remain absent.
    lending = lending[lending.event_date.ne(dates.iloc[5]) & lending.security_id.ne(lending.security_id.iloc[-1])]
    lending = lending.reset_index(drop=True)
    revised = lending.iloc[[1]].copy()
    revised["available_at"] = data["sessions"].decision_at.iloc[12]
    revised["utilisation"] = np.nan  # A newer NaN replaces, not fills from, an older value.
    lending = pd.concat([lending, revised], ignore_index=True)
    data["lending"] = lending
    data["events"] = pd.DataFrame([
        dict(event_id="E",security_id=lending.security_id.iloc[0],event_date=dates.iloc[13],
             available_at=data["sessions"].decision_at.iloc[1],event_type="dividend",status="active"),
        dict(event_id="E",security_id=lending.security_id.iloc[0],event_date=dates.iloc[15],
             available_at=data["sessions"].decision_at.iloc[7],event_type="dividend",status="active"),
        dict(event_id="E",security_id=lending.security_id.iloc[0],event_date=dates.iloc[15],
             available_at=data["sessions"].decision_at.iloc[11],event_type="dividend",status="cancelled"),
    ])
    return data


def test_optimized_panel_matches_revisions_missing_histories_resets_events(api):
    data = optimization_fixture(api)
    config = api["Config"](window=5,min_observations=4,ema_min_observations=4,half_lives=(1,2,4),change_window=5)
    expected = api["_build_feature_panel_reference"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    actual = api["build_feature_panel"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    pd.testing.assert_frame_equal(actual, expected, check_exact=True)


def test_preparation_defers_unseen_conflicting_lending_and_event_revisions(api):
    data = optimization_fixture(api)
    config = api["Config"](window=5,min_observations=4,ema_min_observations=4,half_lives=(1,2,4))
    future = data["lending"].iloc[[-1]].copy()
    conflict = future.copy(); conflict["utilisation"] = 77.0
    data["lending"] = pd.concat([data["lending"], conflict],ignore_index=True)
    event = data["events"].iloc[[-1]].copy()
    event["status"] = "active"
    data["events"] = pd.concat([data["events"],event],ignore_index=True)
    prepared = api["_prepare_stock_context"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    decision = data["sessions"].decision_at.iloc[3]
    members = api["universe_at"](data["universe"],data["sessions"].session.iloc[3],decision)
    expected = api["features_at"](data["lending"],data["sessions"],members,decision,config,data["events"])
    actual = api["_features_at_impl"](prepared["lending"],prepared["calendar"],members,decision,config,prepared["events"],_prepared=prepared)
    pd.testing.assert_frame_equal(actual,expected,check_exact=True)
    with pytest.raises(ValueError,match="Conflicting"):
        api["_features_at_impl"](prepared["lending"],prepared["calendar"],members,data["sessions"].decision_at.iloc[-1],config,prepared["events"],_prepared=prepared)


def test_cached_ema_geometry_preserves_ranks_and_exact_reduction_order(api):
    optimized = api["_prepared_ema_contrasts"](330)
    for values in [np.full(330,5.),np.arange(330.),-np.arange(330.),
                   np.where(np.arange(330)%7==0,np.nan,np.arange(330,dtype=float))]:
        for length in [10,128,330]:
            expected = api["ema_contrasts"](values[:length],(1,2,4,8,16,32,64,128),3)
            actual = optimized(values[:length],(1,2,4,8,16,32,64,128),3)
            np.testing.assert_array_equal(actual,expected)


def test_new_invocation_observes_caller_changes_and_does_not_mutate_inputs(api):
    data = optimization_fixture(api)
    config = api["Config"](window=5,min_observations=4,ema_min_observations=4,half_lives=(1,2,4))
    originals = {name: frame.copy(deep=True) for name,frame in data.items()}
    first = api["build_feature_panel"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    for name,frame in originals.items():
        pd.testing.assert_frame_equal(data[name],frame)
    data["lending"].loc[data["lending"].event_date.eq(data["sessions"].session.iloc[-1]),"utilisation"] = 33.0
    second = api["build_feature_panel"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    expected = api["_build_feature_panel_reference"](data["lending"],data["sessions"],data["universe"],config,data["events"])
    pd.testing.assert_frame_equal(second,expected,check_exact=True)
    assert not first.equals(second)


def test_no_feature_path_does_not_eagerly_validate_unused_events(api):
    data = optimization_fixture(api)
    members = data["universe"].iloc[:0].copy()
    invalid_events = pd.DataFrame({"not_an_event_schema":[1]})
    expected = api["_build_feature_panel_reference"](data["lending"],data["sessions"],members,events=invalid_events)
    actual = api["build_feature_panel"](data["lending"],data["sessions"],members,events=invalid_events)
    pd.testing.assert_frame_equal(actual,expected,check_exact=True)


def test_event_grouping_preserves_original_id_payload_conflicts(api):
    data = optimization_fixture(api)
    old_id = data["lending"].security_id.iloc[0]
    data["lending"]["security_id"] = data["lending"].security_id.replace({old_id:"1"})
    data["universe"]["security_id"] = data["universe"].security_id.replace({old_id:"1"})
    events = pd.DataFrame([
        dict(event_id="SAME",security_id=1,event_date=data["sessions"].session.iloc[13],
             available_at=data["sessions"].decision_at.iloc[1],event_type="dividend",status="active"),
        dict(event_id="SAME",security_id="1",event_date=data["sessions"].session.iloc[13],
             available_at=data["sessions"].decision_at.iloc[1],event_type="dividend",status="active"),
    ])
    config = api["Config"](window=5,min_observations=4,ema_min_observations=4,half_lives=(1,2,4))
    with pytest.raises(ValueError,match="Conflicting event"):
        api["_build_feature_panel_reference"](data["lending"],data["sessions"],data["universe"],config,events)
    with pytest.raises(ValueError,match="Conflicting event"):
        api["build_feature_panel"](data["lending"],data["sessions"],data["universe"],config,events)
