from pathlib import Path
import runpy
import numpy as np
import pandas as pd
import pytest

SOURCE = Path(__file__).parents[1] / 'work' / 'notebook_source.py'

@pytest.fixture(scope='module')
def api():
    return runpy.run_path(str(SOURCE)) if SOURCE.exists() else {}

def function(api, name):
    assert callable(api.get(name)), f'{name}: required stock-crowding behavior is not implemented'
    return api[name]

def observations():
    return pd.DataFrame({
        'security_id':['A','A','A'],
        'event_date':['2024-01-02','2024-01-03','2024-01-02'],
        'available_at':['2024-01-03T01:00:00Z','2024-01-04T01:00:00Z','2024-02-01T01:00:00Z'],
        'utilisation':[20.,30.,99.], 'on_loan':[20.,30.,99.],
        'lendable':[100.,100.,100.], 'shares_outstanding':[1000.]*3,
        'broker_count':[2.,3.,9.]})

def test_late_revision_cannot_rewrite_old_history(api):
    snapshot=function(api,'history_asof')(observations(),'2024-01-04T02:00:00Z')
    assert snapshot.utilisation.tolist()==[20.,30.]
    revised=function(api,'history_asof')(observations(),'2024-02-02T02:00:00Z')
    assert revised.utilisation.tolist()==[99.,30.]

def test_conflicting_same_timestamp_rejected_independent_of_input_order(api):
    frame=observations().iloc[[0,0]].copy()
    frame.loc[frame.index[-1],'utilisation']=21.
    frame=frame.reset_index(drop=True)
    frame.loc[0,'utilisation']=20.
    with pytest.raises(ValueError,match='conflict'):
        function(api,'history_asof')(frame,'2024-02-02T02:00:00Z')

def test_timezone_naive_availability_is_rejected(api):
    frame=observations(); frame.loc[0,'available_at']='2024-01-03 01:00:00'
    with pytest.raises(ValueError,match='timezone'):
        function(api,'history_asof')(frame,'2024-02-02T02:00:00Z')

@pytest.mark.parametrize('unit,value', [('decimal',.05),('percent',5.),('bps',500.)])
def test_fee_unit_conversion_has_one_annual_decimal_result(api,unit,value):
    result=function(api,'canonical_fee')(pd.Series([value]),unit)
    assert result.iloc[0]==pytest.approx(.05)

def test_ordinal_fee_is_not_a_rate(api):
    with pytest.raises(ValueError,match='unit'):
        function(api,'canonical_fee')(pd.Series([3.]),'DCBS')

def test_lender_fraction_zero_and_proportional_counts(api):
    result=function(api,'lender_fraction')(pd.Series([0.,2.,4.,0.]),pd.Series([4.,4.,8.,0.]))
    assert result.iloc[:3].tolist()==[0.,.5,.5]
    assert np.isnan(result.iloc[3])

@pytest.mark.parametrize('active,total',[(3,2),(1,0),(-1,2),(1.5,3)])
def test_invalid_lender_populations_rejected(api,active,total):
    with pytest.raises(ValueError):
        function(api,'lender_fraction')(pd.Series([active]),pd.Series([total]))

def test_constant_history_has_no_flow_or_curvature(api):
    slope,curvature,count=function(api,'ema_contrasts')(np.full(300,5.),(1,2,4,8,16,32,64,128),250)
    assert count==300
    assert slope==pytest.approx(0.,abs=1e-12)
    assert curvature==pytest.approx(0.,abs=1e-12)

def test_linear_ramp_is_not_temporal_acceleration(api):
    slope,curvature,_=function(api,'ema_contrasts')(np.arange(400.),(1,2,4,8,16,32,64,128),250)
    reverse=function(api,'ema_contrasts')(-np.arange(400.),(1,2,4,8,16,32,64,128),250)
    assert slope>0
    assert abs(curvature)>1
    assert reverse[0]==pytest.approx(-slope)

def test_missing_observation_never_counts_toward_warmup(api):
    slope,_,count=function(api,'ema_contrasts')(np.array([1.,np.nan,2.]),(1,2,4),3)
    assert count==2 and np.isnan(slope)

def test_mask_does_not_relax_actual_observation_minimum(api):
    result=function(api,'trailing_moments')(np.array([1.,2.,np.nan,np.nan,5.]),5,4)
    assert result['count']==3 and np.isnan(result['std'])
    result=function(api,'trailing_moments')(np.array([1.,2.,3.,4.,np.nan]),5,4)
    assert result['std']==pytest.approx(np.sqrt(5/3))

def test_fee_definition_break_resets_risk_history(api):
    result=function(api,'trailing_moments')(np.array([.01,.50,.02,.02]),4,3,regimes=np.array(['old','old','new','new']))
    assert result['count']==2 and np.isnan(result['std'])

def test_cross_section_ties_constant_and_missing_stay_finite(api):
    result=function(api,'cross_section')(pd.Series([2.,2.,np.nan]),(.01,.99))
    assert result.iloc[:2].tolist()==[0.,0.]
    assert np.isnan(result.iloc[2])

def test_missing_path_does_not_increase_other_family_weights(api):
    result=function(api,'fixed_overlay')(pd.DataFrame({'scarcity_flow':[1.,np.nan], 'positioning_flow':[0.,1.], 'participation_flow':[0.,0.]}))
    assert result.tolist()==pytest.approx([1/3,1/3])

def test_purge_requires_actual_label_availability(api):
    labels=pd.DataFrame({'label_available_at':pd.to_datetime(['2024-02-01T00:00:00Z','2024-02-01T00:00:01Z'],utc=True)})
    mask=function(api,'mature_labels')(labels,'2024-02-01T00:00:00Z')
    assert mask.tolist()==[True,False]

def test_short_return_sign_and_calendar_borrow_accrual(api):
    value=function(api,'position_return')(100.,110.,-1,.365,3,0.)
    assert value==pytest.approx(-.103)
    gain=function(api,'position_return')(100.,90.,-1,.365,3,0.)
    assert gain==pytest.approx(.097)

def test_cover_ledger_loses_money_on_squeeze_despite_zero_terminal_return(api):
    value=function(api,'cover_ledger')([100.,200.,100.],1,None)
    assert value['pnl_per_initial_share']==pytest.approx(-100.)
    hold=function(api,'cover_ledger')([100.,200.,100.],None,None)
    assert hold['pnl_per_initial_share']==pytest.approx(0.)

def test_missing_borrow_rate_does_not_create_free_short(api):
    with pytest.raises(ValueError,match='fee'):
        function(api,'position_return')(100.,90.,-1,np.nan,1,0.)

def test_local_csv_and_parquet_mapping_execute(api,tmp_path):
    frame=pd.DataFrame({'Vendor ID':['A'],'Vendor U':[20.]})
    mapping={'security_id':'Vendor ID','utilisation':'Vendor U'}
    for suffix in ['csv','parquet']:
        path=tmp_path/f'input.{suffix}'
        if suffix=='csv': frame.to_csv(path,index=False)
        else: frame.to_parquet(path,index=False)
        actual=function(api,'load_table')(path,mapping)
        assert actual.columns.tolist()==['security_id','utilisation']
        assert actual.iloc[0].to_dict()=={'security_id':'A','utilisation':20.}

def test_all_missing_histories_remain_missing_not_zero(api):
    moments=function(api,'trailing_moments')(np.full(250,np.nan),250,200)
    assert moments['count']==0 and np.isnan(moments['mean'])

def test_common_feasibility_does_not_depend_on_challenger_score(api):
    data=pd.DataFrame({'security_id':['A','B','C'],'borrowable':[True,False,True], 'borrow_available':[100.,0.,1.]})
    mask=function(api,'common_short_feasibility')(data)
    assert mask.tolist()==[True,False,True]

def tiny_inputs():
    dates=pd.bdate_range('2024-01-02',periods=8)
    sessions=pd.DataFrame({'session':dates,'decision_at':[d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=17) for d in dates]})
    rows=[]
    for j,d in enumerate(dates):
        for i,name in enumerate(['A','B','C']):
            rows.append(dict(security_id=name,event_date=d,available_at=d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=16),utilisation=10.+j*(i+1),on_loan=10.+j*(i+1),lendable=100.,shares_outstanding=1000.,broker_count=i+1.,annual_fee=.01,fee_definition='v1',active_lenders=1.,total_lenders=2.))
    members=pd.DataFrame({'security_id':['A','B','C'],'eligible':[True]*3,'gics_sector':['Materials','Financials','Materials']})
    return pd.DataFrame(rows),sessions,members

@pytest.mark.parametrize('entry,invalid',[
    ('validation','fractional'),('standalone','fractional'),
    ('validation','negative'),('standalone','negative'),
    ('validation','infinite'),('standalone','infinite')])
def test_entity_broker_count_contract_rejects_invalid_values_without_rounding(api,entry,invalid):
    data=function(api,'synthetic_inputs')(sessions_count=8,securities_count=3)
    data['lending'].loc[data['lending'].index[-1],'broker_count']={'fractional':2.5,'negative':-1.,'infinite':np.inf}[invalid]
    with pytest.raises(ValueError,match='broker_count'):
        if entry=='validation':
            function(api,'validate_inputs')(data['lending'],data['sessions'],data['universe'])
        else:
            members=data['universe'].loc[data['universe'].session.eq(data['sessions'].session.iloc[-1])]
            function(api,'features_at')(data['lending'],data['sessions'],members,data['sessions'].decision_at.iloc[-1])

def test_standalone_count_validation_uses_only_available_vintages(api):
    frame,sessions,members=tiny_inputs()
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4))
    expected=function(api,'features_at')(frame,sessions,members,sessions.decision_at.iloc[-1],cfg)
    future=frame.iloc[[0]].copy(); future['broker_count']=2.5
    future['available_at']=sessions.decision_at.iloc[-1]+pd.Timedelta(days=5)
    actual=function(api,'features_at')(pd.concat([frame,future],ignore_index=True),sessions,members,sessions.decision_at.iloc[-1],cfg)
    pd.testing.assert_frame_equal(actual,expected,check_exact=True)

def test_integer_broker_counts_and_unknowns_preserve_their_values(api):
    data=function(api,'synthetic_inputs')(sessions_count=8,securities_count=3)
    last=data['sessions'].session.iloc[-1]
    latest=data['lending'].event_date.eq(last)
    data['lending'].loc[latest,'broker_count']=[0.,2.,np.nan]
    original=data['lending'].copy(deep=True)
    function(api,'validate_inputs')(data['lending'],data['sessions'],data['universe'])
    members=data['universe'].loc[data['universe'].session.eq(last)]
    result=function(api,'features_at')(data['lending'],data['sessions'],members,data['sessions'].decision_at.iloc[-1])
    np.testing.assert_allclose(result.raw_participation_level,[0.,np.log(3.),np.nan],equal_nan=True)
    pd.testing.assert_frame_equal(data['lending'],original)

def test_full_feature_snapshot_is_future_revision_invariant(api):
    frame,sessions,members=tiny_inputs()
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4),change_window=2)
    build=function(api,'features_at')
    old=build(frame,sessions,members,sessions.decision_at.iloc[-1],cfg)
    revision=frame.iloc[[2]].copy(); revision['utilisation']=99.; revision['available_at']='2024-03-01T00:00:00Z'
    extended=pd.concat([frame,revision],ignore_index=True)
    new=build(extended.sample(frac=1,random_state=42),sessions,members,sessions.decision_at.iloc[-1],cfg)
    pd.testing.assert_frame_equal(old.sort_index(axis=1),new.sort_index(axis=1))
    core=[c for c in old.filter(regex='_(level|flow|curvature|unusualness|instability|within_gics)$') if not c.startswith(('raw_','optional_'))]
    assert len(core)==16

def test_absent_latest_name_is_not_a_zero_loan(api):
    frame,sessions,members=tiny_inputs()
    frame=frame.loc[~((frame.event_date==frame.event_date.max())&(frame.security_id=='A'))]
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4))
    result=function(api,'features_at')(frame,sessions,members,sessions.decision_at.iloc[-1],cfg)
    a=result.set_index('security_id').loc['A']
    assert np.isnan(a.scarcity_level) and np.isnan(a.positioning_level)
    assert a.latest_row_missing

def test_event_revision_only_changes_masks_after_announcement(api):
    _,sessions,_=tiny_inputs()
    events=pd.DataFrame({'event_id':['e','e'],'security_id':['A','A'],'event_date':[sessions.session.iloc[4],sessions.session.iloc[6]],'available_at':['2024-01-01T00:00:00Z','2024-03-01T00:00:00Z'],'event_type':['dividend','dividend'],'status':['active','active']})
    mask=function(api,'event_mask')(sessions,events,'A',sessions.decision_at.iloc[-1])
    initial=function(api,'event_mask')(sessions,events.iloc[:1],'A',sessions.decision_at.iloc[-1])
    np.testing.assert_array_equal(mask,initial)

def test_price_labels_start_after_decision_and_keep_calendar_days(api):
    _,sessions,_=tiny_inputs()
    sessions['open_at']=[d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=10) for d in sessions.session]
    sessions['close_at']=[d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=16) for d in sessions.session]
    prices=pd.DataFrame({'security_id':['A']*8,'session':sessions.session,'open':[100.]*8,'close':[100.,101.,102.,103.,104.,105.,106.,107.]})
    result=function(api,'make_labels')(prices,sessions,2)
    first=result.iloc[0]
    assert first.entry_session==sessions.session.iloc[1]
    assert first.exit_session==sessions.session.iloc[2]
    assert first.forward_return==pytest.approx(.02)
    assert pd.Timestamp(first.entry_at)>pd.Timestamp(sessions.decision_at.iloc[0])

def test_directional_block_inference_handles_constant_and_overlap(api):
    result=function(api,'paired_block_inference')([.01]*40,5,200,7)
    assert result['mean']==pytest.approx(.01)
    assert result['lower']<=.01<=result['upper']
    assert result['p_value']<=.05
    assert result['n_dates']==40

def test_no_data_is_not_reported_as_zero_performance(api):
    result=function(api,'paired_block_inference')([],5,200,7)
    assert result['status']=='insufficient'
    assert np.isnan(result['mean'])

def test_fixed_research_models_cannot_train_on_future_labels(api):
    dates=pd.bdate_range('2024-01-02',periods=12)
    rows=[]
    for j,d in enumerate(dates):
        for i in range(4):
            rows.append(dict(session=d,security_id=str(i),decision_at=d.tz_localize('UTC')+pd.Timedelta(hours=17),
                             label_available_at=(d+pd.offsets.BDay(2)).tz_localize('UTC')+pd.Timedelta(hours=16),
                             forward_return=(i-1.5)*.01,scarcity_level=i-1.5,baseline=i-1.5))
    frame=pd.DataFrame(rows)
    cfg=api['Config'](minimum_train_sessions=4,refit_sessions=3,run_research_models=True)
    predict=function(api,'chronological_predictions')
    a=predict(frame,cfg,methods=('ridge','lasso','elastic_net','pcr','trees'))
    changed=frame.copy(); changed.loc[changed.session>=dates[-1],'forward_return']=999.
    b=predict(changed,cfg,methods=('ridge','lasso','elastic_net','pcr','trees'))
    columns=['ridge','lasso','elastic_net','pcr','trees']
    pd.testing.assert_frame_equal(a[columns],b[columns])
    assert a[columns].notna().any().all()
    assert (a.loc[a.fit_at.notna(),'latest_training_label_at']<=a.loc[a.fit_at.notna(),'fit_at']).all()

def test_portfolio_uses_same_stock_feasibility_for_both_scores(api):
    data=pd.DataFrame({'session':[pd.Timestamp('2024-01-02')]*3,'security_id':['A','B','C'],
      'baseline':[3.,2.,1.],'overlay':[1.,3.,2.], 'borrowable':[True,False,True], 'borrow_available':[100.]*3,
      'entry_price':[100.]*3,'exit_price':[90.,200.,100.],'annual_fee':[0.]*3,
      'entry_at':pd.to_datetime(['2024-01-03T00:00:00Z']*3),'exit_at':pd.to_datetime(['2024-01-04T00:00:00Z']*3),
      'round_trip_cost_bps':[0.]*3})
    result=function(api,'evaluate_legs')(data,api['Config'](leg_fraction=.34))
    shorts=result[result.side=='short']
    assert 'B' not in ','.join(shorts.selected_ids)
    assert set(shorts.model)=={'baseline','overlay'}

def test_synthetic_demo_runs_without_real_market_data(api):
    demo=function(api,'synthetic_inputs')(sessions_count=35,securities_count=8,seed=11)
    cfg=api['Config'](window=10,min_observations=8,ema_min_observations=10,half_lives=(1,2,4),horizon=3,minimum_train_sessions=10)
    result=function(api,'run_analysis')(**demo,config=cfg,mode='SYNTHETIC MACHINERY ONLY')
    assert len(result['features'])>0 and len(result['legs'])>0
    assert result['metadata']['mode']=='SYNTHETIC MACHINERY ONLY'
    assert result['metadata']['alpha_validated'] is False

def test_unconfigured_real_input_reports_setup_instead_of_fake_results(api):
    result=function(api,'run_local_exports')({},api['Config']())
    assert result['status']=='setup_required'
    assert 'features' not in result

def test_whole_date_outage_preserves_missing_session(api):
    lending,sessions,members=tiny_inputs()
    lending=lending.loc[lending.event_date<lending.event_date.max()]
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4))
    result=function(api,'features_at')(lending,sessions,members,sessions.decision_at.iloc[-1],cfg)
    assert result.latest_row_missing.all()
    assert (result.covered_session_span==8).all()
    assert (result.data_cutoff==sessions.session.iloc[-1]).all()

def test_missing_future_outcome_never_replaces_selected_stock(api):
    lending,sessions,members=tiny_inputs()
    sessions['open_at']=[d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=10) for d in sessions.session]
    sessions['close_at']=[d.tz_localize('Australia/Sydney')+pd.Timedelta(hours=16) for d in sessions.session]
    universe=pd.concat([members.assign(session=row.session,available_at=row.decision_at-pd.Timedelta(hours=1),borrowable=True,borrow_available=100.,round_trip_cost_bps=0.) for row in sessions.itertuples()],ignore_index=True)
    prices=pd.DataFrame([dict(session=d,security_id=n,open=100.,close=100.) for d in sessions.session for n in ['A','B','C']])
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4),horizon=2)
    original=function(api,'run_analysis')(lending,sessions,universe,prices,config=cfg)
    first=original['legs'].query("side=='short' and model=='baseline'").iloc[0]
    selected=first.selected_ids
    prices.loc[(prices.security_id==selected)&(prices.session==sessions.session.iloc[2]),'close']=np.nan
    broken=function(api,'run_analysis')(lending,sessions,universe,prices,config=cfg)
    after=broken['legs'].query("side=='short' and model=='baseline'").iloc[0]
    assert after.selected_ids==selected and after.eligible_count==first.eligible_count
    assert np.isnan(after.gross_return) and after.unpriced_selected==1

def test_missing_target_still_gets_current_model_prediction(api):
    dates=pd.bdate_range('2024-01-02',periods=12)
    frame=pd.DataFrame([dict(session=d,security_id=str(i),decision_at=d.tz_localize('UTC')+pd.Timedelta(hours=17),label_available_at=(d+pd.offsets.BDay(2)).tz_localize('UTC'),forward_return=i*.01,scarcity_level=float(i),baseline=float(i)) for d in dates for i in range(4)])
    frame.loc[frame.session==dates[-1],['forward_return','label_available_at']]=[np.nan,pd.NaT]
    result=function(api,'chronological_predictions')(frame,api['Config'](minimum_train_sessions=4,refit_sessions=2),methods=('ridge',))
    assert result.loc[result.session==dates[-1],'ridge'].notna().all()

def test_invalid_historical_utilisation_is_not_clipped_into_flow(api):
    lending,sessions,members=tiny_inputs()
    lending.loc[(lending.security_id=='A')&(lending.event_date==sessions.session.iloc[-2]),'utilisation']=900.
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=8,half_lives=(1,2,4))
    result=function(api,'features_at')(lending,sessions,members,sessions.decision_at.iloc[-1],cfg).set_index('security_id')
    assert result.loc['A','invalid_utilisation_count']==1
    assert np.isnan(result.loc['A','scarcity_flow'])

def test_positioning_flow_uses_quantity_then_current_shares(api):
    lending,sessions,members=tiny_inputs()
    a=lending.security_id=='A'
    lending.loc[a,'on_loan']=10.
    lending.loc[a,'shares_outstanding']=np.arange(1,9)*1000.
    cfg=api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4))
    result=function(api,'features_at')(lending,sessions,members,sessions.decision_at.iloc[-1],cfg).set_index('security_id')
    assert result.loc['A','raw_positioning_flow']==pytest.approx(0.,abs=1e-12)

@pytest.mark.parametrize('suffix',['csv','parquet'])
def test_complete_mapped_stock_exports_run_without_local_helper_imports(api,tmp_path,suffix):
    inputs=function(api,'synthetic_inputs')(sessions_count=20,securities_count=4,seed=5)
    settings={key:True for key in ['vintages_are_as_received','row_availability_is_max_input','point_in_time_universe','consistent_corporate_actions','prices_include_distributions']}
    settings.update(fee_unit='decimal',fee_kind='actual_borrower')
    for name,frame in inputs.items():
        mapping={column:'export_'+column for column in frame.columns}
        exported=frame.rename(columns=mapping)
        path=tmp_path/f'{name}.{suffix}'
        if suffix=='csv': exported.to_csv(path,index=False)
        else: exported.to_parquet(path,index=False)
        settings[name+'_path']=str(path); settings[name+'_columns']=mapping
    result=function(api,'run_local_exports')(settings,api['Config'](window=5,min_observations=4,ema_min_observations=5,half_lives=(1,2,4),horizon=2))
    assert result['status']=='research_complete',result.get('message')
    assert len(result['features'])==80 and len(result['legs'])>0
    assert 'no independent' in result['metadata']['session_calendar']

@pytest.mark.parametrize('suffix',['csv','parquet'])
def test_export_reads_project_mapped_columns_at_io_boundary(api,tmp_path,suffix):
    from unittest.mock import patch
    source=pd.DataFrame({'source_b':[2,3],'unused':[999,999],'source_a':[5,7]})
    path=tmp_path/f'wide_export.{suffix}'
    if suffix=='csv': source.to_csv(path,index=False)
    else: source.to_parquet(path,index=False)
    name='read_csv' if suffix=='csv' else 'read_parquet'
    with patch.object(pd,name,wraps=getattr(pd,name)) as reader:
        result=function(api,'load_table')(path,{'a':'source_a','b':'source_b'})
        keyword='usecols' if suffix=='csv' else 'columns'
        assert reader.call_args.kwargs[keyword]==['source_a','source_b']
    pd.testing.assert_frame_equal(result,pd.DataFrame({'a':[5,7],'b':[2,3]}))
    with pytest.raises(ValueError,match='mapped'):
        function(api,'load_table')(path,{'absent':'missing_column'})

def test_invalid_export_mapping_fails_before_any_io(api,tmp_path):
    with pytest.raises(ValueError,match='one-to-one'):
        function(api,'load_table')(tmp_path/'not_created.csv',{'a':'same','b':'same'})

def test_csv_identifiers_preserve_leading_zeroes_and_reject_ambiguous_header(api,tmp_path):
    path=tmp_path/'identifiers.csv'
    path.write_text('source_id,value\n00123,2\n',encoding='utf-8')
    result=function(api,'load_table')(path,{'security_id':'source_id','metric':'value'})
    assert result.security_id.iloc[0]=='00123'
    path.write_text('source_id,source_id\n00123,00456\n',encoding='utf-8')
    with pytest.raises(ValueError,match='ambiguous'):
        function(api,'load_table')(path,{'security_id':'source_id'})

def test_parquet_index_is_not_a_mapped_data_column(api,tmp_path):
    path=tmp_path/'indexed.parquet'
    pd.DataFrame({'value':[2]},index=pd.Index(['00123'],name='source_id')).to_parquet(path)
    with pytest.raises(ValueError,match='mapped data columns'):
        function(api,'load_table')(path,{'security_id':'source_id'})
