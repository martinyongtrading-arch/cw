"""Contract tests for the symbolic, deliberately non-empirical catalogue."""

import importlib.util
import ast
import math
from pathlib import Path

import pandas as pd
import pytest


MODULE = Path(__file__).resolve().parents[1] / "work" / "formula_catalogue.py"


@pytest.fixture(scope="module")
def catalogue_module():
    assert MODULE.exists(), (
        "The self-contained formula catalogue implementation is missing"
    )
    spec = importlib.util.spec_from_file_location("formula_catalogue", MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_complete_exact_grid(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    rows = result["all_candidates"]
    assert len(rows) == 840
    assert rows.groupby(["archetype", "field", "d"]).size().eq(1).all()
    assert rows["archetype"].nunique() == 10
    assert rows["field"].nunique() == 14
    assert set(rows["d"]) == {5, 10, 20, 60, 120, 252}


def test_every_ledger_row_explains_its_expected_failure_mode(catalogue_module):
    rows = catalogue_module.build_formula_catalogue()["all_candidates"].set_index(
        "candidate_id"
    )
    modes = rows.expected_fragility_mode
    assert (
        len(modes) == 840
        and modes.notna().all()
        and modes.str.strip().str.len().gt(0).all()
    )
    change = modes.loc["Change:PR:d5"].lower()
    assert "denominator" in change and "overlap" in change
    assert "near-zero eigenvalues" in modes.loc["Level:Cond:d5"].lower()
    assert "minimum5-session" in modes.loc["Decay:AR:d20"].lower()
    assert "scalar" in modes.loc["CSrank:AR:d60"].lower()


def test_top30_reuses_the_full_ledger_failure_description(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    ledger = result["all_candidates"].set_index("candidate_id")
    for row in result["top30"].to_dict("records"):
        assert row["Fragility mode"].endswith(
            ledger.loc[row["candidate_id"], "expected_fragility_mode"]
        )


def test_scalar_cross_section_and_literal_decay_are_rejected(catalogue_module):
    rows = catalogue_module.build_formula_catalogue()["all_candidates"]
    invalid = rows[rows.archetype.isin(["CSrank", "Divergence", "Neutral", "Decay"])]
    assert invalid.status.eq("REJECTED").all()
    assert (
        rows[rows.archetype.eq("Decay")]
        .formula.str.contains("delta\\([^,]+,1\\)")
        .all()
    )
    assert (
        rows[rows.archetype.eq("CSrank")].rejection_reasons.str.contains("scalar").all()
    )


def test_level_duplicates_and_analytic_degeneracy(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    rows = result["all_candidates"]
    level = rows[(rows.archetype == "Level") & (rows.field == "PR")]
    assert level.formula.nunique() == 1
    assert level.status.eq("SURVIVOR").sum() == 1
    assert level.status.eq("DUPLICATE").sum() == 5
    degenerate = rows[rows.field.isin(["crowd_mean", "Slope"])]
    assert degenerate.status.eq("REJECTED").all()
    assert result["survivors"].formula.is_unique


def test_tied_percentile_moments_are_conditionally_admitted(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    rows = result["all_candidates"]
    moments = rows[rows.field.isin(["crowd_std", "crowd_skew"])]
    assert moments[moments.archetype.eq("Level")].status.eq("SURVIVOR").sum() == 2
    assert moments.field_admission.eq("CONDITIONAL_TIE_COHORT").all()
    assert moments.field_warning.str.contains("ties|tie", case=False).all()
    assert not moments.rejection_reasons.str.contains(
        "analytic percentile-rank moment degeneracy"
    ).any()
    # Analytic counterexample, not market data or an empirical signal test.
    distinct = pd.Series([1.0, 2.0, 3.0]).rank(method="average", pct=True)
    tied = pd.Series([1.0, 1.0, 3.0]).rank(method="average", pct=True)
    assert distinct.mean() == pytest.approx(tied.mean())
    assert distinct.std(ddof=1) == pytest.approx(1 / 3)
    assert tied.std(ddof=1) == pytest.approx(math.sqrt(1 / 12))
    assert distinct.skew() == pytest.approx(0)
    assert tied.skew() == pytest.approx(math.sqrt(3))
    assert "unverified" in result["metadata"]["field_binding_status"].lower()


def test_top30_are_valid_and_only_available_symbolic_fields(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    top = result["top30"]
    assert len(top) == 30
    assert {
        "#",
        "Formula",
        "Interpretation",
        "Fragility mode",
        "Orthogonality score",
    } <= set(top)
    assert set(top.Formula) <= set(result["survivors"].formula)
    assert top["Orthogonality score"].str.contains("syntactic").all()
    allowed = set(catalogue_module.GLOBAL_FIELDS) | {"crowd_i", "ret_i"}
    for fields in result["all_candidates"].primitive_fields:
        assert set(fields) <= allowed
    assert "syntactic" in result["metadata"]["diversity_definition"].lower()
    assert result["metadata"]["numeric_execution"] is False


def test_balanced_top30_spans_admissible_archetypes(catalogue_module):
    result = catalogue_module.build_formula_catalogue()
    slate = (
        result["survivors"].set_index("candidate_id").loc[result["top30"].candidate_id]
    )
    assert set(slate.archetype) == {
        "Level",
        "Change",
        "Correlation",
        "Interaction",
        "Accel",
        "Conditional",
    }
    assert slate.archetype.value_counts().eq(5).all()
    assert result["metadata"]["mean_pairwise_ast_overlap"] < 0.4
    assert set(result["metadata"]["excluded_archetypes"]) == {
        "CSrank",
        "Divergence",
        "Decay",
        "Neutral",
    }


def test_determinism_and_honest_overlap(catalogue_module):
    first = catalogue_module.build_formula_catalogue()
    second = catalogue_module.build_formula_catalogue()
    pd.testing.assert_frame_equal(first["all_candidates"], second["all_candidates"])
    pd.testing.assert_frame_equal(first["top30"], second["top30"])
    score = first["metadata"]["mean_pairwise_ast_overlap"]
    assert 0 <= score <= 1
    assert first["metadata"]["overlap_threshold_flag"] == (score >= 0.4)
    assert "not" in first["metadata"]["empirical_orthogonality"].lower()
    assert catalogue_module.ast_overlap("delta(PR,5)", "delta(PR,252)") == 1
    assert catalogue_module.ast_overlap("delta(PR,5)", "correlation(PR,crowd_i,5)") < 1


def test_causal_lags_and_formula_complexity(catalogue_module):
    rows = catalogue_module.build_formula_catalogue()["survivors"]
    expected_lags = {
        "Level": 1,
        "Change": 1,
        "Correlation": 1,
        "Interaction": 0,
        "Accel": 2,
        "Conditional": 1,
    }
    ts_ops = {"zscore", "delta", "ts_std", "correlation", "ts_rank", "decay_linear"}
    all_fields = set(catalogue_module.GLOBAL_FIELDS) | {"crowd_i", "ret_i"}

    def path_metrics(node):
        children = [path_metrics(child) for child in ast.iter_child_nodes(node)]
        child_ts = max((child[0] for child in children), default=0)
        child_depth = max((child[1] for child in children), default=0)
        is_call = isinstance(node, ast.Call)
        is_ts = is_call and isinstance(node.func, ast.Name) and node.func.id in ts_ops
        return child_ts + int(is_ts), child_depth + int(is_call)

    for row in rows.itertuples():
        tree = ast.parse(row.formula, mode="eval")
        ts_depth, call_depth = path_metrics(tree)
        fields = {
            node.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Name) and node.id in all_fields
        }
        assert row.minimum_source_lag == expected_lags[row.archetype]
        assert row.max_time_series_nesting == ts_depth
        field_lags = {}

        def collect_field_lags(node, depth=0):
            is_ts = (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id in ts_ops
            )
            depth += int(is_ts)
            if isinstance(node, ast.Name) and node.id in all_fields:
                field_lags.setdefault(node.id, []).append(depth)
            for child in ast.iter_child_nodes(node):
                collect_field_lags(child, depth)

        collect_field_lags(tree)
        assert row.source_lag_by_input == {
            name: min(lags) for name, lags in field_lags.items()
        }
        assert row.minimum_source_lag == min(row.source_lag_by_input.values())
        assert ts_depth <= 2
        assert call_depth <= 4
        assert len(fields) <= 3
