# ASX stock crowding notebook design

The user authorizes implementation, testing, a signal generator and an independent critic, with no more than three subagents. All research and implementation concern stock crowding. Indices and GICS sectors are evaluation slices of the same stock signal.

## Deliverable

One self-contained Jupyter notebook, `ASX_Crowding_Framework.ipynb`, containing the four-pass structural review, per-feature audit, public-source research, implementation, executable adversarial checks, synthetic demonstration, and local CSV/Parquet configuration. No proprietary data is available. Synthetic outputs establish machinery behavior only.

## Approach

A standalone notebook is the user's chosen approach. Reusing either neighboring Crowding project would import unrelated assumptions, so neither is a dependency. A separate Python package would violate the request for everything in a notebook. Build-time source files and verification scripts may exist, but the delivered notebook must not import them.

## Input contract

Explicit maps translate user export columns to canonical names; canonical names are not claimed S&P identifiers. Lending vintages require security_id, event_date, available_at, utilisation, on_loan, lendable, shares_outstanding, broker_count. Timestamps are timezone-aware. A row timestamp must be the maximum availability of all fields used in that row. Separate ASX session, point-in-time eligible-universe and price tables are required for historical evaluation. Unknown absence remains missing. Conflicting timestamp ties, invalid matched active/total lender counts, unidentified fee units and noncausal timestamps are rejected with useful messages. Broker_count is an entity count: nonmissing values must be finite nonnegative integers, without rounding. The public validator checks the supplied panel once; standalone features validate only visible as-of vintages. An average or weighted vendor quantity must not be mapped to broker_count; its distinct semantics require verification before separate use.

For each decision rebuild the entire prior feature history from vintages available at that decision. Do not roll a final-revised historical panel. Use supplied ASX sessions, never infer exchange sessions from weekdays. Events use event_date plus available_at and versions; known future event dates may be used after announcement.

## Corrected architecture

Compute the three-theme, 16-column template as diagnostic output. Label quadratic log-horizon contrasts as horizon curvature, not temporal acceleration. Default score is equal-theme baseline plus fixed EMA-slope overlay (kappa 0.5), with one shared normalization cohort and fixed family weights. Preserve missing contributions as neutral without availability-pattern reweighting. Optional columns: annual borrower-fee level, trailing standard deviation of fee levels, matched active/total lender fraction, quantity/supply decomposition and one demand quadrant. These are disabled by default and never auto-selected. No blanket interaction search.

Use adjusted causal EMA kernels with explicit calendar gaps, trailing250-session moments requiring200 actual observations, and one rule unaffected by event masking. Reset fee history at a supplied definition regime. Clip inputs once before cross-sectional normalization, preserve raw monetary returns. The same feasibility universe applies to baseline and challenger. Side comparisons use actual portfolio legs, not different piecewise models.

The implemented baseline/overlay comparison uses chronological mature-label eligibility and exploratory retrospective reports. The original design promised an untouched purged holdout; that stage is **not implemented or executed**. Mature-label boundary checks do not fulfill that promise. Optional single fixed configurations of Ridge, Lasso, Elastic Net, PCR and shallow trees produce research predictions, but their portfolio comparisons are not wired into the default report. Dependence-aware block inference and Holm are exploratory diagnostics, not a completed confirmatory testing programme. Portfolio accounting uses signed stock returns and entry-fee/initial-notional cost scenarios. The deterministic forced-cover ledger is standalone and tested; it is **not integrated into evaluate_legs**. No probability level is guessed from literature. Prices must have a declared distribution/corporate-action convention.

## Verification and limits

Run adversarial tests for vintage revisions, missing rows, masked windows, zero variance, proportional lender counts, fee-unit conversion/regime breaks, future invariance, purge endpoints, common feasibility, weekend fees and short-cover cash flows. Execute notebook top to bottom in a fresh kernel. Exercise real CSV and Parquet adapters on synthetic exports. An unconfigured real-data path reports setup status; it must not substitute synthetic results for real results.

Unverified actual vendor schema, data delivery history, baseline signs and portfolio costs remain explicit configuration requirements. No claim of alpha, feasible capacity or production approval follows from passing these checks.

## Requirement coverage corrections

The requested analytical +/-10% and +/-20% parameter/configuration fragility review is fulfilled. A comprehensive executed sensitivity grid remains proposed/unperformed validation; it was not required to fabricate empirical results in the original web-only review. The fourteen names are symbolic catalogue vocabulary, not an implemented extractor; that symbolic-generation request did not explicitly demand an extractor or numeric DSL. Numeric score-AR is implemented separately. Return-AR and position-HHI are reviewed conditional constructions without runnable paths. Detailed GICS2/4/6/8 research is fulfilled; deeper hierarchy views are not implemented. MP/EWM/two-window assertions were reviewed and unsupported mandatory claims rejected, rather than omitted. See work/requirement_coverage.md for implemented, standalone, protocol-only and unavailable statuses; this design is not a completion certificate.
