# ASX Stock Crowding Notebook Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Deliver one self-contained, executable stock-crowding notebook for mapped S&P Global ASX CSV/Parquet exports, with research and meaningful machinery tests.

**Architecture:** All runtime definitions live in notebook cells. Build-time sources produce the notebook; no neighboring project or local runtime module is imported. Input validation, causal feature construction, fixed scoring, chronological evaluation and signed accounting have separate cells.

**Tech Stack:** Python3.13, numpy, pandas, scipy, scikit-learn, matplotlib, nbformat, nbclient, ipykernel, pyarrow, pytest.

**Spec:** ../specs/2026-10-30-asx-crowding-design.md

## Global Constraints

- Stocks only; maximum three subagents total.
- No proprietary data, no empirical signal claims.
- Local CSV/Parquet inputs through explicit field maps, not guessed vendor names.
- One self-contained notebook, as-of-known-time history, real ASX session calendar for real runs.
- Never clip monetary P&L; no automatic feature/model search.

## Review Focus

- Late revisions to old observations must not change earlier decisions.
- Partial data and masks must never manufacture zero loans or relax minimum valid counts.
- Invalid lender denominators and fee units must fail descriptively.
- Delayed or missing prices must not create executable labels or free shorts.
- Synthetic demonstrations must remain visibly separate from real-data execution.

### Task 1: causal adapters and feature engine

Files: work/notebook_source.py; tests/test_notebook.py.

Interfaces: load_table(path, mapping), validate_inputs(lending, sessions, universe), history_asof(lending, decision_at), features_at(lending, sessions, members, decision_at, config), build_scores(features, config).

- [x] Write behavioral tests for revision invariance, timestamp ties, missingness, constant/ramp kernels, lender ratios, fees and min-periods.
- [x] Run tests and observe assertions fail because definitions are absent.
- [x] Implement explicit contracts, per-decision vintage snapshots and fixed score construction.
- [x] Run the tests and confirm green.

### Task 2: stock evaluation and accounting

Interfaces: make_labels(prices,sessions,horizon), chronological_predictions(features,labels,config), evaluate_legs(scores,prices,sessions,config), cover_ledger(prices,cover_index,reenter_index,fee).

- [x] Write failing tests for mature-label purging, signed returns, common feasible universe, fees over weekends and forced covers.
- [x] Implement fixed comparisons, optional fixed research models, block inference, slices and raw cash-flow accounting.
- [x] Run whole project tests and record results.

### Task 3: notebook packaging, research and execution

Files: ASX_Crowding_Framework.ipynb; work/build_notebook.py; requirements.txt; README.md; work/verification.json.

- [x] Embed full structural/feature review and stock-index/sector research, with primary links.
- [x] Embed all definitions and tests, synthetic demonstration, local CSV/Parquet settings and actionable setup status.
- [x] Execute fresh kernel, export synthetic CSV/Parquet, run mapped adapters, inspect artifacts.
- [x] Have critic agent review final notebook; fix material findings with regression tests and rerun full suite.
- [x] Record exact passing counts and unverified vendor/data limitations.

No Git repository exists at the workspace root. Use this new isolated directory; do not initialize or mutate unrelated repositories. User explicitly directed proceeding to implementation, so no additional design-approval stop is inserted.

### Task4: symbolic catalogue — complete
840slots;372unique conditional symbolic candidates;60duplicates;408rejections; balancedtop30, normalizedASToverlap0.1734. No numericDSLor empiricalalpha claim.

### Task5: safe stock preparation and bounded profiling
- [x] Prepare canonical tables once per invocation; share one feature-math implementation.
- [x] Preserve future-conflict timing, event revisions/raw payloads, missingness and exact normalized scores.
- [x] Benchmark ASX200/300-sized330-history/ten-decision fixtures; separate wall time and one-date traced memory.
- [x] Independent full330-decision ASX200-sized runtime measured at94.02seconds;66,000rows.
- [ ] FullASX300/7000-stock backfills, realDB/HPC and vendor-data acceptance remainOPEN external gates.
- [x] Final saved notebook rebuilt/executed/digest-verified after integration;86embeddedchecks,zeroerrors/warnings.

### Completeness follow-up
- [x]840row-level fragility descriptions and sharedtop30rendering; two regressions.
- [x]Finite nonnegative integer broker-count validation at public/standalone boundaries, without rounding; future-vintage and missing-value tests.
- [x]96source/embeddedchecks and fresh-kernel hash verification; finalcore performance rebound.
- [x]Provenance-aware requirement coverage:analyticalreviewfulfilled; comprehensiveproposedsensitivityvalidationunperformed.
- [ ]Originalpurgedholdoutdesignpromiseandforced-cover/optionalcandidate/modelportfoliointegrationsremainoutstanding.
No numeric14-fieldextractor was explicitlyrequestedbythesymbolicprompt; A/Breview-onlyandGICSresearchfulfilledarelabelledaccordingly.

### Code quality repair pass
- [x]Independent expected-value regressions for8defectfamilies and uncappedshortcontrols;182fullsource/embeddedchecks.
- [x]Batchnormalization/lenderratio reuse, exactpublicarchiveparity and pairedfull-backfill timing/RSS.
- [x]Formatted coherentcells≤99lines, earlymatrixplot, visibleconfiguration, explicitstrategyassumptions.
- [x]Freshkernel, source/AST/digest/layout/visualverification; no model/feed/selectionpolicy expansion.
